POKEMON RED v2 — PARTY SPRITES + TYPE LABELS FIX
================================================

FIXES
-----
- Adds a complete 151-species Generation-I internal-ID -> National Dex map,
  based on Red/Blue's Pokédex-order lookup.
- Adds `national_dex` and raw `type_ids` to the environment's JSON-safe party
  snapshots. The renderer can now find `assets/gen1_sprites/<dex>.png`.
- Preserves live type labels and includes safe legacy labels for the already
  saved Charmander + two Geodude party: Charmander = Fire; Geodude = Rock/Ground.
- Backfills the old snapshot's starter and preferred HM carrier labels.
- Updates the TensorBoard callback to enrich the persisted best worker's
  metadata even when that worker is no longer improving the progression rank.
  Existing historical level, HP, move, status and party-order data are retained.
- Uses metadata fallbacks when rendering older snapshots so the sprites can
  appear immediately after the patch, before a new full live record is saved.

CHECKPOINT COMPATIBILITY
------------------------
The patch only adds diagnostic fields to party snapshots and callback rendering.
It does not modify action_space, observation_space, rewards, policy inputs,
policy outputs, or PPO model parameters. Existing checkpoints are preserved.

FILES
-----
pokemon_red_party_sprite_type_fix.patch   Patch for the two existing .py files
gen1_party_metadata.py                    Full Gen-I ID mapping + merge helper
migrate_most_advanced_party.py             Safe one-time JSON metadata backfill
test_party_metadata_visual_fix.py          Offline regression tests

INSTALL (FISH SHELL)
--------------------
1. Stop the trainer with Ctrl+C. Do not delete runs/, checkpoints, starter DB,
   or TensorBoard event files.
2. Extract these package files into the project root (beside the two .py files).
3. Back up source and saved party JSON:

   cp red_gym_env_v2.py red_gym_env_v2.py.pre_party_visual_fix
   cp tensorboard_callback.py tensorboard_callback.py.pre_party_visual_fix
   cp runs/_trajectory_history/most_advanced_party.json runs/_trajectory_history/most_advanced_party.json.pre_party_visual_fix

4. Dry-run the source patch first:

   patch -p0 --dry-run < pokemon_red_party_sprite_type_fix.patch

   Continue only if both files check cleanly. Then apply:

   patch -p0 < pokemon_red_party_sprite_type_fix.patch

5. Preview then migrate the historical party record:

   python migrate_most_advanced_party.py --dry-run
   python migrate_most_advanced_party.py

   The expected result for the current three-member snapshot is:
   National Dex=3, types=3, starter labels=3, HM roles=2.

6. Validate:

   python -m py_compile red_gym_env_v2.py tensorboard_callback.py gen1_party_metadata.py migrate_most_advanced_party.py
   python test_party_metadata_visual_fix.py
   python test_capture_rewards.py
   python test_party_balance.py
   python test_starter_diversity.py
   python test_callback_party_metrics.py
   python test_hm_awareness_patch.py

7. Resume from the existing `runs/poke_latest.zip` (or your chosen checkpoint).
   No checkpoint reset or retraining from scratch is required. The party image
   should show actual Gen-I sprites once the callback writes the next image.

IMPORTANT
---------
This package was prepared against the archived source revision reconstructed
from your prior capture/HM patch and the callback revision, and cross-checked
against the live code excerpts you pasted. Always dry-run first. If a hunk fails,
do not force the patch; keep the backups and share the dry-run output.
