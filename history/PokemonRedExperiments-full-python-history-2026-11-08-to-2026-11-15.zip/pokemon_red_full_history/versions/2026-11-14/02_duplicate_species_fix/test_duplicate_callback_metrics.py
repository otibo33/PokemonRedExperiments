from __future__ import annotations
import importlib.util
import sys
import types
from pathlib import Path

# Stub only SB3/TensorBoard symbols; exercise the real callback metric helper.
callbacks = types.ModuleType("stable_baselines3.common.callbacks")
class BaseCallback: pass
callbacks.BaseCallback = BaseCallback
logger = types.ModuleType("stable_baselines3.common.logger")
class Image:
    def __init__(self, *args, **kwargs): pass
logger.Image = Image
stable = types.ModuleType("stable_baselines3")
common = types.ModuleType("stable_baselines3.common")
common.callbacks, common.logger = callbacks, logger
stable.common = common
sys.modules["stable_baselines3"] = stable
sys.modules["stable_baselines3.common"] = common
sys.modules["stable_baselines3.common.callbacks"] = callbacks
sys.modules["stable_baselines3.common.logger"] = logger

tensorboard = types.ModuleType("torch.utils.tensorboard")
tensorboard.SummaryWriter = type("SummaryWriter", (), {})
sys.modules["torch.utils.tensorboard"] = tensorboard

path = Path(__file__).with_name("tensorboard_callback.py")
spec = importlib.util.spec_from_file_location("party_callback_test", path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

metrics = module.TensorboardCallback._party_level_metrics
cases = [
    ([], 0.0, 0),
    ([{"level": 20}], 0.0, 0),
    ([{"level": 20}, {"level": 10}], 1.0, 1),
    ([{"level": 40}, {"level": 16}], 10.0 / 24.0, 1),
]
for party, expected_score, expected_eligible in cases:
    result = metrics(party, 10)
    assert abs(result["party_level_balance_score"] - expected_score) < 1e-9
    assert result["party_level_balance_eligible"] == expected_eligible
print("PASS TensorBoard callback matches environment balance eligibility/score")


# Verify the newly-added diagnostics are surfaced as TensorBoard scalars.
class FakeLogger:
    def __init__(self):
        self.values = {}
    def record(self, key, value):
        self.values[key] = value

class FakeTrainingEnv:
    def env_method(self, *args, **kwargs):
        return [{"Bulbasaur": 1, "Charmander": 1, "Squirtle": 1}]

callback = module.TensorboardCallback.__new__(module.TensorboardCallback)
callback.num_timesteps = 10
callback._last_scalar_log_timestep = 0
callback.scalar_log_every = 1
callback.best_map_progress = -1
callback.best_map_id = -1
callback.episodes_completed = 0
callback.logger = FakeLogger()
callback.training_env = FakeTrainingEnv()
callback._log_progress_scalars([{
    "map_progress": 1,
    "best_map_progress": 1,
    "seen_tiles": 5,
    "captures": 3,
    "unique_captures": 1,
    "repeat_or_unpaired_captures": 2,
    "party_duplicate_count": 1,
    "party_unique_fill_score": 2 / 6,
    "party_species_count": 2,
    "party_size": 3,
    "party_fill_score": 0.5,
    "party_diversity_score": 2 / 6,
}])
assert callback.logger.values["game/unique_captures_mean"] == 1.0
assert callback.logger.values["game/repeat_or_unpaired_captures_mean"] == 2.0
assert callback.logger.values["game/party_duplicate_count_mean"] == 1.0
assert abs(callback.logger.values["game/party_unique_fill_score_mean"] - 2 / 6) < 1e-9
print("PASS TensorBoard logs duplicate-capture and unique-party metrics")


# The saved "most advanced party" candidate must prefer distinct captures and
# a less redundant party when progression metrics otherwise tie.
rank_unique = module.TensorboardCallback._party_rank({
    "best_map_progress": 5, "map_progress": 5, "badges": 2,
    "hm_critical_ready": 1, "hm_critical_moves_taught": 1,
    "hm_moves_taught": 2, "pokedex_owned": 12,
    "unique_captures": 4, "captures": 4,
    "party_species_count": 4, "party_duplicate_count": 0,
    "party_diversity_score": 4 / 6, "party_level_balance_score": 0.8,
    "party_size": 5,
})
rank_duplicate = module.TensorboardCallback._party_rank({
    "best_map_progress": 5, "map_progress": 5, "badges": 2,
    "hm_critical_ready": 1, "hm_critical_moves_taught": 1,
    "hm_moves_taught": 2, "pokedex_owned": 12,
    "unique_captures": 2, "captures": 7,
    "party_species_count": 3, "party_duplicate_count": 2,
    "party_diversity_score": 3 / 6, "party_level_balance_score": 0.8,
    "party_size": 5,
})
assert rank_unique > rank_duplicate
print("PASS best-party ranking prefers unique captures and fewer duplicates")
