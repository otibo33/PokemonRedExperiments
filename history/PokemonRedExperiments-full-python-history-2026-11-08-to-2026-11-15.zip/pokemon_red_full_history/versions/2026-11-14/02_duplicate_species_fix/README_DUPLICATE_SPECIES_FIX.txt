POKEMON RED v2 — DUPLICATE-SPECIES REWARD FIX
============================================

SCOPE
-----
This is an additive overlay patch for the existing PokemonRedExperiments/v2
project. It changes only:
  - red_gym_env_v2.py
  - tensorboard_callback.py

It does NOT replace either full source file, alter the observation/action
spaces, change your ROM/save-state, or delete/rotate any checkpoints or logs.
The same PPO checkpoint remains structurally loadable. Reward shaping changes,
so continued training will now optimize the revised collection/team objective.

IMPORTANT BASELINE
------------------
This patch was generated against the v2 source that already includes the
party-completion/capture/HM work and the later party sprite/type metadata fix
(pokemon_red_party_sprite_type_fix). It assumes those changes are already
present in your active red_gym_env_v2.py and tensorboard_callback.py. It is
not a replacement for those earlier patches and does not contain their full
source files. Always run the dry-run step below against your actual active
files before applying it.

WHY THE AGENT WAS REPEATING GEODUDE
----------------------------------
The environment counted every successful capture in the primary capture reward,
including repeat catches of a species already registered in the Pokédex. It
also rewarded occupied party slots, even when a new slot duplicated a species.
That made a second Geodude produce positive reward despite adding no team
variety.

WHAT CHANGES
------------
1. `captures` continues to count every successful catch for diagnostics.
2. `unique_captures` counts captures paired with a new owned-Pokédex bit. Only
   these earn the primary capture reward.
3. Repeat/unpaired captures receive a small penalty. A short four-environment-
   step pairing window handles the case where the capture marker and Pokédex
   update arrive on adjacent steps; the temporary penalty clears when paired.
4. Party-slot reward is based on unique species occupying the active party,
   not raw occupied slots. A second Geodude therefore cannot increase the
   party-fill reward.
5. An additional mild penalty applies for each redundant active-party slot.
   This encourages depositing duplicates, without hard-banning a species.
6. TensorBoard gains unique-capture, repeat/unpaired-capture, unique-party-fill,
   and party-duplicate metrics. The saved “most advanced party” ranking now
   prefers unique captures and fewer duplicate party members when progression
   is otherwise tied.

DEFAULT WEIGHTS
---------------
  repeat_capture_penalty_weight = 4.0
  party_duplicate_penalty_weight = 5.0

With the existing `reward_scale = 0.5`, a repeat/unpaired catch costs 2.0 reward
units and one redundant active-party slot costs 2.5 reward units. A unique
capture keeps the existing capture reward weight (default 32.0, or 16.0 reward
units at reward_scale 0.5). The weights can be overridden in env_config if
needed; no training-launcher change is required for the defaults to apply.

INSTALL (CACHYOS / FISH)
------------------------
1. Stop training cleanly with Ctrl+C. Do not delete runs/, checkpoints,
   TensorBoard event files, the starter-choice database, init.state, or ROM.
2. Extract this archive into the v2 project directory, beside the two source
   files:

   cd "/path/to/external-drive/Projects/PokemonRedExperiments/v2"
   unzip -o pokemon_red_duplicate_species_fix.zip -d .

3. Back up the two files:

   cp red_gym_env_v2.py red_gym_env_v2.py.pre_duplicate_fix
   cp tensorboard_callback.py tensorboard_callback.py.pre_duplicate_fix

4. Dry-run before modifying anything:

   patch -p0 --dry-run < pokemon_red_duplicate_capture_reward.patch

5. Only if every hunk succeeds, apply:

   patch -p0 < pokemon_red_duplicate_capture_reward.patch

   If any hunk fails, stop. Do not use --force. Your active source may contain
   newer changes than this saved patch base; compare/merge against the active
   files rather than replacing them with an older full source file.

6. Run syntax checks and the included regression tests:

   python -m py_compile red_gym_env_v2.py tensorboard_callback.py
   python test_duplicate_capture_rewards.py
   python test_duplicate_callback_metrics.py

7. Also run the relevant existing checks if they are present:

   python test_party_balance.py
   python test_starter_diversity.py
   python test_party_metadata_visual_fix.py

   The older test_hm_awareness_patch.py contains a brittle source-text
   assertion that predates the sprite/type metadata update; its failure on
   that changed line is not evidence that HM runtime behaviour regressed.

8. Resume the existing run/checkpoint with the same launcher and configuration.
   The observation/action interfaces are unchanged, so do not start a fresh
   policy merely for this patch. TensorBoard will show the new metrics after
   additional training steps.

EXPECTED TENSORBOARD TAGS
-------------------------
  game/unique_captures_mean
  game/repeat_or_unpaired_captures_mean
  game/party_duplicate_count_mean
  game/party_unique_fill_score_mean
  progress/most_advanced_unique_captures
  game/most_advanced_party_duplicate_count

VALIDATION
----------
The patch was applied in a clean temporary copy of the saved v2 baseline
(including the party sprite/type metadata change), and `patch --dry-run` passed.
Python syntax compilation passed. The duplicate-capture, party-balance,
callback metrics, starter-diversity, and party sprite/type metadata regression
tests all passed. This is source-level verification only; no live PyBoy training
session was run in this build environment.

LIMITATION
----------
`unique_captures` is paired with an owned-Dex count increase over the existing
short window. It is a robust Gen-I novelty signal, but an unrelated gift or
evolution occurring in the same small window as a catch could theoretically
be paired with that catch. This does not affect total `captures` telemetry.
The policy is discouraged, not hard-blocked, from catching duplicates. It may
still do so when exploration, survival, or a future reward objective makes it
choose that action.
