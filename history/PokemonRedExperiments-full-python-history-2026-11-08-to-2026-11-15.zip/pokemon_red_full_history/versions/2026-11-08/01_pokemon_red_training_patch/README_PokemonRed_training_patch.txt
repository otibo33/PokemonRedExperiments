Pokémon Red PPO training patch
==============================

Files
-----
red_gym_env_v2.py
  Updated environment. Default observation mode keeps the original Dict keys and
  shapes so an existing checkpoint can be checked for compatibility. The
  optional navigation observations are enabled only with --nav in the trainer.

game_stats_callback.py
  Logs numeric game metrics from the environment's step() info dictionary.

baseline_run_paralell.py
  Integrated PPO trainer reconstructed from the training script already shared
  in the project. Keeps the original core PPO settings and adds time-based seeds,
  rolling versioned checkpoints, repeated --init-state support, and --nav mode.

smoke_test_env.py
  Tests observation_space.contains() after reset and after each sampled action,
  checks finite rewards, and tests every configured init-state path.

Run from the project folder containing global_map.py and events.json
--------------------------------------------------------------------

1) Legacy-observation checkpoint resume (default mode):
   python smoke_test_env.py --gb-path ../PokemonRed.gb --init-state ../init.state
   python baseline_run_paralell.py --resume runs/poke_final --timesteps 500000000

2) Test multiple starting states:
   python smoke_test_env.py --gb-path ../PokemonRed.gb \
     --init-state states/pallet.state \
     --init-state states/after_brock.state

   The same repeated --init-state arguments can be supplied to the trainer.
   Repeating a path weights it more heavily in the random start distribution.

3) Fresh navigation-aware run (DO NOT load an old checkpoint):
   python smoke_test_env.py --nav --gb-path ../PokemonRed.gb \
     --init-state ../init.state
   python baseline_run_paralell.py --nav --timesteps 500000000

The --nav trainer defaults to runs_v3, while legacy mode defaults to runs.
Use --session-dir to override either directory.

Checkpointing
-------------
New checkpoints are named poke_<aggregate_timesteps>_steps.zip. The newest
five are retained by default. The final model is written as poke_final.zip;
Ctrl+C writes poke_interrupted.zip.

Notes
-----
- Python syntax compilation passed in the authoring environment.
- The authoring environment does not have PyBoy, Gymnasium, or Stable-Baselines3,
  so the real-ROM smoke test must still be run in the user's project venv.
- tensorboard_callback.py was not available in the supplied project files. The
  trainer uses PPO's built-in TensorBoard logging plus GameStatsCallback.
