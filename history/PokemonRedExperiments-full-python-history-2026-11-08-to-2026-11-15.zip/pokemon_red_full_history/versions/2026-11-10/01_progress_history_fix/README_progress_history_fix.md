# Pokémon Red: terminal episode + persistent exploration history fix

This package contains two replacements for the v2 project:

- `red_gym_env_v2.py`
- `tensorboard_callback.py`

They are built from the environment source you supplied and the working
`TensorboardCallback` implementation you pasted. The callback keeps the same
public class name and constructor, so the existing launcher's import and
`TensorboardCallback(log_dir)` call do not need to change.

## What this fixes

1. **Captures the true terminal episode before SB3 resets it.**
   `RedGymEnv.step()` now places a copy of the terminal episode stats, episode
   map, lifetime map, progression and event flags inside `info["episode_snapshot"]`
   on the truncating step. `SubprocVecEnv` can then auto-reset without erasing
   the data the callback needs.

2. **Stops polling `check_if_done()` after the reset.**
   The callback uses SB3's `dones` and `infos` from the step that just finished.
   It processes every worker that finished on that vector step, not only worker 0.

3. **Keeps an exploration map across episode resets.**
   The environment now has an episode map (still reset for the environment's
   normal observation/reward behaviour) and a separate `lifetime_explore_map`
   that is not cleared by `reset()`.

4. **Persists map history across training process restarts.**
   The callback saves worker maps and best progression in:

   ```text
   <log_dir>/_trajectory_history/
       worker_exploration_maps.npz
       progress_metadata.json
   ```

   Reusing the same callback `log_dir` when resuming training reloads the
   cumulative map, best map progression, episode count and named event flags.

5. **Logs better progress indicators.**
   Existing image tags stay available and now show cumulative exploration:

   - `trajectory/explore_sum`
   - `trajectory/explore_map`

   Additional per-episode images are logged when one or more workers finish:

   - `trajectory/episode_explore_sum`
   - `trajectory/episode_explore_map`

   Progress scalars include:

   - `progress/current_map_progress_mean`
   - `progress/worker_best_map_progress_mean`
   - `progress/best_ever_map_progress`
   - `progress/best_map_id`
   - `progress/episodes_completed_total`

   Map images are refreshed every 10,000 aggregate environment timesteps and
   whenever an episode ends. Image enlargement remains 2x nearest-neighbour.

6. **No gameplay screenshots.**
   This callback does not log `gameplay/screen_4x_rgb`.

## Important distinction

This fixes the *history and logging* of exploration. It does not make a new
reinforcement-learning episode continue its in-game save from Cerulean City.
Your existing `reset()` intentionally reloads `init.state` at the start of each
episode. The agent still learns across episodes through the PPO checkpoint;
the cumulative maps and high-water progression now also remain visible across
episodes and resumptions.

Existing TensorBoard event records from before this fix are not rewritten.
Future records under `trajectory/explore_sum` and `trajectory/explore_map` will
show the cumulative map. Old historical frames will still represent the old
per-episode maps.

## Install safely

From the v2 directory:

```fish
cd ~/Projects/PokemonRedExperiments/v2
cp red_gym_env_v2.py red_gym_env_v2.py.before_progress_fix
cp tensorboard_callback.py tensorboard_callback.py.before_progress_fix
```

Extract the ZIP into this directory, allowing the two files to be replaced.
Do not replace `global_map.py`, `events.json`, the ROM, `init.state`, or your PPO
checkpoint.

The existing training code can keep using:

```python
from tensorboard_callback import TensorboardCallback

# Keep the existing construction:
TensorboardCallback(log_dir)
```

**Use the same `log_dir` when resuming** if you want the cumulative map from a
previous training process to be restored. For the earlier launcher that uses
`Path("runs")`, the history directory will be `runs/_trajectory_history/`.

## Verify before launching a long run

With the project's `.venv` activated:

```fish
python -m py_compile red_gym_env_v2.py tensorboard_callback.py
python -c "from tensorboard_callback import TensorboardCallback; print('callback import OK')"
python -c "from red_gym_env_v2 import RedGymEnv; print('environment import OK')"
```

The two files pass Python syntax compilation. A callback persistence smoke test
using a mocked VecEnv also passed. A full emulator/training run must still be
verified on your machine with your ROM, state file and installed dependencies.
