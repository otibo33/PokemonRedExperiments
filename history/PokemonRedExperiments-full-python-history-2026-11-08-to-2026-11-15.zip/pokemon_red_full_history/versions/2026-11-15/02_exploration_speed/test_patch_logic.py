from apply_exploration_speed_patch import ENV_NEW, ENV_OLD


def test_environment_reward_block_is_exactly_matchable():
    fixture = "prefix\n" + ENV_OLD + "suffix\n"
    assert fixture.count(ENV_OLD) == 1
    updated = fixture.replace(ENV_OLD, ENV_NEW, 1)
    assert "len(self.lifetime_seen_coords)" in updated
    assert "max(self.best_map_progress, 0)" in updated
    assert "len(self.seen_coords) * 0.1" not in updated


def test_observation_and_action_definitions_are_not_in_patch():
    assert '"screens"' not in ENV_NEW
    assert '"recent_actions"' not in ENV_NEW
    assert "action_space" not in ENV_NEW
