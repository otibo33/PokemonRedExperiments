#!/usr/bin/env python3
"""Apply a checkpoint-observation-compatible exploration reward patch.

Run from the v2 directory, or pass explicit --env and --trainer paths.
The patch changes reward accounting only; it does not alter observations,
action space, emulator timing, PPO architecture, or existing checkpoints.
"""
from __future__ import annotations

import argparse
import re
import shutil
from datetime import datetime
from pathlib import Path

ENV_OLD = '''            # Important story-map milestones. This uses the config value that
            # existed in the original file but was not connected to rewards.
            "map_progress": (
                self.reward_scale * self.map_progress_weight * self.max_map_progress
            ),
            "explore": self.reward_scale * self.explore_weight * len(self.seen_coords) * 0.1,
'''

ENV_NEW = '''            # Reward story-map progress once per worker lifetime, not once per
            # episode. This prevents repeatedly farming the same early maps.
            "map_progress": (
                self.reward_scale * self.map_progress_weight
                * max(self.best_map_progress, 0)
            ),
            # Reward coordinates that are genuinely new to this worker across
            # episode resets. Episode-local seen_coords remains available for
            # diagnostics and episode map visualizations.
            "explore": (
                self.reward_scale * self.explore_weight
                * len(self.lifetime_seen_coords) * 0.1
            ),
'''


def resolve_path(explicit: str | None, candidates: list[Path], label: str) -> Path | None:
    if explicit:
        path = Path(explicit).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"{label} file not found: {path}")
        return path
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    return None


def backup(path: Path) -> Path:
    base = path.with_name(path.name + ".before_exploration_speed.bak")
    if not base.exists():
        destination = base
    else:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        destination = path.with_name(path.name + f".before_exploration_speed_{stamp}.bak")
    shutil.copy2(path, destination)
    return destination


def patch_environment(path: Path, dry_run: bool) -> bool:
    source = path.read_text(encoding="utf-8")
    if ENV_NEW in source:
        print(f"[already patched] {path}")
        return False
    count = source.count(ENV_OLD)
    if count != 1:
        raise RuntimeError(
            f"Expected exactly one known reward block in {path}, found {count}. "
            "No environment file was changed. Your local file may differ from the "
            "2026-11-14 tested snapshot."
        )
    updated = source.replace(ENV_OLD, ENV_NEW, 1)
    if dry_run:
        print(f"[dry-run] would update lifetime novelty + lifetime map-progress reward in {path}")
        return True
    backup_path = backup(path)
    path.write_text(updated, encoding="utf-8")
    print(f"[updated] {path}")
    print(f"[backup]  {backup_path}")
    return True


def patch_trainer(path: Path, weight: float, dry_run: bool) -> bool:
    source = path.read_text(encoding="utf-8")
    # Only update the explicit config entry, whether the dict uses single or
    # double quotes. Other numeric values in the trainer are left untouched.
    pattern = re.compile(
        r"(?P<key>['\"]explore_weight['\"]\s*:\s*)(?P<value>(?:0?\.25|0\.250))(?=\s*[,}])"
    )
    updated, count = pattern.subn(lambda m: m.group("key") + f"{weight:g}", source)
    if count == 0:
        if re.search(r"['\"]explore_weight['\"]\s*:\s*" + re.escape(f"{weight:g}"), source):
            print(f"[already configured] explore_weight={weight:g} in {path}")
            return False
        print(
            f"[manual config needed] Could not find an explicit explore_weight: 0.25 in {path}. "
            f"Set the environment config entry to 'explore_weight': {weight:g}."
        )
        return False
    if count != 1:
        raise RuntimeError(f"Expected one explore_weight: 0.25 entry in {path}, found {count}; not changed")
    if dry_run:
        print(f"[dry-run] would set explore_weight={weight:g} in {path}")
        return True
    backup_path = backup(path)
    path.write_text(updated, encoding="utf-8")
    print(f"[updated] explore_weight={weight:g} in {path}")
    print(f"[backup]  {backup_path}")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env", help="Path to red_gym_env_v2.py")
    parser.add_argument("--trainer", help="Path to baseline_run_paralell.py or baseline_fast_v2.py")
    parser.add_argument("--explore-weight", type=float, default=2.0)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--env-only", action="store_true", help="Do not try to edit the trainer config")
    args = parser.parse_args()

    if args.explore_weight <= 0:
        parser.error("--explore-weight must be greater than zero")

    here = Path(__file__).resolve().parent
    cwd = Path.cwd()
    env_path = resolve_path(
        args.env,
        [cwd / "red_gym_env_v2.py", cwd / "v2" / "red_gym_env_v2.py", here / "red_gym_env_v2.py"],
        "Environment",
    )
    if env_path is None:
        raise FileNotFoundError("Could not locate red_gym_env_v2.py; pass --env /path/to/red_gym_env_v2.py")

    patch_environment(env_path, args.dry_run)

    if not args.env_only:
        trainer_path = resolve_path(
            args.trainer,
            [
                cwd / "baseline_run_paralell.py",
                cwd / "baseline_fast_v2.py",
                cwd / "v2" / "baseline_run_paralell.py",
                cwd / "v2" / "baseline_fast_v2.py",
                here / "baseline_run_paralell.py",
                here / "baseline_fast_v2.py",
            ],
            "Trainer",
        )
        if trainer_path is None:
            print(
                "[manual config needed] Trainer not found. In your training script's "
                f"env_config, set 'explore_weight': {args.explore_weight:g}."
            )
        else:
            patch_trainer(trainer_path, args.explore_weight, args.dry_run)

    if args.dry_run:
        print("Dry run complete; no files were written.")
    else:
        print("Patch complete. Observation/action shapes and PPO policy architecture are unchanged.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
