# Pokémon Red v2 — faster exploration patch

This patch is for the `working/v2-latest-tested-2026-11-14` v2 snapshot.
It keeps PPO, the observation dictionary, action space, and emulator action timing unchanged.

## What changes

1. Exploration novelty is rewarded across a worker's lifetime, rather than restarting the novelty counter every episode. `seen_coords` remains episode-local for diagnostics and maps.
2. Story-map progress is rewarded using the worker's lifetime best map rank, so re-entering the same early maps after each reset does not repeatedly earn the same milestone reward.
3. The trainer's explicit `explore_weight: 0.25` is raised to `2.0` (8×). With `reward_scale=0.5`, a newly discovered tile changes the exploration potential by `0.1` instead of `0.0125`.

The environment's lifetime sets are in-memory and reset when the training process starts. They persist through ordinary Gymnasium episode resets within that training run.

## Apply from your v2 directory

Stop the current training process with `Ctrl+C`. Do not delete, rename, or overwrite any `runs/` directory or checkpoint.

Extract this ZIP into:

`/path/to/external-drive/Projects/PokemonRedExperiments/v2`

Then from the `v2` directory, use fish or bash:

```bash
python pokemon_exploration_speed_patch/apply_exploration_speed_patch.py --dry-run
python pokemon_exploration_speed_patch/apply_exploration_speed_patch.py
python -m py_compile red_gym_env_v2.py baseline_run_paralell.py
```

The patcher makes timestamp-safe `.bak` copies before changing either file. It will patch `baseline_run_paralell.py` if present, otherwise `baseline_fast_v2.py`. It only changes the trainer setting when it finds exactly one explicit `explore_weight: 0.25` entry.

If your trainer file has a different config format, manually set this inside its `env_config` dictionary:

```python
'explore_weight': 2.0,
```

Keep `reward_scale` at its current value for this first test. Do not change `action_freq`, PPO hyperparameters, policy architecture, or observation fields at the same time.

## Resume

Resume from the same best checkpoint you were already using, with the same resume command and arguments. This patch does not create a new model or require deleting old checkpoints. Keep the old checkpoint untouched; loading it with this patch is structurally compatible because the observation and action spaces are unchanged. The reward function is different, so allow the value function some time to adapt.

## What to watch in TensorBoard

- `trajectory/explore_sum`: should fill in new areas over time.
- `progress/current_episode_seen_tiles_mean`: should rise within active episodes. The current callback does not log a lifetime-tile scalar, so use the cumulative map for across-episode coverage.
- `progress/best_ever_map_progress`: should move beyond 5 (Viridian Forest).
- `progress/current_map_progress_mean`: should rise, but it can fluctuate as workers explore different areas.

This is a focused first change. If the map remains stuck, inspect a short rollout and the action/coordinate trace before increasing novelty further; excessively strong intrinsic reward can make an agent wander instead of completing story objectives.
