#!/usr/bin/env python3
"""Install directional Pokémon Red progression shaping towards Vermilion Gym.

Run from the user's v2 project directory. The installer modifies only
red_gym_env_v2.py and tensorboard_callback.py, creates timestamped backups,
and refuses partial/incompatible installations.
"""
from __future__ import annotations

import argparse
import ast
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

TARGET_GYM_MAP_ID = 92
PROGRESSION_MAPS = [
    40, 0, 12, 1, 13, 51, 2, 54, 14, 59, 60, 61, 15, 3, 65,
    # Pewter/Cerulean onward toward Vermilion: Route 5, underground path,
    # Route 6, Vermilion, S.S. Anne, then Vermilion Gym.
    35, 36, 88, 62,  # Nugget Bridge/Route 24, Route 25, Bill's house, Rocket-robbed house
    16, 70, 71, 119, 74, 73, 17, 5, 94,
    95, 96, 97, 98, 99, 100, 101, 102, 103, 104,
    TARGET_GYM_MAP_ID,
]

ENV_ATTRS = '''        # Directional navigation memory persists across this worker's episode resets.
        self.lifetime_seen_maps = getattr(self, "lifetime_seen_maps", set())
        self.lifetime_map_transitions = set()
        self.lifetime_forward_transitions = set()
        self._map_transition_counts = {}
        self._last_transition_map_id = None
        self.steps_since_progress = 0
        self.stagnation_reset_count = 0
'''

ENV_METHODS = '''
    def _get_v3_transition_repeat_count(self):
        """Count repeated traversals of already-known directed map edges."""
        return int(sum(max(0, int(count) - 1) for count in self._map_transition_counts.values()))

    def _v3_update_navigation_progress(self, new_episode_tile=False):
        """Track directed map transitions and reset workers that truly stagnate.

        Progress is any newly explored episode tile, first-time directed map
        edge, newly set event flag, or higher story-map milestone. Battle frames
        do not accumulate stagnation time.
        """
        current_map = int(self.read_m(0xD35E))
        self.lifetime_seen_maps.add(current_map)
        previous_map = self._last_transition_map_id
        new_edge = False
        if previous_map is not None and int(previous_map) != current_map:
            edge = (int(previous_map), current_map)
            if edge not in self.lifetime_map_transitions:
                self.lifetime_map_transitions.add(edge)
                new_edge = True
            self._map_transition_counts[edge] = int(self._map_transition_counts.get(edge, 0)) + 1
            previous_rank = int(self.get_map_progress(int(previous_map)))
            current_rank = int(self.get_map_progress(current_map))
            if current_rank >= 0 and current_rank > previous_rank:
                self.lifetime_forward_transitions.add(edge)
            self._last_transition_map_id = current_map
        elif previous_map is None:
            self._last_transition_map_id = current_map

        event_progress = int(self.get_all_events_reward())
        progress_rank = int(getattr(self, "max_map_progress", -1))
        event_changed = event_progress > int(getattr(self, "_v3_last_event_progress", event_progress))
        rank_changed = progress_rank > int(getattr(self, "_v3_last_progress_rank", progress_rank))
        made_progress = bool(new_episode_tile or new_edge or event_changed or rank_changed)

        in_battle = bool(self.read_m(0xD057))
        if made_progress:
            self.steps_since_progress = 0
        elif not in_battle:
            self.steps_since_progress = int(getattr(self, "steps_since_progress", 0)) + 1

        self._v3_last_event_progress = event_progress
        self._v3_last_progress_rank = max(
            progress_rank, int(getattr(self, "_v3_last_progress_rank", progress_rank))
        )

        threshold = int(self.stagnation_reset_steps)
        min_age = int(self.stagnation_min_steps)
        should_reset = (
            threshold > 0
            and int(getattr(self, "step_count", 0)) >= min_age
            and self.steps_since_progress >= threshold
            and not in_battle
        )
        if should_reset:
            self.stagnation_reset_count = int(getattr(self, "stagnation_reset_count", 0)) + 1
        return bool(should_reset)
'''

CALLBACK_METHODS = '''
    def _log_v3_navigation_metrics(self, infos):
        """Log route exploration and stagnation diagnostics at scalar cadence."""
        if self.logger is None:
            return
        last = int(getattr(self, "_last_v3_navigation_log_timestep", 0))
        if self.num_timesteps - last < self.scalar_log_every:
            return
        self._last_v3_navigation_log_timestep = int(self.num_timesteps)
        specs = (
            ("lifetime_unique_maps", "progress/lifetime_unique_maps_mean"),
            ("lifetime_unique_transitions", "progress/lifetime_unique_transitions_mean"),
            ("lifetime_forward_transitions", "progress/lifetime_forward_transitions_mean"),
            ("transition_repeat_count", "progress/transition_repeat_count_mean"),
            ("steps_since_progress", "progress/steps_since_progress_mean"),
            ("stagnation_reset_count", "progress/stagnation_reset_count_mean"),
            ("stagnation_reset", "progress/stagnation_reset_rate"),
        )
        for key, tag in specs:
            values = [
                float(info[key]) for info in infos
                if isinstance(info, dict) and isinstance(info.get(key), (int, float, np.number))
            ]
            if values:
                self.logger.record(tag, float(np.mean(values)))
        goal_values = [
            int(info.get("vermilion_gym_reached", 0))
            for info in infos if isinstance(info, dict)
        ]
        if goal_values:
            self.logger.record("progress/vermilion_gym_reached", float(max(goal_values)))
            self.logger.record("progress/vermilion_gym_reached_workers", float(sum(goal_values)))

    def _log_v3_live_party_and_files(self):
        """Refresh the live party image and write PNG/JSON dashboard files."""
        if self.training_env is None or self.logger is None:
            return
        try:
            parties = self.training_env.env_method("read_party_snapshot")
            best_progress = self.training_env.get_attr("best_map_progress")
            best_map_ids = self.training_env.get_attr("best_map_id")
            current_progress = self.training_env.get_attr("max_map_progress")
            current_maps = self.training_env.env_method("get_game_coords")
            badges = self.training_env.env_method("get_badges")
            dex = self.training_env.env_method("read_pokedex_owned_count")
            captures = self.training_env.get_attr("capture_count")
            if not parties:
                return
            count = min(len(parties), len(best_progress), len(current_progress))
            worker = max(
                range(count),
                key=lambda i: (
                    int(best_progress[i]), int(current_progress[i]), len(parties[i] or [])
                ),
            )
            party = parties[worker] if isinstance(parties[worker], (list, tuple)) else []
            coords = current_maps[worker] if worker < len(current_maps) else (0, 0, -1)
            current_map_id = int(coords[2]) if isinstance(coords, (list, tuple)) and len(coords) >= 3 else -1
            meta = {
                "worker_index": int(worker),
                "timestep": int(self.num_timesteps),
                "best_map_progress": int(best_progress[worker]),
                "best_map_id": int(best_map_ids[worker]),
                "map_progress": int(current_progress[worker]),
                "map_id": current_map_id,
                "badges": int(badges[worker]) if worker < len(badges) else 0,
                "pokedex_owned": int(dex[worker]) if worker < len(dex) else 0,
                "captures": int(captures[worker]) if worker < len(captures) else 0,
                "party_size": int(len(party)),
            }
            live_board = self._render_party_board(party, worker, int(self.num_timesteps), progress_meta=meta)
            self.logger.record(
                "game/party_visual/env", Image(live_board, "HWC"),
                exclude=("stdout", "log", "json", "csv"),
            )

            out_dir = self.log_dir / "party_visual"
            out_dir.mkdir(parents=True, exist_ok=True)
            live_tmp = out_dir / "env.png.tmp"
            PILImage.fromarray(live_board).save(live_tmp, format="PNG")
            os.replace(live_tmp, out_dir / "env.png")

            most_meta = None
            if isinstance(self.best_party_record, dict):
                record = self.best_party_record
                most_party = record.get("party_snapshot", [])
                if isinstance(most_party, (list, tuple)):
                    most_board = self._render_party_board(
                        most_party, int(record.get("worker_index", -1)),
                        int(record.get("timestep", self.num_timesteps)), progress_meta=record,
                    )
                    most_tmp = out_dir / "most_advanced.png.tmp"
                    PILImage.fromarray(most_board).save(most_tmp, format="PNG")
                    os.replace(most_tmp, out_dir / "most_advanced.png")
                most_meta = {
                    "worker_index": int(record.get("worker_index", -1)),
                    "timestep": int(record.get("timestep", 0)),
                    "best_map_progress": int(record.get("best_map_progress", -1)),
                    "best_map_id": int(record.get("best_map_id", -1)),
                    "party_size": int(record.get("party_size", 0)),
                }
            metadata = {"updated_timestep": int(self.num_timesteps), "live": meta, "most_advanced": most_meta}
            meta_tmp = out_dir / "metadata.json.tmp"
            meta_tmp.write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")
            os.replace(meta_tmp, out_dir / "metadata.json")
        except Exception as exc:
            self._warn(f"Could not refresh live party dashboard ({exc}).")
'''


def _replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"Expected exactly one {label} anchor, found {count}.")
    return text.replace(old, new, 1)


def patch_env(source: str) -> str:
    if "def _v3_update_navigation_progress(" in source:
        return source
    if "class RedGymEnv" not in source:
        raise RuntimeError("red_gym_env_v2.py does not contain class RedGymEnv.")
    if "self.essential_map_locations =" not in source:
        raise RuntimeError("Could not find essential_map_locations progression table.")

    # Add reward configuration.
    config_anchor = '        self.map_progress_weight = float(config.get("map_progress_weight", 5.0))\n'
    if config_anchor not in source:
        raise RuntimeError("Could not find map_progress_weight configuration anchor.")
    config_block = config_anchor + '''        # Navigation shaping toward Vermilion Gym (map ID 92).
        self.map_transition_weight = float(config.get("map_transition_weight", 3.0))
        self.forward_transition_weight = float(config.get("forward_transition_weight", 8.0))
        self.transition_repeat_penalty_weight = float(config.get("transition_repeat_penalty_weight", 0.08))
        self.vermilion_goal_reward_weight = float(config.get("vermilion_goal_reward_weight", 20.0))
        self.stagnation_reset_steps = int(config.get("stagnation_reset_steps", 12288))
        self.stagnation_min_steps = int(config.get("stagnation_min_steps", 4096))
'''
    source = _replace_once(source, config_anchor, config_block, "reward configuration")

    # Lifetime navigation trackers.
    tracker_anchor = '        self.lifetime_seen_coords = set()\n'
    if tracker_anchor not in source:
        raise RuntimeError("Could not find lifetime_seen_coords tracker anchor.")
    source = _replace_once(source, tracker_anchor, tracker_anchor + ENV_ATTRS, "lifetime navigation trackers")

    # Extend progression milestones to Vermilion Gym. Accept spacing differences.
    pattern = re.compile(
        r'enumerate\(\[\s*40\s*,\s*0\s*,\s*12\s*,\s*1\s*,\s*13\s*,\s*51\s*,\s*2\s*,\s*54\s*,\s*14\s*,\s*59\s*,\s*60\s*,\s*61\s*,\s*15\s*,\s*3\s*,\s*65\s*\]\s*\)'
    )
    replacement = "enumerate(" + repr(PROGRESSION_MAPS) + ")"
    source, count = pattern.subn(replacement, source, count=1)
    if count != 1:
        raise RuntimeError("Could not identify the original 15-map story progression list.")

    # Reset episode-local stagnation clocks after the initial map has been recorded.
    reset_start = source.find("    def reset(")
    step_start = source.find("    def step(", reset_start)
    if reset_start < 0 or step_start < 0:
        raise RuntimeError("Could not locate reset()/step() methods.")
    reset_block = source[reset_start:step_start]
    reset_anchor = "        self.update_map_progress()\n"
    if reset_anchor not in reset_block:
        raise RuntimeError("Could not find reset's initial update_map_progress() call.")
    reset_block = _replace_once(
        reset_block, reset_anchor,
        reset_anchor + '''        self._last_transition_map_id = int(self.read_m(0xD35E))
        self.lifetime_seen_maps.add(self._last_transition_map_id)
        self.steps_since_progress = 0
        self._v3_last_event_progress = int(self.get_all_events_reward())
        self._v3_last_progress_rank = int(self.max_map_progress)
''',
        "reset navigation baseline",
    )
    source = source[:reset_start] + reset_block + source[step_start:]

    # Modify the step method only.
    step_start = source.find("    def step(")
    action_start = source.find("    def run_action_on_emulator(", step_start)
    if step_start < 0 or action_start < 0:
        raise RuntimeError("Could not isolate step() method.")
    step_block = source[step_start:action_start]
    seen_anchor = "        self.update_seen_coords()\n"
    if seen_anchor not in step_block:
        raise RuntimeError("Could not find step's update_seen_coords() call.")
    step_block = _replace_once(
        step_block, seen_anchor,
        "        _v3_seen_before = len(self.seen_coords)\n"
        + seen_anchor
        + "        _v3_new_episode_tile = len(self.seen_coords) > _v3_seen_before\n",
        "step tile novelty",
    )
    progress_anchor = "        self.update_map_progress()\n"
    if progress_anchor not in step_block:
        raise RuntimeError("Could not find step's update_map_progress() call.")
    step_block = _replace_once(
        step_block, progress_anchor,
        progress_anchor + "        _v3_stagnation_reset = self._v3_update_navigation_progress(_v3_new_episode_tile)\n",
        "step navigation tracker",
    )
    done_anchor = "        step_limit_reached = self.check_if_done()\n"
    if done_anchor not in step_block:
        raise RuntimeError("Could not find step_limit_reached assignment.")
    step_block = _replace_once(
        step_block, done_anchor,
        "        step_limit_reached = self.check_if_done() or _v3_stagnation_reset\n",
        "selective stagnation reset",
    )

    info_anchor = '            "map_id": int(current_map),\n'
    if info_anchor not in step_block:
        raise RuntimeError("Could not find map_id in the step info/snapshot payload.")
    extra_info = '''            "lifetime_unique_maps": int(len(self.lifetime_seen_maps)),
            "lifetime_unique_transitions": int(len(self.lifetime_map_transitions)),
            "lifetime_forward_transitions": int(len(self.lifetime_forward_transitions)),
            "transition_repeat_count": int(self._get_v3_transition_repeat_count()),
            "steps_since_progress": int(self.steps_since_progress),
            "stagnation_reset": int(_v3_stagnation_reset),
            "stagnation_reset_count": int(self.stagnation_reset_count),
            "vermilion_gym_reached": int(92 in self.lifetime_seen_maps),
'''
    step_block = step_block.replace(info_anchor, info_anchor + extra_info)
    source = source[:step_start] + step_block + source[action_start:]

    # New cumulative potentials are emitted as deltas by the existing update_reward().
    reward_anchor = "        state_scores = {\n"
    if reward_anchor not in source:
        raise RuntimeError("Could not find state_scores reward dictionary.")
    reward_terms = '''        state_scores = {
            "new_directed_transitions": (
                self.reward_scale * self.map_transition_weight * len(self.lifetime_map_transitions)
            ),
            "new_forward_transitions": (
                self.reward_scale * self.forward_transition_weight * len(self.lifetime_forward_transitions)
            ),
            "repeated_transition_penalty": (
                -self.reward_scale * self.transition_repeat_penalty_weight
                * self._get_v3_transition_repeat_count()
            ),
            "vermilion_gym_goal": (
                self.reward_scale * self.vermilion_goal_reward_weight
                * int(92 in self.lifetime_seen_maps)
            ),
'''
    source = _replace_once(source, reward_anchor, reward_terms, "navigation reward terms")

    # Add tracker methods immediately before update_map_progress().
    method_anchor = "    def update_map_progress(self):\n"
    if method_anchor not in source:
        raise RuntimeError("Could not find update_map_progress() method anchor.")
    source = _replace_once(source, method_anchor, ENV_METHODS + "\n" + method_anchor, "navigation tracker methods")

    ast.parse(source)
    return source


def patch_callback(source: str) -> str:
    if "def _log_v3_navigation_metrics(" in source:
        return source
    if "class TensorboardCallback" not in source:
        raise RuntimeError("tensorboard_callback.py does not contain class TensorboardCallback.")
    # Refresh visual tags more frequently.
    source = source.replace("party_image_every=40960,", "party_image_every=8192,", 1)

    # Add diagnostics and live dashboard methods before _on_step.
    on_step_anchor = "    def _on_step(self) -> bool:\n"
    if on_step_anchor not in source:
        raise RuntimeError("Could not find TensorboardCallback._on_step().")
    source = _replace_once(source, on_step_anchor, CALLBACK_METHODS + "\n" + on_step_anchor, "callback navigation/dashboard methods")

    # Call navigation diagnostics from every callback step (method enforces its own cadence).
    log_anchor = "        self._log_progress_scalars(infos)\n"
    if log_anchor not in source:
        raise RuntimeError("Could not find _log_progress_scalars(infos) call.")
    source = _replace_once(source, log_anchor, log_anchor + "        self._log_v3_navigation_metrics(infos)\n", "navigation diagnostics call")

    # Replace the single env tag with a fresh live snapshot after the saved best-party snapshot.
    party_anchor = "            self._log_party_images()\n            self._last_party_image_timestep = int(self.num_timesteps)\n"
    if party_anchor not in source:
        raise RuntimeError("Could not find periodic party image refresh block.")
    source = _replace_once(
        source, party_anchor,
        "            self._log_party_images()\n"
        "            self._log_v3_live_party_and_files()\n"
        "            self._last_party_image_timestep = int(self.num_timesteps)\n",
        "live party refresh call",
    )

    # Write an initial snapshot too, so the files exist at startup.
    startup_anchor = "        initial_count = self._log_party_images()\n"
    if startup_anchor in source:
        source = _replace_once(
            source, startup_anchor,
            startup_anchor + "        self._log_v3_live_party_and_files()\n",
            "initial live party refresh",
        )
    ast.parse(source)
    return source


def install(project_dir: Path, dry_run: bool = False) -> list[tuple[Path, Path]]:
    targets = [
        (project_dir / "red_gym_env_v2.py", patch_env),
        (project_dir / "tensorboard_callback.py", patch_callback),
    ]
    staged: list[tuple[Path, str]] = []
    for path, patcher in targets:
        if not path.is_file():
            raise FileNotFoundError(f"Required file not found: {path}")
        original = path.read_text(encoding="utf-8")
        updated = patcher(original)
        ast.parse(updated)
        staged.append((path, updated))

    if dry_run:
        for path, _ in staged:
            print(f"Would update: {path}")
        print("Dry run passed. No files changed.")
        return []

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backups: list[tuple[Path, Path]] = []
    # Back up all originals before writing either file.
    for path, _ in staged:
        backup = path.with_name(f"{path.name}.before_vermilion_{timestamp}")
        if backup.exists():
            raise FileExistsError(f"Refusing to overwrite backup: {backup}")
        shutil.copy2(path, backup)
        backups.append((path, backup))

    try:
        for path, updated in staged:
            temp = path.with_suffix(path.suffix + ".vermilion.tmp")
            temp.write_text(updated, encoding="utf-8")
            os.replace(temp, path)
    except Exception:
        # Restore all source files if a write fails part-way through.
        for path, backup in backups:
            shutil.copy2(backup, path)
        raise

    for path, backup in backups:
        print(f"Patched: {path}")
        print(f"Backup:  {backup}")
    return backups


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-dir", type=Path, default=Path.cwd())
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    try:
        install(args.project_dir.expanduser().resolve(), dry_run=args.dry_run)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
