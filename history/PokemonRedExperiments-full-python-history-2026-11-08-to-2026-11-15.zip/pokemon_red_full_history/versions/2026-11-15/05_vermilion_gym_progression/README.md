# Pokémon Red V2 — Vermilion Gym Progression Update

This is a reward/navigation update for the existing PPO v2 environment. It does **not** guarantee a Gym clear or replace the PPO agent; it makes reaching Vermilion Gym (map ID 92) an explicit progression target and supplies more useful navigation feedback.

## Changes

- Extends the story-map progress ladder from the existing Cerulean Gym milestone through Route 24, Route 25, Bill's house, the Rocket-robbed house exit, Route 5, the Route 5–6 Underground Path, Route 6, Vermilion City, S.S. Anne areas, and Vermilion Gym.
- Tracks directed map transitions per worker across episode resets.
- Adds one-time reward for first-time directed transitions and stronger reward for transitions to a higher story-map rank.
- Adds a small cumulative penalty for repeatedly traversing the same directed map edge, allowing the first round-trip while discouraging endless oscillation.
- Rewards entering Vermilion Gym (map 92) as a one-time goal.
- Selectively truncates a worker episode after 12,288 steps without new episode tiles, new event flags, a new directed edge, or improved story-map rank. Stagnation time does not accrue during battles. This makes only the stuck worker reset; the other subprocess workers continue.
- Adds TensorBoard metrics for unique transitions, forward transitions, repeated transitions, time since progress, stagnation resets, and Vermilion Gym reached.
- Refreshes the live party dashboard every 8,192 aggregate timesteps and atomically writes `party_visual/env.png`, `party_visual/most_advanced.png`, and `party_visual/metadata.json` inside the callback's log directory.

The action space, observation keys/shapes, PPO network, and saved model format are unchanged. Existing checkpoints remain structurally loadable, though the value function must adapt to new reward shaping.

## Install

Stop training with Ctrl+C and let the trainer save its interrupted checkpoint. Because your working tree was previously on `master` with local edits, move the current working tree onto a development branch first; this does not discard the uncommitted edits:

```fish
cd "/path/to/external-drive/Projects/PokemonRedExperiments/v2"
git status --short
git switch -c working/vermilion-gym-progression-2026-11-15
```

Then extract and test the package:

```fish
unzip -o ~/Downloads/pokemon_vermilion_gym_progression.zip
python apply_vermilion_progression_patch.py --dry-run
python test_vermilion_progression_patch.py
python apply_vermilion_progression_patch.py
python -m py_compile red_gym_env_v2.py tensorboard_callback.py
```

The progression table uses Generation I map indices: Route 24 is 35, Route 25 is 36, Bill's house is 88, Vermilion City is 5, and Vermilion Gym is 92. The explicit target is entering map 92.

The installer creates timestamped backups before changing either source file. It stages both patches and restores backups if a write fails. It refuses to proceed if expected code anchors are not found.

## Resume

Resume using the same existing PPO checkpoint and existing session directory/configuration. Do not delete or rename any runs or checkpoints. Start with the same 30 workers; benchmark worker count later, separately.

## Important limits

This update increases the learning signal for the route to Vermilion, but reinforcement learning is stochastic. It cannot honestly guarantee that the agent will reach or defeat Lt. Surge within a fixed number of timesteps. Reaching map 92 is the logged target; beating the Gym Leader is a separate battle objective that would need its own success signal.

## Verification

The package tests patching/idempotence, progression ordering, map-edge reward tracking, repeated-edge counting, stagnation handling, and battle exemption. They do not replace a live PyBoy/ROM smoke test on the user's machine.
