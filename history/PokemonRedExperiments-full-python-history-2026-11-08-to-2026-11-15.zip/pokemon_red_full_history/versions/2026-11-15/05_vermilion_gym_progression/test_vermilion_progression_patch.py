from __future__ import annotations

import ast
import sys
from pathlib import Path

from apply_vermilion_progression_patch import (
    PROGRESSION_MAPS,
    TARGET_GYM_MAP_ID,
    patch_callback,
    patch_env,
)

BASE = Path(__file__).resolve().parent


def _get_method(source: str, name: str):
    tree = ast.parse(source)
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "RedGymEnv")
    node = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == name)
    module = ast.Module(body=[node], type_ignores=[])
    namespace = {}
    exec(compile(module, "<extracted-method>", "exec"), namespace)
    return namespace[name]


def test_patch_is_valid_and_idempotent():
    env_path = Path.cwd() / "red_gym_env_v2.py"
    callback_path = Path.cwd() / "tensorboard_callback.py"
    if env_path.exists():
        first = patch_env(env_path.read_text(encoding="utf-8"))
        ast.parse(first)
        assert patch_env(first) == first
        assert '"vermilion_gym_goal"' in first
        assert '"new_forward_transitions"' in first
        assert "_v3_update_navigation_progress" in first
    if callback_path.exists():
        first_cb = patch_callback(callback_path.read_text(encoding="utf-8"))
        ast.parse(first_cb)
        assert patch_callback(first_cb) == first_cb
        assert "game/party_visual/env" in first_cb
        assert "_log_v3_live_party_and_files" in first_cb
        assert "party_image_every=8192" in first_cb


def test_vermilion_map_order():
    assert PROGRESSION_MAPS[:15] == [40, 0, 12, 1, 13, 51, 2, 54, 14, 59, 60, 61, 15, 3, 65]
    assert PROGRESSION_MAPS.index(35) < PROGRESSION_MAPS.index(36)
    assert PROGRESSION_MAPS.index(36) < PROGRESSION_MAPS.index(88)
    assert PROGRESSION_MAPS.index(88) < PROGRESSION_MAPS.index(16)
    assert PROGRESSION_MAPS.index(16) < PROGRESSION_MAPS.index(17)
    assert PROGRESSION_MAPS.index(17) < PROGRESSION_MAPS.index(5)
    assert PROGRESSION_MAPS.index(5) < PROGRESSION_MAPS.index(TARGET_GYM_MAP_ID)
    assert PROGRESSION_MAPS[-1] == 92


def test_transition_rewards_and_stagnation_reset_logic():
    base = Path.cwd() / "red_gym_env_v2.py"
    if not base.is_file():
        raise FileNotFoundError("Run this test from the v2 project directory containing red_gym_env_v2.py")
    source = patch_env(base.read_text(encoding="utf-8"))
    update = _get_method(source, "_v3_update_navigation_progress")
    repeat = _get_method(source, "_get_v3_transition_repeat_count")
    progress = _get_method(source, "get_map_progress")

    class Dummy:
        essential_map_locations = {map_id: rank for rank, map_id in enumerate(PROGRESSION_MAPS)}
        lifetime_seen_maps = {51}
        lifetime_map_transitions = set()
        lifetime_forward_transitions = set()
        _map_transition_counts = {}
        _last_transition_map_id = 51
        steps_since_progress = 50
        stagnation_reset_count = 0
        stagnation_reset_steps = 3
        stagnation_min_steps = 4
        step_count = 10
        max_map_progress = 6
        _v3_last_event_progress = 0
        _v3_last_progress_rank = 5
        memory = {0xD35E: 2, 0xD057: 0}
        event_progress = 0

        def read_m(self, address):
            return self.memory.get(address, 0)

        def get_all_events_reward(self):
            return self.event_progress

    Dummy.get_map_progress = progress
    Dummy._v3_update_navigation_progress = update
    Dummy._get_v3_transition_repeat_count = repeat

    env = Dummy()
    assert env._v3_update_navigation_progress(False) is False
    assert (51, 2) in env.lifetime_map_transitions
    assert (51, 2) in env.lifetime_forward_transitions
    assert env.steps_since_progress == 0

    # Repeating the same directed edge is counted, while the reverse edge is distinct.
    env.memory[0xD35E] = 51
    env._v3_update_navigation_progress(False)
    env.memory[0xD35E] = 2
    env._v3_update_navigation_progress(False)
    assert env._get_v3_transition_repeat_count() >= 1

    # With no new tiles/events/edges, the worker is stopped after the configured threshold.
    env.memory[0xD35E] = 2
    env.steps_since_progress = 2
    env.step_count = 20
    assert env._v3_update_navigation_progress(False) is True
    assert env.stagnation_reset_count == 1

    # Battle actions never trigger stagnation resets.
    env.memory[0xD057] = 1
    env.steps_since_progress = 100
    assert env._v3_update_navigation_progress(False) is False


def main():
    test_patch_is_valid_and_idempotent()
    test_vermilion_map_order()
    test_transition_rewards_and_stagnation_reset_logic()
    print("PASS test_patch_is_valid_and_idempotent")
    print("PASS test_vermilion_map_order")
    print("PASS test_transition_rewards_and_stagnation_reset_logic")
    print("All Vermilion progression patch tests passed.")


if __name__ == "__main__":
    main()
