#!/usr/bin/env python3
"""Non-destructive source checks for apply_live_party_visual_update.py."""
from __future__ import annotations
import argparse
import importlib.util
from pathlib import Path


def load_patcher(path: Path):
    spec = importlib.util.spec_from_file_location("live_party_patcher", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load patcher: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=Path, default=Path("red_gym_env_v2.py"))
    parser.add_argument("--callback", type=Path, default=Path("tensorboard_callback.py"))
    parser.add_argument("--patcher", type=Path, default=Path("apply_live_party_visual_update.py"))
    args = parser.parse_args()
    module = load_patcher(args.patcher)
    env, env_changes = module.patch_env_source(args.env.read_text(encoding="utf-8"))
    callback, callback_changes = module.patch_callback_source(args.callback.read_text(encoding="utf-8"))
    compile(env, str(args.env), "exec")
    compile(callback, str(args.callback), "exec")
    env_again, env_second_changes = module.patch_env_source(env)
    callback_again, callback_second_changes = module.patch_callback_source(callback)
    assert env_again == env and not env_second_changes, "Environment patch is not idempotent"
    assert callback_again == callback and not callback_second_changes, "Callback patch is not idempotent"
    for token in (
        '"lifetime_seen_maps": len(self.lifetime_seen_maps)',
        '"map_novelty_score":',
    ):
        assert token in env, f"Missing env telemetry: {token}"
    for token in (
        "party_image_every=8192,",
        '"game/party_visual/env", Image(live_board',
        '"game/party_visual/most_advanced", Image(best_board',
        'self._write_party_visual_file("env.png", live_board)',
        '"progress/lifetime_unique_maps_mean"',
    ):
        assert token in callback, f"Missing callback feature: {token}"
    print("PASS: both files compile after patch")
    print("PASS: patch is idempotent")
    print("PASS: lifetime map telemetry is exposed")
    print("PASS: live and historical party dashboards are separate")
    print("PASS: atomic PNG output is enabled")
    print(f"Environment updates to apply: {len(env_changes)}")
    print(f"Callback updates to apply: {len(callback_changes)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
