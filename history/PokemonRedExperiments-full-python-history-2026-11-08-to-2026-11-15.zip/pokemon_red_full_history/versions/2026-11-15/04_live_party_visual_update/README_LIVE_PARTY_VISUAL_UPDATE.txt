Pokémon Red v2 — live party dashboard + navigation telemetry

This update edits your existing files in place. It does not replace the PPO model,
observations, action space, ROM, checkpoints, run directories, or training history.

WHAT CHANGES
- game/party_visual/env becomes a live view of the currently active party on the
  selected highest-progress worker, refreshed every 8,192 aggregate environment
  timesteps (instead of the old 40,960 default).
- game/party_visual/most_advanced remains a separate historical-best party view.
- The callback also overwrites PNG files atomically while training:
    <callback log_dir>/party_visual/env.png
    <callback log_dir>/party_visual/most_advanced.png
    <callback log_dir>/party_visual/metadata.json
- TensorBoard navigation scalars are added:
    progress/lifetime_unique_tiles_mean
    progress/lifetime_unique_maps_mean
    rewards/map_novelty_score_mean
- The environment exposes lifetime map count and map novelty potential in its
  info dictionaries. The map novelty reward and lifetime tile reward are kept.

INSTALL (CachyOS / fish)
1. Stop training cleanly with Ctrl+C and let the model save.
2. Change into your v2 project directory:

   cd "/path/to/external-drive/Projects/PokemonRedExperiments/v2"

3. Unzip this archive into that directory. The script is at the archive root:

   unzip -o ~/Downloads/pokemon_live_party_visual_update.zip

4. Preview the changes and run the non-destructive source checks:

   python apply_live_party_visual_update.py --dry-run
   python test_live_party_visual_update.py

5. Apply them:

   python apply_live_party_visual_update.py

6. Check syntax:

   python -m py_compile red_gym_env_v2.py tensorboard_callback.py

BACKUPS
The installer creates these before replacing either file:
- red_gym_env_v2.py.before_live_party_visual
- tensorboard_callback.py.before_live_party_visual

If either backup already exists, the installer stops before changing any file.
It also validates both new source files before writing them. Keep the backups.

RESUME
Resume using your existing checkpoint and the same trainer command. Do not create
a new run or delete any existing checkpoint or TensorBoard data.

NOTES
- The live env image follows the worker selected by the callback's historical
  progression ranking. If that worker resets, env.png shows its current team;
  most_advanced.png retains the previously saved best team.
- The PNGs are written under the TensorboardCallback log_dir. TensorBoard image
  events are recorded at the same refresh cadence and become visible on the
  next normal SB3 logger dump.
- This is a source-level update; perform one short local run and verify that the
  two PNGs and TensorBoard tags are being refreshed before leaving long training.
