#!/usr/bin/env python3
"""Safely update the Pokémon Red v2 environment telemetry and party dashboard.

Run from the v2 project directory. Creates backups before modifying either file.
"""
from __future__ import annotations

import argparse
import re
import shutil
from pathlib import Path


def _replace_once(source: str, old: str, new: str, label: str) -> tuple[str, bool]:
    count = source.count(old)
    if count == 0:
        return source, False
    if count != 1:
        raise ValueError(f"Expected one occurrence for {label}; found {count}. Refusing to guess.")
    return source.replace(old, new, 1), True


def patch_env_source(source: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    if "self.lifetime_seen_maps = set()" not in source:
        source, ok = _replace_once(
            source,
            "self.lifetime_seen_coords = set()",
            "self.lifetime_seen_coords = set()\n        self.lifetime_seen_maps = set()",
            "lifetime map set",
        )
        if not ok:
            raise ValueError("Could not find lifetime_seen_coords initialization in red_gym_env_v2.py")
        changes.append("Added lifetime map tracking")

    if "self.lifetime_seen_maps.add(map_idx)" not in source:
        pattern = r"(    def update_map_progress\(self\):\n(?:        .*\n)*?        map_idx = int\(self\.read_m\(0xD35E\)\)\n)"
        source, count = re.subn(pattern, r"\1        self.lifetime_seen_maps.add(map_idx)\n", source, count=1)
        if count != 1:
            raise ValueError("Could not safely add lifetime map tracking in update_map_progress()")
        changes.append("Record each map only once per worker lifetime")

    if "self.map_novelty_weight" not in source:
        anchor = 'self.stuck_penalty_weight = float(config.get("stuck_penalty_weight", 1.0))'
        source, ok = _replace_once(
            source, anchor,
            anchor + '\n        self.map_novelty_weight = float(config.get("map_novelty_weight", 2.0))',
            "map novelty setting",
        )
        if not ok:
            raise ValueError("Could not find stuck_penalty_weight config in red_gym_env_v2.py")
        changes.append("Added configurable map novelty weight")

    if '"map_novelty"' not in source:
        pattern = r'("map_progress"\s*:\s*\(\s*\n\s*self\.reward_scale\s*\*\s*self\.map_progress_weight\s*\*\s*self\.max_map_progress\s*\n\s*\),)'
        source, count = re.subn(
            pattern,
            r'\1\n            "map_novelty": (\n                self.reward_scale * self.map_novelty_weight * len(self.lifetime_seen_maps)\n            ),',
            source,
            count=1,
        )
        if count != 1:
            raise ValueError("Could not safely add map_novelty reward to state_scores")
        changes.append("Added one-time lifetime map-discovery reward")

    # Keep the observation/action contract unchanged; expose telemetry through info only.
    step_anchor = '"lifetime_seen_tiles": len(self.lifetime_seen_coords),'
    step_add = (
        step_anchor + '\n'
        '            "lifetime_seen_maps": len(self.lifetime_seen_maps),\n'
        '            "map_novelty_score": float(self.reward_scale * self.map_novelty_weight * len(self.lifetime_seen_maps)),'
    )
    if '"lifetime_seen_maps": len(self.lifetime_seen_maps)' not in source:
        source, ok = _replace_once(source, step_anchor, step_add, "step info lifetime map telemetry")
        if not ok:
            raise ValueError("Could not find step info lifetime_seen_tiles field")
        changes.append("Expose lifetime map count and novelty score in step info")

    terminal_anchor = '"lifetime_seen_tiles": int(len(self.lifetime_seen_coords)),'
    terminal_add = (
        terminal_anchor + '\n'
        '                "lifetime_seen_maps": int(len(self.lifetime_seen_maps)),\n'
        '                "map_novelty_score": float(self.reward_scale * self.map_novelty_weight * len(self.lifetime_seen_maps)),'
    )
    if '"lifetime_seen_maps": int(len(self.lifetime_seen_maps))' not in source:
        source, ok = _replace_once(source, terminal_anchor, terminal_add, "terminal snapshot lifetime map telemetry")
        if not ok:
            raise ValueError("Could not find terminal snapshot lifetime_seen_tiles field")
        changes.append("Expose lifetime map telemetry in terminal snapshots")

    # Ensure the exploration potential cannot accidentally revert to episode-only novelty.
    source, count = re.subn(
        r'("explore"\s*:\s*[^\n]*len\()self\.seen_coords(\)\s*\*\s*0\.1)',
        r'\1self.lifetime_seen_coords\2',
        source,
        count=1,
    )
    if count:
        changes.append("Use lifetime unique tiles for exploration reward")

    if '"explore":' in source and 'len(self.lifetime_seen_coords)' not in source:
        raise ValueError("Explore reward exists but lifetime tile reward could not be verified")

    return source, changes


LIVE_PARTY_HELPERS = '''    def _safe_live_env_method(self, method_name, worker_index, default=None):
        """Read one value from one live VecEnv worker without breaking training."""
        try:
            values = self.training_env.env_method(method_name, indices=[int(worker_index)])
            return values[0] if values else default
        except Exception:
            return default

    def _safe_live_env_attr(self, attr_name, worker_index, default=None):
        """Read one attribute from one live VecEnv worker without breaking training."""
        try:
            values = self.training_env.get_attr(attr_name, indices=[int(worker_index)])
            return values[0] if values else default
        except Exception:
            return default

    def _build_live_party_record(self, worker_index, fallback_record):
        """Build a fresh view of the selected worker while retaining safe fallbacks."""
        live = dict(fallback_record)
        party = self._safe_live_env_method("read_party_snapshot", worker_index)
        if isinstance(party, (list, tuple)):
            live["party_snapshot"] = [dict(mon) if isinstance(mon, dict) else {} for mon in party]
            live["party_size"] = len(party)
            live["party_fill_score"] = min(len(party), 6) / 6.0

        attr_fields = {
            "best_map_progress": "best_map_progress",
            "best_map_id": "best_map_id",
            "map_progress": "max_map_progress",
            "captures": "capture_count",
            "party_level_spread_target": "party_level_tolerance",
        }
        for output_key, attr_name in attr_fields.items():
            value = self._safe_live_env_attr(attr_name, worker_index)
            if value is not None:
                try:
                    live[output_key] = int(value)
                except (TypeError, ValueError):
                    pass

        method_fields = {
            "badges": "get_badges",
            "pokedex_owned": "read_pokedex_owned_count",
            "party_species_count": "read_unique_party_count",
            "party_diversity_score": "get_party_diversity_score",
            "party_level_balance_score": "get_party_level_balance_score",
            "party_level_spread": "get_party_level_spread",
            "party_level_spread_excess": "get_party_level_spread_excess",
            "party_level_spread_within_target": "is_party_level_spread_within_target",
        }
        for output_key, method_name in method_fields.items():
            value = self._safe_live_env_method(method_name, worker_index)
            if value is not None:
                try:
                    live[output_key] = float(value) if "score" in output_key else int(value)
                except (TypeError, ValueError):
                    pass

        coords = self._safe_live_env_method("get_game_coords", worker_index)
        if isinstance(coords, (list, tuple)) and len(coords) >= 3:
            try:
                live["map_id"] = int(coords[2])
            except (TypeError, ValueError):
                pass

        live["worker_index"] = int(worker_index)
        live["timestep"] = int(self.num_timesteps)
        party_now = live.get("party_snapshot", [])
        if isinstance(party_now, (list, tuple)):
            live.update(self._party_level_metrics(party_now, live.get("party_level_spread_target", 10)))
        return live

    def _write_party_visual_file(self, filename, image_array):
        """Atomically replace a current PNG so external viewers never read a partial file."""
        output_dir = self.log_dir / "party_visual"
        output_dir.mkdir(parents=True, exist_ok=True)
        destination = output_dir / filename
        temporary = destination.with_name(destination.stem + ".tmp.png")
        PILImage.fromarray(image_array).save(temporary, format="PNG")
        os.replace(temporary, destination)
        return destination

    def _log_navigation_scalars(self, infos):
        """Log lifetime navigation diagnostics at the normal scalar cadence."""
        last = getattr(self, "_last_navigation_log_timestep", 0)
        if self.num_timesteps - last < self.scalar_log_every:
            return
        self._last_navigation_log_timestep = int(self.num_timesteps)
        fields = (
            ("progress/lifetime_unique_tiles_mean", "lifetime_seen_tiles"),
            ("progress/lifetime_unique_maps_mean", "lifetime_seen_maps"),
            ("rewards/map_novelty_score_mean", "map_novelty_score"),
        )
        for tag, key in fields:
            values = [
                float(info[key]) for info in infos
                if isinstance(info, dict) and isinstance(info.get(key), (int, float, np.number))
            ]
            if values:
                self.logger.record(tag, float(np.mean(values)))

'''


def _replace_method(source: str, method_name: str, new_method: str, next_method: str) -> str:
    start_token = f"    def {method_name}(self"
    end_token = f"    def {next_method}(self"
    start = source.find(start_token)
    end = source.find(end_token, start + len(start_token))
    if start < 0 or end < 0:
        raise ValueError(f"Could not locate method block {method_name}() to {next_method}()")
    return source[:start] + new_method.rstrip() + "\n\n" + source[end:]


NEW_LOG_PARTY_IMAGES = '''    def _log_party_images(self):
        """Refresh the live selected worker and separately retain its historical best team."""
        if self.training_env is None or self.logger is None:
            return 0
        if self.best_party_record is None:
            self._prime_best_party_from_envs()
        record = self.best_party_record
        if not isinstance(record, dict):
            return 0

        worker_index = int(record.get("worker_index", -1))
        if worker_index < 0 or worker_index >= int(self.training_env.num_envs):
            return 0

        best_party = record.get("party_snapshot")
        if not isinstance(best_party, (list, tuple)):
            return 0

        # This is the current party of the selected worker. It is intentionally
        # distinct from the persisted historical-best party below.
        live_record = self._build_live_party_record(worker_index, record)
        live_party = live_record.get("party_snapshot", best_party)
        if not isinstance(live_party, (list, tuple)):
            live_party = best_party

        live_board = self._render_party_board(
            live_party, worker_index, int(self.num_timesteps), progress_meta=live_record,
            heading_label="CURRENT LIVE PARTY",
        )
        best_board = self._render_party_board(
            best_party, worker_index, int(record.get("timestep", self.num_timesteps)),
            progress_meta=record, heading_label="HISTORICAL BEST PARTY",
        )

        self.logger.record(
            "game/party_visual/env", Image(live_board, "HWC"),
            exclude=("stdout", "log", "json", "csv"),
        )
        self.logger.record(
            "game/party_visual/most_advanced", Image(best_board, "HWC"),
            exclude=("stdout", "log", "json", "csv"),
        )
        self.logger.record("game/party_visual/env_updated_timestep", float(self.num_timesteps))
        self.logger.record("game/party_visual/env_worker_index", float(worker_index))
        self.logger.record("game/party_visual/env_map_id", float(live_record.get("map_id", -1)))
        self.logger.record("game/party_visual/env_party_size", float(live_record.get("party_size", len(live_party))))
        self.logger.record("progress/most_advanced_worker_index", float(worker_index))
        self.logger.record("progress/most_advanced_map_progress", float(record.get("best_map_progress", -1)))
        self.logger.record("progress/most_advanced_badges", float(record.get("badges", 0)))
        self.logger.record("progress/most_advanced_pokedex_owned", float(record.get("pokedex_owned", 0)))
        self.logger.record("progress/most_advanced_captures", float(record.get("captures", 0)))
        self.logger.record("game/most_advanced_party_size", float(record.get("party_size", len(best_party))))
        self.logger.record("game/most_advanced_party_fill_score", float(record.get("party_fill_score", min(len(best_party), 6) / 6.0)))
        self.logger.record("game/most_advanced_party_diversity_score", float(record.get("party_diversity_score", 0.0)))
        self.logger.record(
            "game/most_advanced_party_level_balance_eligible",
            float(record.get("party_level_balance_eligible", 0)),
            exclude=("stdout", "log"),
        )
        self.logger.record(
            "game/most_advanced_party_level_balance_score",
            float(record.get("party_level_balance_score", 0.0)),
            exclude=("stdout", "log"),
        )
        self.logger.record("game/most_advanced_party_level_spread", float(record.get("party_level_spread", 0)))
        self.logger.record("game/most_advanced_party_level_spread_excess", float(record.get("party_level_spread_excess", 0)))
        self.logger.record("game/most_advanced_party_spread_within_target", float(record.get("party_level_spread_within_target", 0)))

        # A continuously overwritten PNG is useful without opening TensorBoard.
        self._write_party_visual_file("env.png", live_board)
        self._write_party_visual_file("most_advanced.png", best_board)
        metadata = {
            "timestep": int(self.num_timesteps),
            "worker_index": int(worker_index),
            "live_map_id": int(live_record.get("map_id", -1)),
            "live_party_size": int(live_record.get("party_size", len(live_party))),
            "best_map_progress": int(record.get("best_map_progress", -1)),
            "best_map_id": int(record.get("best_map_id", -1)),
            "best_party_size": int(record.get("party_size", len(best_party))),
        }
        output_dir = self.log_dir / "party_visual"
        output_dir.mkdir(parents=True, exist_ok=True)
        temp_meta = output_dir / "metadata.tmp.json"
        temp_meta.write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")
        os.replace(temp_meta, output_dir / "metadata.json")

        self._best_party_dirty = False
        if self.verbose:
            print(
                "[TensorboardCallback] Refreshed live party and historical-best dashboard: "
                f"worker={worker_index}, live_party={len(live_party)}/6, "
                f"best_progress={record.get('best_map_progress')}, "
                f"timestep={self.num_timesteps:,}"
            )
        return 1
'''


def patch_callback_source(source: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    if "party_image_every=8192," not in source:
        source, ok = _replace_once(source, "party_image_every=40960,", "party_image_every=8192,", "party image refresh interval")
        if ok:
            changes.append("Refresh the party dashboard every 8,192 aggregate timesteps")
        elif "party_image_every=" not in source:
            raise ValueError("Callback does not expose party_image_every; this is not the expected callback")

    init_anchor = 'self.best_party_path = self.history_dir / "most_advanced_party.json"'
    init_add = init_anchor + '\n        self.party_visual_dir = self.log_dir / "party_visual"'
    if "self.party_visual_dir = self.log_dir / \"party_visual\"" not in source:
        source, ok = _replace_once(source, init_anchor, init_add, "party visual output directory")
        if not ok:
            raise ValueError("Could not find best_party_path initialization in callback")
        changes.append("Create live party PNG and metadata output paths")

    if "heading_label=None" not in source:
        renderer_old = "    def _render_party_board(cls, party, env_index: int, step: int, progress_meta=None):"
        renderer_new = "    def _render_party_board(cls, party, env_index: int, step: int, progress_meta=None, heading_label=None):"
        source, ok = _replace_once(source, renderer_old, renderer_new, "party renderer heading label")
        if not ok:
            raise ValueError("Could not find _render_party_board() signature")
        heading_old = (
            '        heading = (\n'
            '            f"MOST ADVANCED PARTY  |  WORKER {env_index:02d}"\n'
            '            if progress_meta is not None else f"POKEMON PARTY  |  ENV {env_index:02d}"\n'
            '        )'
        )
        heading_new = (
            '        heading = (\n'
            '            f"{heading_label}  |  WORKER {env_index:02d}"\n'
            '            if heading_label else (\n'
            '                f"MOST ADVANCED PARTY  |  WORKER {env_index:02d}"\n'
            '                if progress_meta is not None else f"POKEMON PARTY  |  ENV {env_index:02d}"\n'
            '            )\n'
            '        )'
        )
        source, ok = _replace_once(source, heading_old, heading_new, "party renderer heading")
        if not ok:
            raise ValueError("Could not update party renderer heading")
        changes.append("Label live and historical party images separately")

    if "def _build_live_party_record(" not in source:
        anchor = "    def _log_party_images(self):"
        source, ok = _replace_once(source, anchor, LIVE_PARTY_HELPERS + anchor, "live party and navigation helpers")
        if not ok:
            raise ValueError("Could not find _log_party_images() in callback")
        changes.append("Add live selected-worker snapshots and lifetime navigation telemetry")

    if '"game/party_visual/env", Image(live_board' not in source:
        source = _replace_method(source, "_log_party_images", NEW_LOG_PARTY_IMAGES, "_update_best_party_from_infos")
        changes.append("Separate continuously refreshed env party image from historical-best image")

    if "self._log_navigation_scalars(infos)" not in source:
        anchor = "        self._log_progress_scalars(infos)"
        source, ok = _replace_once(source, anchor, anchor + "\n        self._log_navigation_scalars(infos)", "navigation telemetry callback")
        if not ok:
            raise ValueError("Could not find _log_progress_scalars(infos) in _on_step()")
        changes.append("Log lifetime tiles, lifetime maps and map-novelty potential")

    # Initialise a separate cadence marker; getattr fallback also keeps older persisted instances safe.
    if "self._last_navigation_log_timestep = 0" not in source:
        anchor = "self._last_scalar_log_timestep = 0"
        source, ok = _replace_once(source, anchor, anchor + "\n        self._last_navigation_log_timestep = 0", "navigation telemetry cadence")
        if not ok:
            raise ValueError("Could not find scalar logging cadence initialization")
        changes.append("Set navigation telemetry logging cadence")

    return source, changes


def patch_file(path: Path, patcher, backup_suffix: str, dry_run: bool) -> list[str]:
    if not path.is_file():
        raise FileNotFoundError(path)
    original = path.read_text(encoding="utf-8")
    updated, changes = patcher(original)
    print(f"\n{path.name}:")
    if not changes:
        print("  Already up to date.")
        return changes
    for change in changes:
        print(f"  - {change}")
    if dry_run:
        print("  Dry run: no changes written.")
        return changes
    backup = path.with_name(path.name + backup_suffix)
    if backup.exists():
        raise FileExistsError(
            f"Backup already exists: {backup}. No file was changed. Move the backup aside manually before retrying."
        )
    shutil.copy2(path, backup)
    temp = path.with_suffix(path.suffix + ".live-party.tmp")
    temp.write_text(updated, encoding="utf-8")
    temp.replace(path)
    print(f"  Patched: {path}")
    print(f"  Backup:  {backup}")
    return changes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env", type=Path, default=Path("red_gym_env_v2.py"))
    parser.add_argument("--callback", type=Path, default=Path("tensorboard_callback.py"))
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    # Build both new sources before writing either file, so an incompatible source
    # cannot leave only half of the requested update applied.
    env_path = args.env.resolve()
    callback_path = args.callback.resolve()
    if not env_path.is_file() or not callback_path.is_file():
        parser.error(f"Expected both files in this directory: {env_path} and {callback_path}")
    env_original = env_path.read_text(encoding="utf-8")
    callback_original = callback_path.read_text(encoding="utf-8")
    env_updated, env_changes = patch_env_source(env_original)
    callback_updated, callback_changes = patch_callback_source(callback_original)

    print("Environment changes:")
    for change in env_changes or ["Already up to date."]:
        print(f"  - {change}")
    print("\nCallback changes:")
    for change in callback_changes or ["Already up to date."]:
        print(f"  - {change}")

    if args.dry_run:
        print("\nDry run only; no files changed.")
        return 0

    targets = ((env_path, env_updated, ".before_live_party_visual"),
               (callback_path, callback_updated, ".before_live_party_visual"))
    backups = []
    for path, _, suffix in targets:
        backup = path.with_name(path.name + suffix)
        if backup.exists():
            raise SystemExit(f"Backup already exists: {backup}\nNo files changed. Move this backup aside manually before retrying.")
        backups.append((path, backup))
    # All backups are created before either live file is replaced.
    for path, backup in backups:
        shutil.copy2(path, backup)
    for path, updated, _ in targets:
        temp = path.with_suffix(path.suffix + ".live-party.tmp")
        temp.write_text(updated, encoding="utf-8")
        temp.replace(path)
        print(f"Patched: {path}")
    for path, backup in backups:
        print(f"Backup:  {backup}")
    print("\nNext: python -m py_compile red_gym_env_v2.py tensorboard_callback.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
