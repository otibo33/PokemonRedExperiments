#!/usr/bin/env python3
"""Safely patch RedGymEnv v2 for persistent tile/map novelty rewards."""
from __future__ import annotations
import argparse
import re
import shutil
from pathlib import Path


def patch_source(source: str) -> tuple[str, list[str]]:
    changes: list[str] = []

    # 1) Persistent map history belongs beside the existing lifetime tile set.
    if "self.lifetime_seen_maps = set()" not in source:
        anchor = "self.lifetime_seen_coords = set()"
        if source.count(anchor) != 1:
            raise ValueError("Could not uniquely find self.lifetime_seen_coords = set(); refusing to guess.")
        source = source.replace(anchor, anchor + "\n        self.lifetime_seen_maps = set()", 1)
        changes.append("Added worker-lifetime map history")

    # 2) Record the map on every progression update (set makes it one-time).
    if "self.lifetime_seen_maps.add(map_idx)" not in source:
        pattern = r"(    def update_map_progress\(self\):\n(?:        .*\n)*?        map_idx = int\(self\.read_m\(0xD35E\)\)\n)"
        source, count = re.subn(pattern, r"\1        self.lifetime_seen_maps.add(map_idx)\n", source, count=1)
        if count != 1:
            raise ValueError("Could not safely locate update_map_progress() map read; refusing to guess.")
        changes.append("Record each newly visited map once across resets")

    # 3) Replace episode-only tile count with worker-lifetime unique tiles.
    explore_pattern = r'("explore"\s*:\s*[^\n]*len\()self\.seen_coords(\)\s*\*\s*0\.1)'
    source, count = re.subn(explore_pattern, r"\1self.lifetime_seen_coords\2", source, count=1)
    if count:
        changes.append("Use lifetime unique tiles for exploration reward")
    elif '"explore":' in source and 'len(self.lifetime_seen_coords)' not in source:
        raise ValueError("Found an explore reward but could not safely identify its tile counter.")

    # 4) Configurable novelty weight.
    if "self.map_novelty_weight" not in source:
        anchor = "self.stuck_penalty_weight = float(config.get(\"stuck_penalty_weight\", 1.0))"
        if source.count(anchor) != 1:
            raise ValueError("Could not uniquely find stuck_penalty_weight config; refusing to guess.")
        source = source.replace(anchor, anchor + "\n        self.map_novelty_weight = float(config.get(\"map_novelty_weight\", 2.0))", 1)
        changes.append("Added configurable map novelty weight (default 2.0)")

    # 5) Add a cumulative potential reward. Its step reward is only paid when
    # the set grows, because update_reward() differences cumulative scores.
    if '"map_novelty"' not in source:
        anchor = r'("map_progress"\s*:\s*\(\s*\n\s*self\.reward_scale\s*\*\s*self\.map_progress_weight\s*\*\s*self\.max_map_progress\s*\n\s*\),)'
        replacement = r'\1\n            "map_novelty": (\n                self.reward_scale * self.map_novelty_weight * len(self.lifetime_seen_maps)\n            ),'
        source, count = re.subn(anchor, replacement, source, count=1)
        if count != 1:
            raise ValueError("Could not safely find the map_progress reward block; refusing to guess.")
        changes.append("Reward first visits to previously unseen maps")

    return source, changes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--file", type=Path, default=Path("red_gym_env_v2.py"))
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    path = args.file.resolve()
    if not path.is_file():
        parser.error(f"Environment file not found: {path}")
    original = path.read_text(encoding="utf-8")
    patched, changes = patch_source(original)
    if not changes:
        print(f"Already patched: {path}")
        return 0
    print("Planned changes:")
    for item in changes:
        print(f"  - {item}")
    if args.dry_run:
        print("Dry run only; no files changed.")
        return 0
    backup = path.with_name(path.name + ".before_directional_exploration")
    if backup.exists():
        raise SystemExit(f"Backup already exists: {backup}\nMove it aside manually before applying again; no files changed.")
    shutil.copy2(path, backup)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(patched, encoding="utf-8")
    temp.replace(path)
    print(f"Patched: {path}")
    print(f"Backup:  {backup}")
    print("Next: python -m py_compile red_gym_env_v2.py")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
