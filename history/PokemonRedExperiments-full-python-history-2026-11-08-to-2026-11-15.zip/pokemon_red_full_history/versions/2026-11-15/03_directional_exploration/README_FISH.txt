POKEMON RED V2 — DIRECTIONAL EXPLORATION PATCH

What it changes:
- Exploration novelty is based on lifetime unique tiles, not episode-only tiles.
- Each worker remembers maps it has visited across automatic episode resets.
- First visits to new maps receive an additional cumulative novelty reward.
- Existing map-progression reward remains unchanged.

It does NOT change PPO, observations, action space, emulator timing, or checkpoint tensor shapes.
It creates a backup beside red_gym_env_v2.py before editing.

IMPORTANT: stop the training process cleanly (Ctrl+C) before applying.

Fish commands:

cd "/path/to/external-drive/Projects/PokemonRedExperiments/v2"
unzip ~/Downloads/pokemon_directional_exploration_patch.zip
python pokemon_directional_exploration_patch/apply_directional_exploration_patch.py --dry-run
python pokemon_directional_exploration_patch/apply_directional_exploration_patch.py
python -m py_compile red_gym_env_v2.py

Then resume using the SAME existing checkpoint and training command. Do not delete or rename runs.

If the dry run says it cannot safely locate an expected section, stop and send the output; do not edit manually or force the patch.
