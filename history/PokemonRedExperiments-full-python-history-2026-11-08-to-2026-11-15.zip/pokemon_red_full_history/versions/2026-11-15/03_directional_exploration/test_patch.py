from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent))
from apply_directional_exploration_patch import patch_source

source = Path('/mnt/data/files/red_gym_env_v2(3).py').read_text()
patched, changes = patch_source(source)
assert 'self.lifetime_seen_maps = set()' in patched
assert 'self.lifetime_seen_maps.add(map_idx)' in patched
assert 'len(self.lifetime_seen_coords)' in patched
assert 'self.map_novelty_weight' in patched
assert '"map_novelty": (' in patched
# Idempotency: applying a second time makes no changes.
patched2, changes2 = patch_source(patched)
assert patched2 == patched and changes2 == []
compile(patched, '<patched red_gym_env_v2.py>', 'exec')
print('PASS: lifetime tile reward, map novelty, syntax, and idempotency')
