"""Unit tests for StagnationResetWrapper; run with python test_stagnation_wrapper.py."""
import unittest
import sys
import types

import numpy as np

# The production project already depends on Gymnasium. This tiny fallback lets
# the watchdog's logic tests run in minimal build environments too.
try:
    import gymnasium as gym
    from gymnasium import spaces
except ImportError:
    gym = types.ModuleType("gymnasium")
    class _Env:
        def reset(self, *, seed=None, options=None):
            return None
    class _Wrapper(_Env):
        def __init__(self, env):
            self.env = env
        def reset(self, **kwargs):
            return self.env.reset(**kwargs)
        def step(self, action):
            return self.env.step(action)
    class _Space:
        def __init__(self, *args, **kwargs):
            pass
    gym.Env = _Env
    gym.Wrapper = _Wrapper
    spaces = types.SimpleNamespace(Box=_Space, Discrete=_Space)
    gym.spaces = spaces
    sys.modules["gymnasium"] = gym

from stagnation_wrapper import StagnationResetWrapper


class FakeEnv(gym.Env):
    observation_space = spaces.Box(0, 1, shape=(1,), dtype=np.float32)
    action_space = spaces.Discrete(2)

    def __init__(self):
        self.pos = (3, 6, 38)
        self.max_map_progress = 0
        self.best_map_progress = 0
        self.badges = 0
        self.dex = 1
        self.events = 0
        self.party = (0x99,)
        self.levels = (5,)
        self.episodes_completed = 0
        self.reset_count = 0
        self.step_count = 0
        self.explore_map = np.zeros((4, 4), dtype=np.uint8)
        self.lifetime_explore_map = np.zeros((4, 4), dtype=np.uint8)
        self.seen_coords = {}
        self.lifetime_seen_coords = set()
        self.agent_stats = []
        self.current_event_flags_set = {}
        self.lifetime_event_flags = {}
        self.capture_count = 0

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self.reset_count += 1
        self.step_count = 0
        return np.zeros(1, dtype=np.float32), {}

    def step(self, action):
        self.step_count += 1
        return np.zeros(1, dtype=np.float32), 0.0, False, False, {}

    def get_game_coords(self):
        return self.pos

    def get_badges(self):
        return self.badges

    def read_pokedex_owned_count(self):
        return self.dex

    def get_all_events_reward(self):
        return self.events

    def read_party_species(self):
        return self.party

    def read_party_snapshot(self):
        return [{"species": "Bulbasaur", "level": self.levels[0]}]

    def update_event_flag_names(self):
        pass


class StagnationWrapperTests(unittest.TestCase):
    def test_stagnant_worker_is_truncated_and_reported(self):
        wrapped = StagnationResetWrapper(FakeEnv(), patience_steps=3, min_episode_steps=0, timeout_penalty=2)
        wrapped.reset()
        for _ in range(2):
            _, reward, terminated, truncated, _ = wrapped.step(0)
            self.assertFalse(terminated)
            self.assertFalse(truncated)
        _, reward, terminated, truncated, info = wrapped.step(0)
        self.assertFalse(terminated)
        self.assertTrue(truncated)
        self.assertAlmostEqual(reward, -2.0)
        self.assertEqual(info["reset_reason"], "stagnation")
        self.assertEqual(info["stagnation_reset"], 1)
        self.assertIn("episode_snapshot", info)
        self.assertEqual(info["episode_snapshot"]["reset_reason"], "stagnation")
        self.assertEqual(info["stagnation_resets_total"], 1)

    def test_new_tile_resets_stagnation_counter(self):
        base = FakeEnv()
        wrapped = StagnationResetWrapper(base, patience_steps=3, min_episode_steps=0)
        wrapped.reset()
        wrapped.step(0)
        wrapped.step(0)
        base.pos = (4, 6, 38)
        _, _, _, truncated, info = wrapped.step(0)
        self.assertFalse(truncated)
        self.assertEqual(info["stagnation_steps"], 0)
        self.assertEqual(info["last_meaningful_progress"], "new_tile")

    def test_new_event_counts_as_progress_without_movement(self):
        base = FakeEnv()
        wrapped = StagnationResetWrapper(base, patience_steps=3, min_episode_steps=0)
        wrapped.reset()
        wrapped.step(0)
        wrapped.step(0)
        base.events += 1
        _, _, _, truncated, info = wrapped.step(0)
        self.assertFalse(truncated)
        self.assertEqual(info["stagnation_steps"], 0)
        self.assertEqual(info["last_meaningful_progress"], "story_event")

    def test_revisiting_old_tile_does_not_refresh_watchdog(self):
        base = FakeEnv()
        wrapped = StagnationResetWrapper(base, patience_steps=3, min_episode_steps=0)
        wrapped.reset()
        base.pos = (4, 6, 38)
        wrapped.step(0)  # new tile
        base.pos = (3, 6, 38)
        wrapped.step(0)  # old tile
        base.pos = (4, 6, 38)
        wrapped.step(0)  # old tile, stagnant step 2
        _, _, _, truncated, info = wrapped.step(0)  # stagnant step 3
        self.assertTrue(truncated)
        self.assertEqual(info["stagnation_steps"], 3)

    def test_party_level_up_counts_as_progress(self):
        base = FakeEnv()
        wrapped = StagnationResetWrapper(base, patience_steps=3, min_episode_steps=0)
        wrapped.reset()
        wrapped.step(0)
        wrapped.step(0)
        base.levels = (6,)
        _, _, _, truncated, info = wrapped.step(0)
        self.assertFalse(truncated)
        self.assertEqual(info["stagnation_steps"], 0)
        self.assertEqual(info["last_meaningful_progress"], "party_level_up")


if __name__ == "__main__":
    unittest.main(verbosity=2)
