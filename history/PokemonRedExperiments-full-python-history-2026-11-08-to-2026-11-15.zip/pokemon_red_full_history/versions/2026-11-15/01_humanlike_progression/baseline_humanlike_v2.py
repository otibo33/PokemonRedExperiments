#!/usr/bin/env python3
"""Fresh goal-conditioned PPO training for Pokémon Red v2.

This is intentionally separate from the existing trainer/session. The new
observation keys are incompatible with old checkpoints, so the default output
folder is runs_humanlike and no old model is loaded unless --resume points to a
checkpoint created with this same goal-conditioned observation schema.
"""
from __future__ import annotations

import argparse
import re
import time
from pathlib import Path
from typing import Sequence

from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback, CallbackList
from stable_baselines3.common.utils import set_random_seed
from stable_baselines3.common.vec_env import SubprocVecEnv

from red_gym_env_v2 import RedGymEnv
from goal_conditioning import OBJECTIVES
from goal_conditioning import HumanLikeGoalObservationWrapper
from stagnation_wrapper import StagnationResetWrapper
from tensorboard_callback import TensorboardCallback


GOAL_TAGS = (
    "leave_home", "get_starter", "heal", "restock", "build_team", "train_team",
    "brock", "misty", "surge", "erika", "koga", "sabrina", "blaine",
    "giovanni", "league",
)


class RollingCheckpointCallback(BaseCallback):
    def __init__(self, save_dir: Path, every_timesteps: int, keep: int = 10, verbose: int = 1):
        super().__init__(verbose=verbose)
        if every_timesteps < 1 or keep < 1:
            raise ValueError("Checkpoint interval and retention must be positive")
        self.save_dir = Path(save_dir)
        self.every_timesteps = int(every_timesteps)
        self.keep = int(keep)
        self.last_saved = 0

    def _init_callback(self) -> None:
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.last_saved = int(self.model.num_timesteps)

    def _on_step(self) -> bool:
        if self.num_timesteps - self.last_saved < self.every_timesteps:
            return True
        path = self.save_dir / f"poke_{int(self.num_timesteps)}_steps"
        self.model.save(str(path))
        self.last_saved = int(self.num_timesteps)
        pattern = re.compile(r"^poke_(\d+)_steps\.zip$")
        candidates = []
        for item in self.save_dir.glob("poke_*_steps.zip"):
            match = pattern.match(item.name)
            if match:
                candidates.append((int(match.group(1)), item))
        candidates.sort(key=lambda pair: pair[0], reverse=True)
        for _, old in candidates[self.keep:]:
            old.unlink(missing_ok=True)
        if self.verbose:
            print(f"[humanlike checkpoint] saved {path}.zip")
        return True


class HumanLikeMetricsCallback(BaseCallback):
    """Log active objectives and per-worker stagnation resets to TensorBoard."""
    def __init__(self, every: int = 2048, verbose: int = 0):
        super().__init__(verbose=verbose)
        self.every = int(every)
        self.last_log = 0

    def _on_step(self) -> bool:
        if self.num_timesteps - self.last_log < self.every:
            return True
        self.last_log = int(self.num_timesteps)
        infos = self.locals.get("infos") or []
        objective_counts = {name: 0 for name in OBJECTIVES}
        objectives_seen = 0
        stagnation_values = []
        reset_flags = []
        reset_totals = []
        for info in infos:
            if not isinstance(info, dict):
                continue
            objective = info.get("active_objective")
            if objective in objective_counts:
                objective_counts[objective] += 1
                objectives_seen += 1
            if isinstance(info.get("stagnation_steps"), (int, float)):
                stagnation_values.append(float(info["stagnation_steps"]))
            if isinstance(info.get("stagnation_reset"), (int, float)):
                reset_flags.append(float(info["stagnation_reset"]))
            if isinstance(info.get("stagnation_resets_total"), (int, float)):
                reset_totals.append(float(info["stagnation_resets_total"]))

        if objectives_seen:
            for index, (name, tag) in enumerate(zip(OBJECTIVES, GOAL_TAGS)):
                value = objective_counts[name] / objectives_seen
                self.logger.record(f"supervisor/goal_{tag}_fraction", float(value))
        if stagnation_values:
            self.logger.record("supervisor/stagnant_steps_mean", float(sum(stagnation_values) / len(stagnation_values)))
        if reset_flags:
            self.logger.record("supervisor/worker_reset_frac", float(sum(reset_flags) / len(reset_flags)))
        if reset_totals:
            self.logger.record("supervisor/resets_total_mean", float(sum(reset_totals) / len(reset_totals)))
        return True


def make_env(rank: int, config: dict, seed: int):
    def _init():
        worker_seed = int(seed) + int(rank)
        set_random_seed(worker_seed)
        env = RedGymEnv(dict(config))
        # Watchdog wraps the raw env so its terminal snapshot is taken before
        # the observation wrapper appends the goal-conditioned input fields.
        env = StagnationResetWrapper(
            env,
            patience_steps=config["stagnation_patience_steps"],
            min_episode_steps=config["stagnation_min_episode_steps"],
            timeout_penalty=config["stagnation_timeout_penalty"],
        )
        env = HumanLikeGoalObservationWrapper(env)
        return env
    return _init


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Goal-conditioned Pokémon Red PPO")
    parser.add_argument("--rom", default="../PokemonRed.gb")
    parser.add_argument("--init-state", default="../init.state")
    parser.add_argument("--session-dir", default="runs_humanlike")
    parser.add_argument("--num-envs", type=int, default=16)
    parser.add_argument("--timesteps", type=int, default=500_000_000)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--resume", default=None,
                        help="Only a checkpoint previously trained with this humanlike observation schema")
    parser.add_argument("--episode-steps", type=int, default=2048 * 80)
    parser.add_argument("--n-steps", type=int, default=2048)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--n-epochs", type=int, default=4)
    parser.add_argument("--ent-coef", type=float, default=0.01)
    parser.add_argument("--save-every", type=int, default=5_000_000)
    parser.add_argument("--keep-checkpoints", type=int, default=10)
    parser.add_argument("--stagnation-patience", type=int, default=8192)
    parser.add_argument("--stagnation-min-steps", type=int, default=1024)
    parser.add_argument("--stagnation-penalty", type=float, default=1.0)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if min(args.num_envs, args.timesteps, args.episode_steps, args.n_steps, args.batch_size,
           args.n_epochs, args.save_every, args.keep_checkpoints, args.stagnation_patience) < 1:
        raise ValueError("All counts and intervals must be positive")
    if args.stagnation_min_steps < 0 or args.stagnation_penalty < 0:
        raise ValueError("Stagnation minimum/penalty must be non-negative")
    if args.batch_size > args.n_steps * args.num_envs:
        raise ValueError("batch-size cannot exceed n-steps * num-envs")

    seed = int(args.seed) if args.seed is not None else int(time.time()) % 100_000
    set_random_seed(seed)
    session_dir = Path(args.session_dir).expanduser()
    session_dir.mkdir(parents=True, exist_ok=True)

    config = {
        "headless": True,
        "save_final_state": False,
        "early_stop": False,
        "action_freq": 24,
        "init_state": args.init_state,
        "max_steps": args.episode_steps,
        "print_rewards": False,
        "save_video": False,
        "fast_video": True,
        "session_path": session_dir,
        "gb_path": args.rom,
        "reward_scale": 0.5,
        "explore_weight": 0.25,
        "map_progress_weight": 5.0,
        "stuck_penalty_weight": 1.0,
        "stagnation_patience_steps": args.stagnation_patience,
        "stagnation_min_episode_steps": args.stagnation_min_steps,
        "stagnation_timeout_penalty": args.stagnation_penalty,
    }

    print("\nPokémon Red — Goal-conditioned humanlike training")
    print("-------------------------------------------------")
    print(f"Workers: {args.num_envs}; device: {args.device}; seed: {seed}")
    print(f"Session: {session_dir.resolve()}")
    print(f"ROM: {Path(args.rom).resolve()}; init state: {Path(args.init_state).resolve()}")
    print(f"Timesteps: {args.timesteps:,}; rollout per worker: {args.n_steps:,}")
    print(f"Stagnation reset: {args.stagnation_patience:,} steps without meaningful progress")
    print("Observation schema: pixels + map + semantic world state + active objective")
    print("This is a new model architecture. Do not resume a legacy checkpoint.\n")

    env = None
    model = None
    try:
        env = SubprocVecEnv(
            [make_env(i, config, seed) for i in range(args.num_envs)],
            start_method="spawn",
        )
        env.seed(seed)
        callbacks = CallbackList([
            RollingCheckpointCallback(session_dir, args.save_every, args.keep_checkpoints),
            TensorboardCallback(session_dir),
            HumanLikeMetricsCallback(every=2048),
        ])

        if args.resume:
            checkpoint = Path(args.resume).expanduser()
            if checkpoint.suffix != ".zip":
                checkpoint = checkpoint.with_suffix(".zip")
            if not checkpoint.is_file():
                raise FileNotFoundError(f"Humanlike checkpoint not found: {checkpoint}")
            model = PPO.load(str(checkpoint), env=env, device=args.device)
            model.tensorboard_log = str(session_dir)
            model.seed = seed
            print(f"Resuming compatible humanlike checkpoint: {checkpoint}")
        else:
            model = PPO(
                "MultiInputPolicy",
                env,
                verbose=1,
                device=args.device,
                n_steps=args.n_steps,
                batch_size=args.batch_size,
                n_epochs=args.n_epochs,
                gamma=0.997,
                ent_coef=args.ent_coef,
                learning_rate=3e-4,
                tensorboard_log=str(session_dir),
                seed=seed,
            )
            print("Starting a NEW goal-conditioned PPO model.")

        model.learn(
            total_timesteps=args.timesteps,
            callback=callbacks,
            tb_log_name="pokemon_humanlike",
            reset_num_timesteps=args.resume is None,
        )
        model.save(str(session_dir / "poke_final"))
        print(f"Training complete: {session_dir / 'poke_final.zip'}")
        return 0
    except KeyboardInterrupt:
        if model is not None:
            path = session_dir / "poke_interrupted"
            model.save(str(path))
            print(f"Interrupted model saved: {path}.zip")
        return 130
    finally:
        if env is not None:
            env.close()


if __name__ == "__main__":
    raise SystemExit(main())
