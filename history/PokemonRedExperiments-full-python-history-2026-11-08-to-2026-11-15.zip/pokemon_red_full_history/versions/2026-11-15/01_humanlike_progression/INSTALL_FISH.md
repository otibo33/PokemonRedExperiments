# Pokémon Red — goal-conditioned humanlike training

This patch provides the first practical version of the human-like player
architecture, isolated from the old PPO run. It combines:

1. **A state-based objective supervisor** that tells the policy what meaningful
   task is currently important (leave the starting house, obtain a starter,
   heal, restock, build a diverse party, train, earn the next badge, or complete
   the League).
2. **A semantic world-state observation** alongside the existing screen/map
   inputs: current map and coordinates, progression, badge bits, party size and
   diversity, Pokédex, levels, HP, Poké Balls, event count, exploration and
   episode position.
3. **A per-worker stagnation watchdog** that automatically truncates only a
   worker that has not made meaningful progress for 8,192 actions. It recognises
   new tiles/maps, story events, milestones, badges, Pokédex growth, party
   changes and level-ups. Repeated loops/door cycling do not refresh the timer.
4. **A separate PPO trainer** that writes to `runs_humanlike/` and keeps the old
   `runs/`, checkpoints and TensorBoard history intact.

The supervisor does not execute button sequences. PPO still decides every
button press, but the policy receives a changing, explicit objective and the
semantic state needed to condition its decisions. The priorities are guidance,
not a scripted walkthrough.

## Important checkpoint compatibility

`HumanLikeGoalObservationWrapper` adds two observation keys (`objective` and
`world_state`). Therefore, **old checkpoints cannot be loaded into this new
policy**. Start a new model in the separate `runs_humanlike/` directory. The old
checkpoint and original `runs/` remain untouched and can still be used by the
legacy trainer.

Only use `--resume` with a checkpoint created by this new trainer and this same
observation schema.

## Install in Fish

Extract/copy these files into the existing `v2/` directory, beside
`red_gym_env_v2.py`, `global_map.py`, `map_data.json`, and
`tensorboard_callback.py`:

- `goal_conditioning.py`
- `stagnation_wrapper.py`
- `baseline_humanlike_v2.py`
- the two test files (optional but recommended)

From the v2 directory, activate your existing virtual environment and run:

```fish
python -m py_compile goal_conditioning.py stagnation_wrapper.py baseline_humanlike_v2.py
python test_stagnation_wrapper.py
python test_goal_conditioning.py
```

Then start the new training session:

```fish
python baseline_humanlike_v2.py --num-envs 16 --device cuda --timesteps 500000000
```

The default ROM and init-state paths match the current project layout:
`../PokemonRed.gb` and `../init.state`. The session is written to
`v2/runs_humanlike/`.

The initial watchdog is configured for 8,192 actions without meaningful
progress, with a 1,024-step minimum episode age and a terminal stagnation
penalty of 1.0. You can change these without editing code:

```fish
python baseline_humanlike_v2.py --stagnation-patience 12000 --stagnation-min-steps 1500
```

## TensorBoard

Open the separate run directory:

```fish
tensorboard --logdir runs_humanlike --reload_interval 1
```

Useful new metrics include `supervisor/goal_*_fraction`,
`supervisor/stagnation_steps_mean`, `supervisor/stagnation_reset_fraction`,
and `supervisor/stagnation_resets_total_mean`. The existing
`TensorboardCallback` also retains exploration maps and party dashboards.

## How the objective selection works

- No active Pokémon: leave the player's house if map 38, otherwise obtain a
  starter.
- Critical HP: recover the party.
- Low Poké Ball supply in an early town: restock.
- After reaching the early routes: build a small varied party.
- Below the recommended level for the next badge: train.
- Otherwise: pursue the next missing badge, in Red/Blue badge order.
- After all eight badges: complete the Pokémon League.

These choices are derived from current game RAM and party/inventory state. They
are not fixed button scripts or a hardcoded route through every map.

## Validation and limitations

The bundled tests cover the objective priorities and stuck-reset behaviour
using a fake environment. They do not replace a live PyBoy/ROM smoke test. A
fresh goal-conditioned policy must learn how to execute these objectives; the
objective labels are not proof that it already knows how to beat a gym or solve
a puzzle. The next improvement after confirming this run is healthy is a
learned navigation/battle skill layer and longer-term memory of failed and
successful strategies.

Do not delete or rename the existing `runs/`, model checkpoints,
`_trajectory_history`, `init.state`, ROM, or starter-choice database.
