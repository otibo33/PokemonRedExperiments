"""State-derived, goal-conditioned observations for Pokémon Red.

This layer supplies a compact strategic objective plus semantic game-state
features alongside the original pixel/map observations. It does not issue
button sequences. PPO still chooses every game action, but now receives an
explicit description of the current task and relevant state.

Because this adds observation keys, it is for a NEW model/session. Do not load
an older checkpoint trained with the previous observation dictionary.
"""
from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces


OBJECTIVES = (
    "leave_starting_house",
    "obtain_starter",
    "heal_party",
    "restock_pokeballs",
    "build_party",
    "train_party",
    "earn_boulder_badge",
    "earn_cascade_badge",
    "earn_thunder_badge",
    "earn_rainbow_badge",
    "earn_soul_badge",
    "earn_marsh_badge",
    "earn_volcano_badge",
    "earn_earth_badge",
    "complete_pokemon_league",
)
OBJECTIVE_TO_INDEX = {name: index for index, name in enumerate(OBJECTIVES)}

# English Red/Blue badge bits in WRAM 0xD356. The badge order also defines the
# main story objective order (Boulder through Earth).
BADGE_OBJECTIVES = (
    "earn_boulder_badge",
    "earn_cascade_badge",
    "earn_thunder_badge",
    "earn_rainbow_badge",
    "earn_soul_badge",
    "earn_marsh_badge",
    "earn_volcano_badge",
    "earn_earth_badge",
)
BADGE_LEVEL_TARGETS = (8, 14, 20, 24, 30, 35, 40, 45)


class HumanLikeGoalObservationWrapper(gym.ObservationWrapper):
    """Add ``objective`` and ``world_state`` inputs to the base observation.

    Goal selection is state based and changes only when game facts change. The
    low-level policy remains responsible for navigation, menus, dialogue,
    battles and interactions; this wrapper never presses buttons for it.
    """

    def __init__(self, env: gym.Env):
        super().__init__(env)
        if not isinstance(getattr(env.observation_space, "spaces", None), dict):
            raise TypeError("HumanLikeGoalObservationWrapper requires a Dict observation space")
        new_spaces = dict(env.observation_space.spaces)
        new_spaces["objective"] = spaces.Box(
            low=0.0, high=1.0, shape=(len(OBJECTIVES),), dtype=np.float32
        )
        new_spaces["world_state"] = spaces.Box(
            low=0.0, high=1.0, shape=(25,), dtype=np.float32
        )
        self.observation_space = spaces.Dict(new_spaces)
        self.active_objective = "obtain_starter"
        self.last_world_state = np.zeros(25, dtype=np.float32)

    @property
    def pyboy(self):
        return self.env.pyboy

    @property
    def seen_coords(self):
        return self.env.seen_coords

    @property
    def game(self):
        return getattr(self.env, "game")

    def __getattr__(self, name: str):
        if name.startswith("_"):
            raise AttributeError(name)
        current = self.__dict__.get("env")
        visited: set[int] = set()
        while current is not None and id(current) not in visited:
            visited.add(id(current))
            try:
                return object.__getattribute__(current, name)
            except AttributeError:
                pass
            try:
                current = object.__getattribute__(current, "env")
            except AttributeError:
                current = None
        raise AttributeError(name)

    def reset(self, *, seed=None, options=None):
        observation, info = self.env.reset(seed=seed, options=options)
        observation = self.observation(observation)
        info = dict(info or {})
        info["active_objective"] = self.active_objective
        return observation, info

    def step(self, action):
        observation, reward, terminated, truncated, info = self.env.step(action)
        observation = self.observation(observation)
        info = dict(info or {})
        info["active_objective"] = self.active_objective
        return observation, reward, terminated, truncated, info

    def _base_env(self):
        current = self.env
        visited: set[int] = set()
        while current is not None and id(current) not in visited:
            visited.add(id(current))
            if hasattr(type(current), "read_m") or "read_m" in getattr(current, "__dict__", {}):
                return current
            try:
                current = object.__getattribute__(current, "env")
            except AttributeError:
                current = None
        return self.env

    @staticmethod
    def _safe_int(value: Any, default: int = 0) -> int:
        try:
            return int(value)
        except (TypeError, ValueError, OverflowError):
            return default

    @staticmethod
    def _safe_float(value: Any, default: float = 0.0) -> float:
        try:
            result = float(value)
            return result if np.isfinite(result) else default
        except (TypeError, ValueError, OverflowError):
            return default

    def _read_semantic_state(self) -> dict[str, Any]:
        env = self._base_env()
        x, y, map_id = env.get_game_coords()
        map_id = self._safe_int(map_id, -1)
        badge_byte = self._safe_int(env.read_m(0xD356), 0) & 0xFF
        party_size = self._safe_int(env.get_party_size(), 0)
        party_species = tuple(self._safe_int(v) for v in env.read_party_species())
        party = env.read_party_snapshot()
        levels: list[int] = []
        for mon in party if isinstance(party, (list, tuple)) else ():
            if isinstance(mon, dict):
                level = self._safe_int(mon.get("level", 0))
                if level > 0:
                    levels.append(level)
        average_level = float(np.mean(levels)) if levels else 0.0
        try:
            lead_hp = self._safe_float(env.read_lead_hp_fraction(), 1.0)
        except Exception:
            lead_hp = self._safe_float(env.read_hp_fraction(), 1.0)
        try:
            aggregate_hp = self._safe_float(env.read_hp_fraction(), 1.0)
        except Exception:
            aggregate_hp = lead_hp
        try:
            pokeballs = self._safe_int(env.read_pokeball_count(), 0)
        except Exception:
            pokeballs = 0
        try:
            dex_count = self._safe_int(env.read_pokedex_owned_count(), 0)
        except Exception:
            dex_count = 0
        try:
            event_count = self._safe_int(env.get_all_events_reward(), 0)
        except Exception:
            event_count = 0
        try:
            current_progress = self._safe_int(env.get_map_progress(map_id), -1)
        except Exception:
            current_progress = -1
        best_progress = self._safe_int(getattr(env, "best_map_progress", -1), -1)
        current_step = self._safe_int(getattr(env, "step_count", 0), 0)
        max_steps = max(1, self._safe_int(getattr(env, "max_steps", 1), 1))
        try:
            seen_tiles = len(getattr(env, "seen_coords", {}))
        except Exception:
            seen_tiles = 0
        return {
            "x": self._safe_int(x),
            "y": self._safe_int(y),
            "map_id": map_id,
            "badge_byte": badge_byte,
            "badge_count": badge_byte.bit_count(),
            "party_size": max(0, min(6, party_size)),
            "party_species": party_species,
            "unique_party": len(set(party_species)),
            "average_level": average_level,
            "lead_hp": float(np.clip(lead_hp, 0.0, 1.0)),
            "aggregate_hp": float(np.clip(aggregate_hp, 0.0, 1.0)),
            "pokeballs": max(0, pokeballs),
            "dex_count": max(0, dex_count),
            "event_count": max(0, event_count),
            "current_progress": current_progress,
            "best_progress": best_progress,
            "seen_tiles": max(0, seen_tiles),
            "episode_fraction": float(np.clip(current_step / max_steps, 0.0, 1.0)),
        }

    def _choose_objective(self, state: dict[str, Any]) -> str:
        party_size = state["party_size"]
        map_id = state["map_id"]
        badge_byte = state["badge_byte"]
        badge_count = state["badge_count"]
        mean_level = state["average_level"]

        # New-game opening: the uploaded init.state starts on the second floor
        # of the player's house (map 38), before the starter is selected.
        if party_size == 0:
            return "leave_starting_house" if map_id == 38 else "obtain_starter"

        # Protect the lead and recover before continuing the story.
        if state["lead_hp"] <= 0.25 or state["aggregate_hp"] <= 0.30:
            return "heal_party"

        # Do not send the new-game opening to a shop before Oak's parcel/story
        # sequence has made that sensible. Restock only in actual early towns.
        if (
            state["pokeballs"] <= 2
            and state["dex_count"] < 30
            and state["map_id"] in {1, 2, 3}
        ):
            return "restock_pokeballs"

        # Encourage a small, varied early party after the agent reaches the
        # first outdoor routes. Existing capture/duplicate rewards handle the
        # detailed species incentives; the objective provides the strategic aim.
        if (
            state["current_progress"] >= 2
            and state["unique_party"] < 3
            and state["pokeballs"] > 0
        ):
            return "build_party"

        # Avoid sending an under-levelled team directly into the next major
        # badge challenge. Targets are guidelines, not forced levels/actions.
        if badge_count < 8:
            target_level = BADGE_LEVEL_TARGETS[badge_count]
            if mean_level > 0 and mean_level < target_level:
                return "train_party"

        # Story milestones use the actual badge bitfield, not badge count alone.
        for bit, objective in enumerate(BADGE_OBJECTIVES):
            if not (badge_byte & (1 << bit)):
                return objective

        return "complete_pokemon_league"

    def observation(self, observation):
        state = self._read_semantic_state()
        self.active_objective = self._choose_objective(state)
        objective_vector = np.zeros(len(OBJECTIVES), dtype=np.float32)
        objective_vector[OBJECTIVE_TO_INDEX[self.active_objective]] = 1.0

        # A compact numeric state vector complements screen pixels. All values
        # are bounded [0, 1] and have stable positions/shapes for PPO.
        world = np.zeros(25, dtype=np.float32)
        world[0] = np.clip(state["map_id"] / 255.0, 0.0, 1.0)
        world[1] = np.clip(state["x"] / 255.0, 0.0, 1.0)
        world[2] = np.clip(state["y"] / 255.0, 0.0, 1.0)
        world[3] = np.clip((state["current_progress"] + 1) / 15.0, 0.0, 1.0)
        world[4] = np.clip((state["best_progress"] + 1) / 15.0, 0.0, 1.0)
        world[5] = np.clip(state["badge_count"] / 8.0, 0.0, 1.0)
        for bit in range(8):
            world[6 + bit] = float(bool(state["badge_byte"] & (1 << bit)))
        world[14] = state["party_size"] / 6.0
        world[15] = state["unique_party"] / 6.0
        world[16] = np.clip(state["dex_count"] / 151.0, 0.0, 1.0)
        world[17] = np.clip(state["average_level"] / 100.0, 0.0, 1.0)
        world[18] = state["lead_hp"]
        world[19] = state["aggregate_hp"]
        world[20] = np.clip(state["pokeballs"] / 99.0, 0.0, 1.0)
        world[21] = np.clip(state["event_count"] / 300.0, 0.0, 1.0)
        world[22] = np.clip(state["seen_tiles"] / 500.0, 0.0, 1.0)
        world[23] = OBJECTIVE_TO_INDEX[self.active_objective] / max(len(OBJECTIVES) - 1, 1)
        world[24] = state["episode_fraction"]

        result = dict(observation)
        result["objective"] = objective_vector
        result["world_state"] = world
        self.last_world_state = world
        return result
