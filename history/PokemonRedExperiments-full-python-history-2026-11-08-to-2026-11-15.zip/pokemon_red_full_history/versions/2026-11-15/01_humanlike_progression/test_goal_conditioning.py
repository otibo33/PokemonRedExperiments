"""Tests for state-derived goal selection."""
import sys
import types
import unittest

import numpy as np

try:
    import gymnasium as gym
    from gymnasium import spaces
except ImportError:
    gym = types.ModuleType("gymnasium")
    class _Env:
        def reset(self, *, seed=None, options=None):
            return None
    class _Wrapper(_Env):
        def __init__(self, env): self.env = env
    class _ObservationWrapper(_Wrapper):
        def observation(self, observation): return observation
    class _Space:
        def __init__(self, *args, **kwargs): pass
    class _Dict(_Space):
        def __init__(self, spaces): self.spaces = spaces
    gym.Env = _Env
    gym.Wrapper = _Wrapper
    gym.ObservationWrapper = _ObservationWrapper
    spaces = types.SimpleNamespace(Box=_Space, Dict=_Dict)
    gym.spaces = spaces
    sys.modules["gymnasium"] = gym

from goal_conditioning import HumanLikeGoalObservationWrapper, OBJECTIVES, OBJECTIVE_TO_INDEX


class FakeEnv(gym.Env):
    def __init__(self):
        self.observation_space = spaces.Dict({"pixels": spaces.Box(0, 255, shape=(1,), dtype=np.uint8)})
        self.pos = (3, 6, 38)
        self.badge_byte = 0
        self.party = ()
        self.levels = ()
        self.lead_hp = 1.0
        self.aggregate_hp = 1.0
        self.balls = 5
        self.dex = 0
        self.events = 0
        self.max_map_progress = -1
        self.step_count = 0
        self.max_steps = 163840
        self.seen_coords = {}
        self.pyboy = object()

    def get_game_coords(self): return self.pos
    def read_m(self, address): return self.badge_byte if address == 0xD356 else 0
    def get_party_size(self): return len(self.party)
    def read_party_species(self): return self.party
    def read_party_snapshot(self): return [{"level": level} for level in self.levels]
    def read_lead_hp_fraction(self): return self.lead_hp
    def read_hp_fraction(self): return self.aggregate_hp
    def read_pokeball_count(self): return self.balls
    def read_pokedex_owned_count(self): return self.dex
    def get_all_events_reward(self): return self.events
    def get_map_progress(self, map_id): return {38: -1, 0: 1, 12: 2, 1: 3}.get(map_id, -1)


class GoalConditioningTests(unittest.TestCase):
    def setUp(self):
        self.base = FakeEnv()
        self.wrapper = HumanLikeGoalObservationWrapper(self.base)

    def goal(self):
        obs = self.wrapper.observation({"pixels": np.zeros(1, dtype=np.uint8)})
        self.assertEqual(obs["objective"].shape, (len(OBJECTIVES),))
        self.assertEqual(obs["world_state"].shape, (25,))
        self.assertAlmostEqual(float(obs["objective"].sum()), 1.0)
        return OBJECTIVES[int(np.argmax(obs["objective"]))]

    def test_player_house_before_starter_gets_exit_home_goal(self):
        self.assertEqual(self.goal(), "leave_starting_house")

    def test_empty_party_outside_home_gets_starter_goal(self):
        self.base.pos = (4, 6, 0)
        self.assertEqual(self.goal(), "obtain_starter")

    def test_low_hp_takes_priority(self):
        self.base.party = (0x99,)
        self.base.levels = (8,)
        self.base.lead_hp = 0.2
        self.assertEqual(self.goal(), "heal_party")

    def test_new_team_building_goal(self):
        self.base.pos = (10, 10, 12)  # Route 1 progress rank 2
        self.base.party = (0x99,)
        self.base.levels = (8,)
        self.assertEqual(self.goal(), "build_party")

    def test_training_goal_before_first_badge(self):
        self.base.pos = (10, 10, 12)
        self.base.party = (0x99, 0xA5, 0x24)
        self.base.levels = (5, 4, 5)
        self.assertEqual(self.goal(), "train_party")

    def test_badge_goal_uses_badge_bits(self):
        self.base.pos = (10, 10, 12)
        self.base.party = (0x99, 0xA5, 0x24)
        self.base.levels = (15, 14, 15)
        self.base.badge_byte = 1  # Boulder earned; next is Cascade
        self.assertEqual(self.goal(), "earn_cascade_badge")


if __name__ == "__main__":
    unittest.main(verbosity=2)
