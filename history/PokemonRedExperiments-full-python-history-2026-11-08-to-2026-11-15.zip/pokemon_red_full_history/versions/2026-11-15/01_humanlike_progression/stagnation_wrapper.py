"""Progress-aware per-worker reset wrapper for Pokémon Red Gymnasium envs.

The wrapper does not choose actions or change observation/action spaces. It
truncates only the worker that has stopped making meaningful progress for a
configurable number of environment steps. Stable-Baselines3's SubprocVecEnv
then resets that worker normally.
"""
from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np


class StagnationResetWrapper(gym.Wrapper):
    """Truncate a worker episode after prolonged lack of meaningful progress.

    Progress is recognised when the worker:
      * visits a new (map, x, y) tile or enters a new map in this episode;
      * reaches a higher story-map milestone;
      * sets additional event flags or earns a badge;
      * registers a new Pokédex entry;
      * changes its active party species or levels up a party member.

    Repeatedly crossing the same door or walking a previously visited loop does
    not refresh the watchdog. HP fluctuations and ordinary menu activity also
    do not count as progress, so a stuck battle/menu eventually times out.

    The default patience of 8,192 actions is deliberately much longer than a
    normal menu interaction or battle, while much shorter than the original
    163,840-step episode limit. Set patience_steps=None to disable it.
    """

    def __init__(
        self,
        env: gym.Env,
        *,
        patience_steps: int | None = 8192,
        timeout_penalty: float = 1.0,
        min_episode_steps: int = 1024,
    ) -> None:
        super().__init__(env)
        if patience_steps is not None and int(patience_steps) < 1:
            raise ValueError("patience_steps must be >= 1 or None")
        if float(timeout_penalty) < 0:
            raise ValueError("timeout_penalty must be >= 0")
        if int(min_episode_steps) < 0:
            raise ValueError("min_episode_steps must be >= 0")

        self.patience_steps = None if patience_steps is None else int(patience_steps)
        self.timeout_penalty = float(timeout_penalty)
        self.min_episode_steps = int(min_episode_steps)

        # These counters intentionally survive reset() for worker-level
        # diagnostics. Episode counters/sets are reinitialized on every reset.
        self.total_stagnation_resets = 0
        self.episode_steps = 0
        self.stagnant_steps = 0
        self.last_progress_reason = "not_started"
        self.last_reset_reason = "initial"
        self._episode_positions: set[tuple[int, int, int]] = set()
        self._episode_maps: set[int] = set()
        self._last_state: dict[str, Any] | None = None

    # StreamWrapper in this project checks these attributes on the wrapped env.
    # Explicit properties avoid depending on Gymnasium's deprecated __getattr__.
    @property
    def pyboy(self):
        return self.env.pyboy

    @property
    def game(self):
        return getattr(self.env, "game")

    @property
    def seen_coords(self):
        return self.env.seen_coords

    def __getattr__(self, name: str):
        # Preserve the env API for SB3 callbacks/wrappers while avoiding private
        # attribute forwarding. The base RedGymEnv owns the actual attributes.
        if name.startswith("_"):
            raise AttributeError(name)
        wrapped = self.__dict__.get("env")
        if wrapped is None:
            raise AttributeError(name)
        current = wrapped
        visited: set[int] = set()
        while current is not None and id(current) not in visited:
            visited.add(id(current))
            try:
                return object.__getattribute__(current, name)
            except AttributeError:
                pass
            try:
                current = object.__getattribute__(current, "env")
            except AttributeError:
                current = None
        raise AttributeError(name)

    def reset(self, *, seed=None, options=None):
        observation, info = self.env.reset(seed=seed, options=options)
        self.episode_steps = 0
        self.stagnant_steps = 0
        self.last_progress_reason = "episode_start"
        self.last_reset_reason = "normal"
        self._episode_positions = set()
        self._episode_maps = set()
        self._last_state = self._read_state()
        if self._last_state is not None:
            self._remember_location(self._last_state)
        info = dict(info or {})
        info.update(self._watchdog_info())
        return observation, info

    def step(self, action):
        observation, reward, terminated, truncated, raw_info = self.env.step(action)
        info = dict(raw_info or {})
        self.episode_steps += 1

        state = self._read_state()
        progress_reason = self._detect_progress(state)
        if progress_reason:
            self.stagnant_steps = 0
            self.last_progress_reason = progress_reason
        else:
            self.stagnant_steps += 1

        # Preserve a natural time-limit truncation from the underlying env.
        reset_reason = None
        if not (terminated or truncated):
            if (
                self.patience_steps is not None
                and self.episode_steps >= self.min_episode_steps
                and self.stagnant_steps >= self.patience_steps
            ):
                truncated = True
                reset_reason = "stagnation"
                self.total_stagnation_resets += 1
                self.last_reset_reason = reset_reason
                reward = float(reward) - self.timeout_penalty
                self._make_terminal_snapshot(info, state, reset_reason)
                info["stagnation_timeout_penalty"] = self.timeout_penalty

        if truncated and reset_reason is None:
            self.last_reset_reason = str(info.get("reset_reason", "time_limit"))

        info.update(self._watchdog_info())
        if reset_reason is not None:
            info["reset_reason"] = reset_reason
            info["stagnation_reset"] = 1
        return observation, reward, terminated, truncated, info

    def _read_state(self) -> dict[str, Any] | None:
        env = self.env
        try:
            x, y, map_id = env.get_game_coords()
            state: dict[str, Any] = {
                "x": int(x),
                "y": int(y),
                "map_id": int(map_id),
                "map_progress": int(getattr(env, "max_map_progress", -1)),
                "best_map_progress": int(getattr(env, "best_map_progress", -1)),
                "badges": int(env.get_badges()),
                "pokedex_owned": int(env.read_pokedex_owned_count()),
                "event_count": int(env.get_all_events_reward()),
                "party_species": tuple(int(v) for v in env.read_party_species()),
            }
            party = env.read_party_snapshot()
            levels = []
            for mon in party if isinstance(party, (list, tuple)) else ():
                if isinstance(mon, dict):
                    try:
                        level = int(mon.get("level", 0))
                    except (TypeError, ValueError):
                        level = 0
                    if level > 0:
                        levels.append(level)
            state["party_levels"] = tuple(levels)
            return state
        except Exception:
            # A failure to inspect optional state should not crash training.
            # Position data is still recoverable in most project revisions.
            try:
                x, y, map_id = env.get_game_coords()
                return {"x": int(x), "y": int(y), "map_id": int(map_id)}
            except Exception:
                return None

    def _remember_location(self, state: dict[str, Any]) -> None:
        map_id = int(state.get("map_id", -1))
        self._episode_maps.add(map_id)
        self._episode_positions.add(
            (map_id, int(state.get("x", -1)), int(state.get("y", -1)))
        )

    def _detect_progress(self, state: dict[str, Any] | None) -> str | None:
        if state is None:
            return None
        previous = self._last_state
        self._last_state = state

        position = (
            int(state.get("map_id", -1)),
            int(state.get("x", -1)),
            int(state.get("y", -1)),
        )
        map_id = position[0]
        if map_id not in self._episode_maps:
            self._remember_location(state)
            return "new_map"
        if position not in self._episode_positions:
            self._remember_location(state)
            return "new_tile"
        self._remember_location(state)

        if previous is None:
            return None

        # Monotonic/high-water changes are meaningful even in a revisited area.
        for key, reason in (
            ("best_map_progress", "story_milestone"),
            ("map_progress", "map_progress"),
            ("event_count", "story_event"),
            ("badges", "badge_earned"),
            ("pokedex_owned", "pokedex_growth"),
        ):
            if int(state.get(key, -1)) > int(previous.get(key, -1)):
                return reason

        if tuple(state.get("party_species", ())) != tuple(previous.get("party_species", ())):
            return "party_changed"

        current_levels = tuple(state.get("party_levels", ()))
        previous_levels = tuple(previous.get("party_levels", ()))
        if len(current_levels) == len(previous_levels) and any(
            current > old for current, old in zip(current_levels, previous_levels)
        ):
            return "party_level_up"
        return None

    def _watchdog_info(self) -> dict[str, Any]:
        return {
            "stagnation_steps": int(self.stagnant_steps),
            "stagnation_patience_steps": int(self.patience_steps or 0),
            "stagnation_resets_total": int(self.total_stagnation_resets),
            "last_meaningful_progress": str(self.last_progress_reason),
            "worker_reset_reason": str(self.last_reset_reason),
        }

    def _make_terminal_snapshot(
        self,
        info: dict[str, Any],
        state: dict[str, Any] | None,
        reset_reason: str,
    ) -> None:
        """Build the same terminal payload expected by TensorboardCallback."""
        env = self.env
        try:
            if hasattr(env, "update_event_flag_names"):
                env.update_event_flag_names()
            snapshot = dict(info.get("episode_snapshot") or {})
            if state is None:
                state = self._read_state() or {}
            snapshot.update({
                "episode": int(getattr(env, "reset_count", 0)),
                "episode_steps": int(self.episode_steps),
                "agent_stats": dict(env.agent_stats[-1]) if getattr(env, "agent_stats", None) else {},
                "explore_map": np.asarray(env.explore_map).copy(),
                "lifetime_explore_map": np.asarray(env.lifetime_explore_map).copy(),
                "map_progress": int(getattr(env, "max_map_progress", state.get("map_progress", -1))),
                "best_map_progress": int(getattr(env, "best_map_progress", state.get("best_map_progress", -1))),
                "best_map_id": int(getattr(env, "best_map_id", state.get("map_id", -1))),
                "map_id": int(state.get("map_id", -1)),
                "seen_tiles": int(len(getattr(env, "seen_coords", {}))),
                "lifetime_seen_tiles": int(len(getattr(env, "lifetime_seen_coords", set()))),
                "badges": int(state.get("badges", 0)),
                "pokedex_owned": int(state.get("pokedex_owned", 0)),
                "captures": int(getattr(env, "capture_count", 0)),
                "party_snapshot": env.read_party_snapshot(),
                "event_flags": dict(getattr(env, "current_event_flags_set", {})),
                "lifetime_event_flags": dict(getattr(env, "lifetime_event_flags", {})),
                "reset_reason": reset_reason,
                "stagnation_steps": int(self.stagnant_steps),
                "stagnation_resets_total": int(self.total_stagnation_resets),
            })
            # Keep the env-side episode count accurate for subsequent info rows.
            if hasattr(env, "episodes_completed"):
                env.episodes_completed += 1
            info["episode_snapshot"] = snapshot
        except Exception as exc:
            # Reset still proceeds even if a telemetry field is unavailable.
            info["stagnation_snapshot_warning"] = str(exc)
            if hasattr(env, "episodes_completed"):
                env.episodes_completed += 1
