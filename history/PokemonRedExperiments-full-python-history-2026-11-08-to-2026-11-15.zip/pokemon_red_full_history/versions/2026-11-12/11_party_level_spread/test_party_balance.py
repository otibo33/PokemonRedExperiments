from __future__ import annotations
import importlib.util, sys, types
from pathlib import Path

# Runtime-only dependency stubs; no emulator or ROM required.
gym = types.ModuleType("gymnasium")
class Env: pass
class Spaces: pass
gym.Env, gym.spaces = Env, Spaces()
sys.modules["gymnasium"] = gym
pyboy = types.ModuleType("pyboy"); pyboy.PyBoy = type("PyBoy", (), {})
pyboy_utils = types.ModuleType("pyboy.utils"); pyboy_utils.WindowEvent = type("WindowEvent", (), {})
sys.modules["pyboy"] = pyboy; sys.modules["pyboy.utils"] = pyboy_utils
sys.modules["mediapy"] = types.ModuleType("mediapy")
global_map = types.ModuleType("global_map"); global_map.local_to_global=lambda *a:(0,0); global_map.GLOBAL_MAP_SHAPE=(48,48)
sys.modules["global_map"] = global_map
p=Path(__file__).with_name("red_gym_env_v2.py")
spec=importlib.util.spec_from_file_location("balance_env_test",p); mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)

def check(ok,msg):
    if not ok: raise AssertionError(msg)

class Fake(mod.RedGymEnv):
    def __init__(self, levels, species=None):
        self.party_level_tolerance=8
        self.levels=list(levels)
        self.species=list(species if species is not None else range(1,len(levels)+1))
    def read_party_snapshot(self):
        return [{"level":v} for v in self.levels]
    def read_unique_party_count(self):
        return len(set(self.species))

def test_balance_score_is_independent_of_party_size():
    one=Fake([20],[25]); six=Fake([20,19,18,20,17,16],[25,4,7,8,9,10])
    check(six.get_party_level_balance_score()==one.get_party_level_balance_score()==1.0,
          "level balance should measure spread only; party size/diversity is tracked separately")

def test_balanced_team_scores_more_than_overlevelled_carry():
    balanced=Fake([20,19,18,20,17,16])
    carried=Fake([40,5,4,3,2,1])
    check(balanced.get_party_level_balance_score()>carried.get_party_level_balance_score(),"balanced team should score above a carry plus underlevelled reserves")

def test_spread_at_or_below_ten_scores_full_balance():
    close=Fake([20,10,13])
    close.party_level_tolerance=10
    check(close.get_party_level_balance_score()==1.0,"a spread of exactly 10 must score 100%")
    within=Fake([20,11,13])
    within.party_level_tolerance=10
    check(within.get_party_level_balance_score()==1.0,"a spread below 10 must score 100%")

def test_spread_above_ten_scores_target_over_spread():
    far=Fake([50,2])
    far.party_level_tolerance=10
    check(abs(far.get_party_level_balance_score()-(10/48))<1e-9,"a 48-level spread should score 10/48, not be divided by six")
    near=Fake([35,24])
    near.party_level_tolerance=10
    check(abs(near.get_party_level_balance_score()-(10/11))<1e-9,"an 11-level spread should be just over target")

def test_single_member_is_balanced_but_empty_party_is_not():
    one=Fake([35])
    check(one.get_party_level_balance_score()==1.0,"one active member has zero spread")
    empty=Fake([])
    check(empty.get_party_level_balance_score()==0.0,"an empty party should not show a perfect balance score")

def test_duplicate_species_do_not_increase_diversity():
    varied=Fake([10,10,10],[25,4,7]); duplicate=Fake([10,10,10],[25,25,25])
    check(varied.get_party_diversity_score()>duplicate.get_party_diversity_score(),"unique species must be preferred")

for fn in (test_balance_score_is_independent_of_party_size,test_balanced_team_scores_more_than_overlevelled_carry,test_spread_at_or_below_ten_scores_full_balance,test_spread_above_ten_scores_target_over_spread,test_single_member_is_balanced_but_empty_party_is_not,test_duplicate_species_do_not_increase_diversity):
    fn(); print("PASS",fn.__name__)
print("All party balance/diversity tests passed.")
