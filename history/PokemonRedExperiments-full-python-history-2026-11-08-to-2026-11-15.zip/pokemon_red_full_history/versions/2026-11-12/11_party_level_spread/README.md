# Pokémon Red — balanced party + starter-choice diversity update

This update builds on the existing balanced/diverse party environment and most-advanced-party TensorBoard callback. It does not force a starter or modify the action/observation spaces.

## Why the policy keeps selecting Charmander

The previous party patch rewarded collecting distinct Pokémon and balancing party levels, but it had no reward for choosing a less-used *starter*. A resumed PPO policy can therefore keep repeating a preference learned before the start state was changed.

## What this update changes

- Tracks Bulbasaur, Charmander, and Squirtle selections in `starter_choice_counts.sqlite3` inside the TensorBoard session directory.
- All parallel workers share this database. SQLite transactions serialize simultaneous choices safely.
- The currently least-selected starter gets the full novelty reward. Repeating an overrepresented starter earns less.
- The agent still chooses by taking its own movement and A-button actions. No worker is assigned a species and no action is injected.
- The choice history survives PPO checkpoint resumes as long as the same session directory is reused.
- TensorBoard adds `game/starter_choices/bulbasaur`, `game/starter_choices/charmander`, `game/starter_choices/squirtle`, and `game/starter_diversity_reward_mean`.
- `show_starter_counts.py` prints the three persistent counts.
- The balanced-party, capture, and HM objectives are preserved. Observation keys/shapes, action space, and PPO architecture are unchanged.

## Reward behaviour

Default `starter_diversity_weight` is 20.0. With the existing `reward_scale=0.5`, the first choice receives up to 10 reward points. The novelty bonus is:

`weight * (least_used_count + 1) / (chosen_starter_count + 1)`

For example, after Charmander has been selected once and Bulbasaur/Squirtle have not been selected, another Charmander receives half the bonus while either underrepresented starter receives the full bonus.

This encourages a balanced population of choices; it does not guarantee an exactly equal distribution. The policy still needs stochastic exploration to discover alternative action sequences.

## Install (Fish / Konsole)

Stop training and back up the current files:

```fish
cp red_gym_env_v2.py red_gym_env_v2.py.before_starter_diversity
cp tensorboard_callback.py tensorboard_callback.py.before_starter_diversity
```

Extract and copy the files into your `v2` directory:

```fish
unzip -o /path/to/pokemon_red_starter_diversity_patch.zip -d /tmp/pokemon_red_starter_diversity
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/red_gym_env_v2.py .
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/starter_diversity.py .
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/tensorboard_callback.py .
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/test_starter_diversity.py .
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/show_starter_counts.py .
```

Validate with the project's `.venv` active:

```fish
python -m py_compile red_gym_env_v2.py starter_diversity.py tensorboard_callback.py test_starter_diversity.py show_starter_counts.py
python test_starter_diversity.py
python show_starter_counts.py runs
```

## Resume training

Keep your single pre-starter save state (`../starter_choice.state`) and resume the existing PPO checkpoint. Add `--ent-coef 0.05` to fine-tune with more stochastic exploration, plus `--init-state ../starter_choice.state` if it is not already in your command. Keep the same session directory so starter counts persist.

Do not delete `starter_choice_counts.sqlite3` between resumes; it is the shared memory for population-level starter balance. Delete it only if you intentionally want to restart the starter-frequency experiment from zero.

## Notes

- If the start state already contains a starter in the party, the environment treats it as preselected and does not award a policy-choice bonus. The intended initial state has party count zero and all three Poké Balls available.
- `--ent-coef 0.05` raises policy entropy during fine-tuning; it may increase exploration in other parts of the game too. If that destabilizes progression, reduce it to `0.03`.
- This reward only affects choices discovered after installing the patch. Existing checkpoint weights are preserved and must be fine-tuned to learn the new objective.
- Unit tests cover reward ranking, persistence across process restarts, concurrent writes, and invalid species rejection. A live PyBoy/SB3 training run is still required to confirm the agent learns to vary its choices.


## Level-spread target update (November 2026)

- The active party's maximum-minus-minimum level spread is now the direct balance measure.
- Default target is **10 levels** (`party_level_tolerance=10`). At or below 10, the balance score is 100%. Above 10, the score is `10 / actual_spread`.
- The previous implementation divided by six even when fewer than six Pokémon were in the party. That could cap a well-levelled small party at 16.7% or 33.3%, making the score look stuck. Party size is tracked separately by party-size/diversity metrics.
- The reward is now an explicit potential penalty for exceeding the 10-level target: each 10 levels above target adds one balance-weight unit of penalty. Improvement in the spread returns that potential reward. The default `party_balance_weight` is 5.0 (was 2.5).
- Added TensorBoard metrics: `game/party_level_spread_target_mean`, `game/party_level_spread_excess_mean`, and `game/party_spread_within_target_mean`. The most-advanced-party image shows spread as `actual/10 max`.
- This is a strong training objective, not a hard game rule: the agent can still temporarily exceed 10 levels, but receives a penalty until it brings the weaker active party members up.

## Install this level-spread correction

Stop the trainer first, then back up the environment and callback in the project directory:

```fish
cp red_gym_env_v2.py red_gym_env_v2.py.before_level_spread_fix
cp tensorboard_callback.py tensorboard_callback.py.before_level_spread_fix
```

Extract the patch and copy the updated files:

```fish
unzip -o /path/to/pokemon_red_party_level_spread_patch.zip -d /tmp/party_level_spread_fix
cp /tmp/party_level_spread_fix/pokemon_red_balanced_diverse_party/red_gym_env_v2.py .
cp /tmp/party_level_spread_fix/pokemon_red_balanced_diverse_party/tensorboard_callback.py .
cp /tmp/party_level_spread_fix/pokemon_red_balanced_diverse_party/test_party_balance.py .
```

With the project's `.venv` active, run:

```fish
python -m py_compile red_gym_env_v2.py tensorboard_callback.py
python test_party_balance.py
python test_capture_rewards.py
python test_starter_diversity.py
```

Resume the same PPO checkpoint and session directory, retaining `--init-state ../starter_choice.state` and any starter-diversity settings you already use. The target and reward are read by the environment on each launch; no policy/observation shape change is made. The next TensorBoard samples will use the corrected score; historical samples are not rewritten.

### Reading the corrected score

- 100%: current active party's level spread is 10 or less.
- 90.9%: spread is 11.
- 50%: spread is 20.
- 20.8%: spread is 48.
- The score measures spread only; the separate party-species-count metric measures team size/diversity. One active Pokémon has no spread and therefore scores 100%; an empty party scores 0%.
- This is a reward objective, not a hard-coded game constraint. The policy can temporarily exceed 10 levels, but the excess-level penalty encourages it to train its weaker party members.
