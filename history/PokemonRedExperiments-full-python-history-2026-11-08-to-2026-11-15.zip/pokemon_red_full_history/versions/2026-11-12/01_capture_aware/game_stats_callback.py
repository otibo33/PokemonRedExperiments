"""TensorBoard callback for metrics returned by RedGymEnv.step()."""

from __future__ import annotations

import numpy as np
from stable_baselines3.common.callbacks import BaseCallback


class GameStatsCallback(BaseCallback):
    """Log averaged game metrics every ``every`` environment timesteps.

    Works with Stable-Baselines3 vector environments. Unlike counting
    ``n_calls``, ``num_timesteps`` accounts for all parallel environments.
    """

    KEYS = (
        "map_progress",
        "seen_tiles",
        "visited_maps",
        "badges",
        "events",
        "levels_sum",
        "deaths",
        "story_milestone_score",
        "pokedex_owned",
        "lifetime_best_owned_count",
        "new_dex_entries",
        "captures",
        "party_size",
        "party_species_count",
        "pokeballs",
    )

    def __init__(self, every: int = 2560, verbose: int = 0):
        if every <= 0:
            raise ValueError("every must be a positive integer")
        super().__init__(verbose=verbose)
        self.every = int(every)
        self._last_log_timestep = 0

    def _on_step(self) -> bool:
        if self.num_timesteps - self._last_log_timestep < self.every:
            return True

        self._last_log_timestep = self.num_timesteps
        infos = self.locals.get("infos", ())

        for key in self.KEYS:
            values = []
            for info in infos:
                if not isinstance(info, dict) or key not in info:
                    continue
                value = info[key]
                if isinstance(value, (int, float, np.number)):
                    values.append(float(value))

            if values:
                self.logger.record(f"game/{key}", float(np.mean(values)))

        return True
