# Pokémon Red capture-aware training patch

This patch adds explicit Pokémon-collection objectives to the saved `RedGymEnv` implementation while preserving the existing PPO observation/action spaces.

## What changed

- Detects successful captures by pairing the game's `wCapturedMonSpecies` marker at WRAM `0xD11C` with a new Pokédex-owned flag.
- Tolerates the capture marker and Pokédex bit being observed on adjacent emulator steps.
- Counts owned Pokédex entries at `0xD2F7`–`0xD309`, ignoring the unused #152 bit.
- Reads party count/species at `0xD163`/`0xD164` onward and rewards growth in the number of distinct Pokémon carried in the active party.
- Counts Master, Ultra, Great, and Poké Balls in the bag (item IDs `01`, `02`, `03`, `04`; Safari Balls are tracked separately by the game) and rewards stocking a modest reserve. The inventory reward uses a high-water mark, so buying, using, and rebuying the same balls cannot repeatedly farm the reward.
- Adds `pokedex_owned`, `lifetime_best_owned_count`, `new_dex_entries`, `captures`, `party_size`, `party_species_count`, and `pokeballs` to `info` and to the `GameStatsCallback` TensorBoard logs (`game/*`).
- Retains the PyBoy performance tweaks from the previously supplied optimizer patch: `sound_emulated=False`, no rendering on the press portion of each action, and no redundant final one-frame tick.

With the current training config's `reward_scale=0.5`, defaults are:

| Objective | Weight | Effective reward |
|---|---:|---:|
| Confirmed new capture | 16.0 | +8.0 |
| New owned Pokédex entry | 2.0 | +1.0 per entry |
| Additional distinct party species above baseline | 3.0 | +1.5 per species |
| Increase in catch-ball stock | 0.5 | +0.25 per ball, capped at 10 |

These are cumulative high-water rewards. Losing HP or using a ball does not erase progress. The baseline is read from the loaded initial save state, so Pokémon already owned there are not awarded again.

## Compatibility

The policy observation dictionary and every observation shape are unchanged. This patch therefore remains compatible with PPO checkpoints trained with the previous observation layout, assuming the local environment file has no additional, unshared changes. The retained PyBoy constructor/tick optimizations target the PyBoy 2.x API used by the project updates.

This is a reward-and-telemetry improvement, not a trained model. Running `run_pretrained_interactive.py` only performs inference; it will not update the policy. Fine-tune the existing checkpoint with the training script before expecting the policy to learn the new objective.

## Install

Stop the running interactive/training process first. From the project's `v2` directory, back up the current files and copy the two replacements from this archive:

```bash
cp red_gym_env_v2.py "red_gym_env_v2.py.before-capture-$(date +%Y%m%d-%H%M%S)"
cp game_stats_callback.py "game_stats_callback.py.before-capture-$(date +%Y%m%d-%H%M%S)"
```

Then copy the archive's `red_gym_env_v2.py` and `game_stats_callback.py` into that directory, replacing the originals. If your local files contain changes made after the November 10 versions this patch was built from, compare/merge before replacing them rather than overwriting those later changes.

Using the same Python environment used for your project, verify:

```bash
python -m py_compile red_gym_env_v2.py game_stats_callback.py
python -c "from red_gym_env_v2 import RedGymEnv; print('RedGymEnv import OK')"
python test_capture_rewards.py
```

The included tests use stubs for PyBoy/Gymnasium so they test RAM parsing and reward logic without launching the emulator. A live ROM/emulator integration test is still required on your machine.

## Fine-tune the existing checkpoint

Do not pass `--nav`; that option changes the observation space and is not compatible with the old checkpoint. Use the same checkpoint currently loaded by your interactive runner. Example, if that checkpoint is `runs/poke_interrupted.zip`:

```bash
python baseline_run_paralell.py \
  --resume runs/poke_interrupted.zip \
  --timesteps 10000000 \
  --num-cpu 16 \
  --session-dir runs_capture_aware
```

The separate `runs_capture_aware` directory keeps the previous logs/checkpoints intact. The trainer saves new checkpoints there and finishes with `runs_capture_aware/poke_final.zip`. Adjust the `--resume` path and worker count to match your actual checkpoint and current machine.

After fine-tuning, point `run_pretrained_interactive.py` at the new `poke_final.zip` using that script's existing model-path option/configuration. I have not assumed its CLI argument because that script was not among the project files available for this patch.

## Validation performed here

- `py_compile` passed for the updated environment and callback.
- Six focused tests passed: Pokédex bit counting, party diversity, catch-ball inventory, capture-marker-before-Dex pairing, Dex-before-capture-marker pairing, no false capture from a Dex-only change, and reward-weight calculations.
- The full PyBoy + ROM training/inference loop was not executable in this build environment and must be tested locally.
