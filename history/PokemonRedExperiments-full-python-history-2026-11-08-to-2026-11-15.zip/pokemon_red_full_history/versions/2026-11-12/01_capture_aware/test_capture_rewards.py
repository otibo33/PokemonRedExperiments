from __future__ import annotations

import importlib.util
import sys
import types
from pathlib import Path

# Stub runtime-only libraries so the RAM/reward helpers can be tested without
# launching PyBoy or installing the full training stack in this build sandbox.
gym = types.ModuleType('gymnasium')
class Env: pass
class Spaces: pass
gym.Env = Env
gym.spaces = Spaces()
sys.modules['gymnasium'] = gym

pyboy = types.ModuleType('pyboy')
class PyBoy: pass
pyboy.PyBoy = PyBoy
pyboy_utils = types.ModuleType('pyboy.utils')
class WindowEvent: pass
pyboy_utils.WindowEvent = WindowEvent
sys.modules['pyboy'] = pyboy
sys.modules['pyboy.utils'] = pyboy_utils

mediapy = types.ModuleType('mediapy')
sys.modules['mediapy'] = mediapy

global_map = types.ModuleType('global_map')
global_map.local_to_global = lambda *args: (0, 0)
global_map.GLOBAL_MAP_SHAPE = (48, 48)
sys.modules['global_map'] = global_map

module_path = Path(__file__).with_name('red_gym_env_v2.py')
spec = importlib.util.spec_from_file_location('red_gym_env_capture_test', module_path)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

class FakeEnv(mod.RedGymEnv):
    def __init__(self):
        self.memory = {}
        self.base_owned_count = 0
        self.max_owned_count = 0
        self.last_owned_count = 0
        self.last_captured_species = 0
        self.capture_pending_steps = 0
        self.pending_dex_entries = 0
        self.pending_dex_steps = 0
        self.capture_count = 0
        self.new_dex_entries = 0
        self.lifetime_best_owned_count = 0
        self.base_party_size = 1
        self.max_party_size = 1
        self.base_unique_party_count = 1
        self.max_unique_party_count = 1
        self.base_pokeballs = 5
        self.max_pokeballs = 5
        self.ball_goal = 10
        self.reward_scale = 0.5
        self.capture_reward_weight = 16.0
        self.dex_reward_weight = 2.0
        self.party_reward_weight = 3.0
        self.ball_reward_weight = 0.5
        self.max_event_rew = 0
        self.max_level_rew = 0
        self.total_healing_rew = 0
        self.explore_weight = 0.25
        self.map_progress_weight = 5.0
        self.stuck_penalty_weight = 1.0
        self.max_map_progress = 0
        self.seen_coords = {}
        self._event_cache = [0] * (mod.event_flags_end - mod.event_flags_start)

    def read_m(self, address):
        return self.memory.get(address, 0)

    def update_max_event_rew(self): return 0
    def get_levels_reward(self): return 0
    def get_badges(self): return 0
    def get_current_coord_count_reward(self): return 0


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def test_dex_count_masks_unused_bit():
    env = FakeEnv()
    env.memory[0xD2F7] = 0b00000011  # two valid species
    env.memory[0xD309] = 0b11000000  # #151 bit valid; #152 bit ignored
    check(env.read_pokedex_owned_count() == 3, 'Dex bit counting/mask failed')


def test_party_and_bag_parsing():
    env = FakeEnv()
    env.memory[mod.PARTY_COUNT_ADDRESS] = 3
    env.memory[0xD164] = 25
    env.memory[0xD165] = 4
    env.memory[0xD166] = 25
    check(env.read_unique_party_count() == 2, 'Unique party count failed')
    env.memory[mod.NUM_BAG_ITEMS_ADDRESS] = 3
    for idx, (item, qty) in enumerate([(4, 6), (0x14, 2), (3, 3)]):
        env.memory[mod.BAG_ITEMS_START + idx * 2] = item
        env.memory[mod.BAG_ITEMS_START + idx * 2 + 1] = qty
    check(env.read_pokeball_count() == 9, 'catch-ball inventory count failed')


def test_capture_marker_then_dex():
    env = FakeEnv()
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 25
    env.update_pokemon_progress()
    check(env.capture_pending_steps > 0 and env.capture_count == 0,
          'Capture marker should wait for the Dex bit')
    env.memory[0xD2F7] = 1
    env.update_pokemon_progress()
    check(env.capture_count == 1, 'Capture was not counted when Dex bit arrived after marker')


def test_dex_then_capture_marker():
    env = FakeEnv()
    env.memory[0xD2F7] = 1
    env.update_pokemon_progress()
    check(env.pending_dex_entries == 1 and env.capture_count == 0,
          'Unmatched Dex entry should be held briefly')
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 4
    env.update_pokemon_progress()
    check(env.capture_count == 1, 'Capture was not counted when marker arrived after Dex bit')


def test_evolution_or_gift_is_not_mislabelled_without_capture_marker():
    env = FakeEnv()
    env.memory[0xD2F7] = 1
    env.update_pokemon_progress()
    check(env.capture_count == 0, 'Dex increase alone must not count as a capture')


def test_rewards_are_monotonic_and_capture_is_weighted():
    env = FakeEnv()
    env.capture_count = 1
    env.max_owned_count = 2
    env.max_unique_party_count = 2
    env.max_pokeballs = 10
    rewards = env.get_game_state_reward()
    check(rewards['capture'] == 8.0, 'Capture reward weight/scale incorrect')
    check(rewards['dex'] == 2.0, 'Dex reward incorrect')
    check(rewards['party'] == 1.5, 'Party reward incorrect')
    check(rewards['balls'] == 1.25, 'Ball supply reward incorrect')


for test in (
    test_dex_count_masks_unused_bit,
    test_party_and_bag_parsing,
    test_capture_marker_then_dex,
    test_dex_then_capture_marker,
    test_evolution_or_gift_is_not_mislabelled_without_capture_marker,
    test_rewards_are_monotonic_and_capture_is_weighted,
):
    test()
    print('PASS', test.__name__)
print('All capture-aware reward tests passed.')
