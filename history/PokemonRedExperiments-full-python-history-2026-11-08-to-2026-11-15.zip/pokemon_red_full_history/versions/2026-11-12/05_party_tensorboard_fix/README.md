# Pokémon Red parallel TensorBoard party-image fix

This fixes the party-image pipeline for `baseline_run_paralell.py` / `SubprocVecEnv`.
It does not require `run_pretrained_interactive.py`.

## What changed

- `GameStatsCallback` now queries every live worker directly with
  `env_method("read_party_snapshot")` when it writes images. It falls back to
  the step `infos` payload for compatible older wrappers.
- It writes the first six-slot party board and gameplay-plus-party image as soon
  as training starts, instead of making you wait for the first 40,960 aggregate
  timesteps.
- It prints diagnostic messages by default: how many workers were found, how
  many party images were written, and whether the TensorBoard image writer is
  missing.
- The recurring image cadence remains every 40,960 aggregate timesteps by
  default. Change `image_every` when constructing `GameStatsCallback` to alter it.

Expected TensorBoard **Images** tags:

- `game/party_visual/env_00` (one tag for each worker)
- `gameplay/with_party/env_00` (one tag for each worker, if the worker returns a game frame)

## Install safely

Stop the current Python training process first. A running Python process does
not reload a callback module after the file is overwritten.

From the project's `v2` directory, back up and replace the two files:

```bash
stamp=$(date +%Y%m%d-%H%M%S)
cp red_gym_env_v2.py "red_gym_env_v2.py.before-partyfix-$stamp"
cp game_stats_callback.py "game_stats_callback.py.before-partyfix-$stamp"

# Extract this ZIP, then copy these files from its folder into the v2 folder:
cp /path/to/pokemon_red_party_tensorboard_fix/red_gym_env_v2.py .
cp /path/to/pokemon_red_party_tensorboard_fix/game_stats_callback.py .
cp /path/to/pokemon_red_party_tensorboard_fix/test_capture_rewards.py .
cp /path/to/pokemon_red_party_tensorboard_fix/test_party_tensorboard.py .
cp /path/to/pokemon_red_party_tensorboard_fix/test_party_visualization.py .
```

Keep your existing `global_map.py`, `events.json`, ROM and save-state files.

## Verify the files the trainer will import

Run these from the `v2` directory using the same venv as training:

```bash
python - <<'PY'
import game_stats_callback
from game_stats_callback import GameStatsCallback
import red_gym_env_v2
from red_gym_env_v2 import RedGymEnv
print("callback:", game_stats_callback.__file__)
print("environment:", red_gym_env_v2.__file__)
print("callback image method:", hasattr(GameStatsCallback, "_log_party_images"))
print("environment party reader:", hasattr(RedGymEnv, "read_party_snapshot"))
print("environment frame reader:", hasattr(RedGymEnv, "get_tensorboard_frame"))
PY

grep -n 'GameStatsCallback' baseline_run_paralell.py
python -m py_compile red_gym_env_v2.py game_stats_callback.py
python test_capture_rewards.py
python test_party_tensorboard.py
python test_party_visualization.py
```

The trainer must import `GameStatsCallback` from `game_stats_callback.py`. If it
imports a different callback module, that trainer is not using this visualizer.

## Restart and view

Restart parallel training from the same checkpoint. For the first image, the
callback should print something similar to:

```text
[GameStatsCallback] Party image logging enabled for 16 worker(s).
[GameStatsCallback] Party images logged: 16; workers without party snapshots: 0; timestep=...; writers=1
```

Open TensorBoard against the exact session directory printed by the trainer.
For the default legacy run this is usually `runs`; with `--session-dir`, use that
specified directory. Open **Images**, expand `game/party_visual`, and select
`env_00` (or another worker). The gameplay composite is under `gameplay/with_party`.

## Interpreting diagnostics

- `No TensorBoard image writer found`: TensorBoard output is not configured for
  this run, or a different logger is in use. The trainer should set
  `tensorboard_log` to the active session directory.
- `workers without party snapshots` greater than zero: the environment method
  is missing or the worker is running a different environment file. Check the
  printed import paths above.
- `Party images logged: 16`: the callback wrote images for all 16 workers. If
  TensorBoard still shows no images, it is almost certainly pointed at a
  different log directory or has not refreshed/reloaded the event data.

The visualizer still uses local Gen-I sprites when available and a numeric
Pokédex fallback when the sprite cache is absent. This does not affect whether
an image is emitted.

## Validation

Python syntax compilation and the focused offline capture, party-table and
party-image tests pass. A live 16-worker PyBoy run cannot be simulated here;
the new startup diagnostics tell us exactly which stage succeeds on the user's
machine.
