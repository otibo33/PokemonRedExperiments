"""Tests for TensorBoard party-table formatting without requiring SB3."""
import importlib.util
import sys
import types
from pathlib import Path

sb3 = types.ModuleType("stable_baselines3")
common = types.ModuleType("stable_baselines3.common")
callbacks = types.ModuleType("stable_baselines3.common.callbacks")
class BaseCallback:
    def __init__(self, verbose=0):
        self.verbose = verbose
        self.logger = None
        self.locals = {}
        self.num_timesteps = 0
callbacks.BaseCallback = BaseCallback
sys.modules["stable_baselines3"] = sb3
sys.modules["stable_baselines3.common"] = common
sys.modules["stable_baselines3.common.callbacks"] = callbacks

path = Path(__file__).with_name("game_stats_callback.py")
spec = importlib.util.spec_from_file_location("party_callback_test", path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

class Writer:
    def __init__(self):
        self.text = []
        self.scalars = []
        self.flushed = False
    def add_text(self, tag, text, global_step):
        self.text.append((tag, text, global_step))
    def add_scalar(self, tag, value, global_step):
        self.scalars.append((tag, value, global_step))
    def flush(self):
        self.flushed = True

class OutputFormat:
    def __init__(self, writer):
        self.writer = writer

writer = Writer()
callback = module.GameStatsCallback(every=10, party_every=20)
callback.logger = types.SimpleNamespace(output_formats=[OutputFormat(writer)])
callback.num_timesteps = 20
callback.locals = {"infos": [{"party_snapshot": [{
    "slot": 1, "species_index": 0xB1, "species": "Squirtle", "level": 12,
    "hp": 25, "max_hp": 30, "status": "OK", "moves": ["Surf", "Tackle"],
    "hm_can_learn": ["SURF"], "hm_knows": ["SURF"],
}]}]}
assert callback._on_step() is True
assert len(writer.text) == 1
assert writer.text[0][0] == "game/party/env_00"
assert "Squirtle" in writer.text[0][1] and "Surf" in writer.text[0][1]
assert "HM compatibility" in writer.text[0][1]
assert writer.flushed
assert any(tag.endswith("/level") and value == 12 for tag, value, _ in writer.scalars)
print("All TensorBoard party callback tests passed.")
