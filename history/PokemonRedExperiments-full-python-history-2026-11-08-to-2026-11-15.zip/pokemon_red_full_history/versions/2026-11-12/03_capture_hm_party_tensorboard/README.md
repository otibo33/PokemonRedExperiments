# Pokémon Red capture-aware + HM-planning patch

This patch adds explicit Pokémon collection and HM progression objectives to the supplied Pokémon Red `RedGymEnv`, while preserving the existing PPO observation and action spaces.

## HM awareness

For each of the five Generation I HMs, the environment distinguishes:

1. **HM item owned** — the HM item is present in the bag.
2. **Compatible party member** — at least one Pokémon currently in the party can learn that HM in English Red/Blue.
3. **Move taught** — at least one current party member has the HM move in one of its four move slots.
4. **Badge owned** — the correct Gym Badge bit is set.
5. **Field-ready** — the HM item, taught move, and required badge are all present.

The badge gates are Cascade/Cut, Thunder/Fly, Soul/Surf, Rainbow/Strength, and Boulder/Flash. Cut, Surf, and Strength are marked as main-story-critical; Fly and Flash are useful but optional.

### Compatibility and memory interpretation

Important: party species bytes in Red/Blue use the game's **internal species indexes**, not National Pokédex numbers. The compatibility sets in the source are keyed by those internal indexes. They were transcribed from the Generation I field-move compatibility table and cross-referenced to the Red/Blue internal-index list. The table includes less obvious learners such as Lickitung (Surf), Pinsir (Strength), and Jolteon (Flash). The table is specifically for Red/Blue; version-specific Yellow compatibility differences are excluded. For a compact Red/Blue HM helper pair, Slowbro can cover Surf/Strength/Flash while Farfetch'd covers Cut/Fly; the agent is rewarded for this coverage without being forced to teach every HM to one Pokémon.

The environment reads:

- Party count/species list: `0xD163` / `0xD164` onward.
- First party record: `0xD16B`, 44 bytes per Pokémon.
- Four move IDs: party record offsets `0x08`–`0x0B`.
- Badge byte: `0xD356`; Boulder bit 0, Cascade bit 1, Thunder bit 2, Rainbow bit 3, Soul bit 4.
- Bag count/items: `0xD31D` / `0xD31E` item-quantity pairs.
- HM item IDs: `0xC4`–`0xC8` (HM01–HM05).
- Move IDs: Cut `0x0F`, Fly `0x13`, Surf `0x39`, Strength `0x46`, Flash `0x94`.

### Reward ladder

The agent receives reward shaping for:

- Having a current party member that can learn an HM (encourages catching and carrying useful species).
- Acquiring the HM item.
- Teaching the move.
- Meeting the badge gate so the HM is field-ready.

The compatibility weights prioritize Surf, Strength, and Cut. Per-episode high-water marks prevent repeatedly farming the same objective by swapping party members or moving through menus. Small current-state penalties discourage depositing the only HM-compatible or HM-ready Pokémon and losing field access. HM progress already present in the initial save-state is used as the baseline and is not rewarded again.

Default HM coefficients (the project config uses `reward_scale=0.5`):

| Stage | Config key | Default |
|---|---|---:|
| Compatible party member | `hm_candidate_reward_weight` | 2.0 |
| HM item acquired | `hm_item_reward_weight` | 0.75 |
| HM move taught | `hm_taught_reward_weight` | 1.5 |
| Field-ready | `hm_ready_reward_weight` | 2.5 |
| Lost compatible party coverage | `hm_candidate_loss_penalty_weight` | 1.0 |
| Lost field-ready HM access | `hm_ready_loss_penalty_weight` | 0.5 |

This is planning/reward support, not a scripted walkthrough. The policy still has to navigate to the HM locations, interact with NPCs, use the item/party menus, and teach the moves itself. Compatibility is checked against the active party; a compatible Pokémon stored in Bill's PC is not counted as immediately usable.

## TensorBoard metrics

Summary metrics include:

- `game/hm_party_compatible`, `game/hm_items_owned`, `game/hm_moves_taught`, `game/hm_field_ready`
- `game/hm_critical_party_compatible`, `game/hm_critical_items_owned`, `game/hm_critical_moves_taught`, `game/hm_critical_ready`
- `game/hm_candidate_coverage_gap` and `game/hm_ready_coverage_gap` (weighted coverage lost from the episode's best state)

For each HM, individual flags are logged. For example, Cut has `game/hm_cut_party_compatible`, `game/hm_cut_item_owned`, `game/hm_cut_taught`, `game/hm_cut_badge`, and `game/hm_cut_usable`. Equivalent metrics are present for Fly, Surf, Strength, and Flash. They are also returned through the environment's `info` dictionary and terminal episode snapshot.

## TensorBoard party viewer

The training callback also writes a human-readable party table to TensorBoard's **Text** dashboard. Each parallel SubprocVecEnv worker is logged separately as `game/party/env_00`, `game/party/env_01`, and so on. Tables refresh every 10,240 aggregate timesteps by default (configure with `GameStatsCallback(party_every=...)`).

Each party table includes slot, species name (resolved from the Red/Blue internal species index), level, current/max HP, status, four moves (decoded to their Generation I names), HM compatibility, and HM moves currently known. The callback also writes per-slot level, HP fraction, and internal species index scalars. This is live training-worker state, not a view of the separate `run_pretrained_interactive.py` process.

To view it: start TensorBoard with your run log directory, open the **Text** tab, and select `game/party/env_00` (or another worker). TensorBoard's **Scalars** tab contains the per-slot numeric series.

## Capture tracking retained

The existing capture-aware logic remains: it pairs the capture marker at `0xD11C` with a newly acquired Pokédex-owned flag, counts owned Dex entries, measures distinct active-party species, and rewards maintaining a reserve of catching balls.

## Existing PPO checkpoint compatibility

No observation keys, data types, tensor shapes, or action meanings are changed. Existing checkpoints trained with the same observation layout remain loadable, assuming your local environment files match the versions this patch was built from.

This patch changes rewards and telemetry; it does **not** train the model. `run_pretrained_interactive.py` only performs inference. Fine-tune the existing checkpoint with the training script after installing this patch. Do not pass `--nav` when resuming a checkpoint trained without navigation observations.

## Install

Stop the training or interactive process first. From the project's `v2` directory, back up the existing files:

```bash
cp red_gym_env_v2.py "red_gym_env_v2.py.before-hm-$(date +%Y%m%d-%H%M%S)"
cp game_stats_callback.py "game_stats_callback.py.before-hm-$(date +%Y%m%d-%H%M%S)"
```

Copy the archive's `red_gym_env_v2.py`, `game_stats_callback.py`, `test_capture_rewards.py`, and `test_party_tensorboard.py` into that same directory. Keep your project's `events.json` and `global_map.py` unchanged.

Run checks with the same virtual environment used for training:

```bash
python -m py_compile red_gym_env_v2.py game_stats_callback.py test_capture_rewards.py test_party_tensorboard.py
python -c "from red_gym_env_v2 import RedGymEnv; print('RedGymEnv import OK')"
python test_capture_rewards.py
python test_party_tensorboard.py
```

The included tests stub out PyBoy and Gymnasium to check RAM parsing and reward logic without starting the emulator. A live PyBoy + ROM smoke test is still required before a long training run.

## Fine-tuning example

Use the same checkpoint loaded by your interactive runner and the existing training script's session-directory option:

```bash
python baseline_run_paralell.py \
  --resume runs/poke_interrupted.zip \
  --timesteps 10000000 \
  --num-cpu 16 \
  --session-dir runs_hm_aware
```

Adjust the checkpoint path and worker count to match your setup. The new session directory preserves previous logs/checkpoints. Do not use `--nav` unless starting a fresh model.

## Validation performed here

- Python syntax compilation passed for the environment, callback, and tests.
- Seventeen focused tests cover capture/Dex detection, party parsing, ball inventory, Red/Blue-specific HM compatibility (including less obvious learners), move-slot parsing, item ownership, badge gating, field readiness, coverage-retention penalties, and high-water HM progress, party snapshot parsing, internal species-name anchors, and TensorBoard party-table formatting.
- A live ROM/emulator training run was not available here. Verify against your exact ROM/build before launching a long fine-tune.

## Data references

- [Bulbapedia — Generation I field-move compatibility](https://bulbapedia.bulbagarden.net/wiki/List_of_Pok%C3%A9mon_by_field_move_%28Generation_I%29)
- [Data Crystal — Red/Blue internal species indexes and move IDs](https://datacrystal.tcrf.net/wiki/Pok%C3%A9mon_Red_and_Blue:Notes)
- [Bulbapedia — Generation I Pokémon data structure](https://bulbapedia.bulbagarden.net/wiki/Pokemon_data_structure_in_Generation_I)
- [pret/pokered — move constants](https://github.com/pret/pokered/blob/master/constants/move_constants.asm)
- [pret/pokered — RAM badge bit constants](https://github.com/pret/pokered/blob/master/constants/ram_constants.asm)
- [pret/pokered — HM item ID constants](https://github.com/pret/pokeyellow/blob/master/constants/item_constants.asm)
