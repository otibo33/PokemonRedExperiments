"""TensorBoard callback for Pokémon Red scalar metrics and party snapshots."""

from __future__ import annotations

import numpy as np
from stable_baselines3.common.callbacks import BaseCallback


class GameStatsCallback(BaseCallback):
    """Log game metrics and human-readable party tables to TensorBoard.

    Each SubprocVecEnv worker is a separate game instance; its current party is
    logged under ``game/party/env_XX`` in TensorBoard's Text dashboard.
    """

    KEYS = (
        "map_progress", "seen_tiles", "visited_maps", "badges", "events",
        "levels_sum", "deaths", "story_milestone_score", "pokedex_owned",
        "lifetime_best_owned_count", "new_dex_entries", "captures", "party_size",
        "party_species_count", "pokeballs", "hm_party_compatible", "hm_items_owned",
        "hm_moves_taught", "hm_field_ready", "hm_critical_ready",
        "hm_critical_candidates_complete", "hm_critical_ready_complete",
        "hm_candidate_coverage_gap", "hm_ready_coverage_gap",
        "hm_cut_party_compatible", "hm_cut_item_owned", "hm_cut_taught", "hm_cut_badge", "hm_cut_usable",
        "hm_fly_party_compatible", "hm_fly_item_owned", "hm_fly_taught", "hm_fly_badge", "hm_fly_usable",
        "hm_surf_party_compatible", "hm_surf_item_owned", "hm_surf_taught", "hm_surf_badge", "hm_surf_usable",
        "hm_strength_party_compatible", "hm_strength_item_owned", "hm_strength_taught", "hm_strength_badge", "hm_strength_usable",
        "hm_flash_party_compatible", "hm_flash_item_owned", "hm_flash_taught", "hm_flash_badge", "hm_flash_usable",
    )

    def __init__(self, every: int = 2560, party_every: int = 10240, verbose: int = 0):
        if every <= 0 or party_every <= 0:
            raise ValueError("every and party_every must be positive integers")
        super().__init__(verbose=verbose)
        self.every = int(every)
        self.party_every = int(party_every)
        self._last_log_timestep = 0
        self._last_party_log_timestep = 0

    def _tensorboard_writers(self):
        """Get writers from SB3's configured TensorBoard output format."""
        writers = []
        for output_format in getattr(self.logger, "output_formats", ()):
            writer = getattr(output_format, "writer", None)
            if writer is not None and hasattr(writer, "add_text"):
                writers.append(writer)
        return writers

    @staticmethod
    def _party_markdown(party):
        if not party:
            return "**Party:** empty (no Pokémon currently in party)"
        lines = [
            "| Slot | Pokémon | Lv. | HP | Status | Moves | HM compatibility | HMs known |",
            "|---:|---|---:|---:|---|---|---|---|",
        ]
        for mon in party:
            hp = f"{mon.get('hp', '?')}/{mon.get('max_hp', '?')}"
            moves = ", ".join(mon.get("moves", [])) or "—"
            compatible = ", ".join(mon.get("hm_can_learn", [])) or "—"
            taught = ", ".join(mon.get("hm_knows", [])) or "—"
            lines.append(
                f"| {mon.get('slot', '?')} | {mon.get('species', 'Unknown')} "
                f"(0x{int(mon.get('species_index', 0)):02X}) | {mon.get('level', '?')} "
                f"| {hp} | {mon.get('status', 'Unknown')} | {moves} | {compatible} | {taught} |"
            )
        return "\n".join(lines)

    def _log_party(self, infos):
        writers = self._tensorboard_writers()
        if not writers:
            return
        for env_index, info in enumerate(infos):
            if not isinstance(info, dict):
                continue
            party = info.get("party_snapshot")
            if not isinstance(party, (list, tuple)):
                continue
            markdown = self._party_markdown(party)
            for writer in writers:
                writer.add_text(
                    f"game/party/env_{env_index:02d}",
                    markdown,
                    global_step=self.num_timesteps,
                )
                # Numeric per-slot tags are useful in TensorBoard's Scalars tab.
                for mon in party:
                    slot_prefix = f"game/party/env_{env_index:02d}/slot_{int(mon.get('slot', 0)):02d}"
                    writer.add_scalar(f"{slot_prefix}/level", float(mon.get("level", 0)), self.num_timesteps)
                    max_hp = max(float(mon.get("max_hp", 0)), 1.0)
                    writer.add_scalar(f"{slot_prefix}/hp_fraction", float(mon.get("hp", 0)) / max_hp, self.num_timesteps)
                    writer.add_scalar(f"{slot_prefix}/species_index", float(mon.get("species_index", 0)), self.num_timesteps)
        for writer in writers:
            writer.flush()

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", ())
        if self.num_timesteps - self._last_log_timestep >= self.every:
            self._last_log_timestep = self.num_timesteps
            for key in self.KEYS:
                values = []
                for info in infos:
                    if not isinstance(info, dict) or key not in info:
                        continue
                    value = info[key]
                    if isinstance(value, (int, float, np.number)):
                        values.append(float(value))
                if values:
                    self.logger.record(f"game/{key}", float(np.mean(values)))

        if self.num_timesteps - self._last_party_log_timestep >= self.party_every:
            self._last_party_log_timestep = self.num_timesteps
            self._log_party(infos)

        return True
