# Pokémon Red — balanced and diverse party reward patch

This patch builds on the capture + HM + party snapshot environment and the most-advanced-party TensorBoard callback.

## What it changes

- **Distinct active species:** rewards a varied active party; duplicates do not increase the diversity score.
- **Level balance:** each active party member earns up to one-sixth credit. A teammate within 8 levels of the strongest member gets full credit; larger gaps reduce credit smoothly. This encourages bringing weaker teammates up without requiring identical levels.
- **Retention:** these are current-state reward potentials, not only lifetime high-water counters. Depositing a unique teammate or allowing the team to become badly lopsided can reduce the score.
- **HM coverage remains important:** the existing Cut/Surf/Strength planning rewards remain intact.
- **Checkpoint compatibility:** no observation keys, observation dimensions, action space, or PPO architecture are changed. This is reward shaping, so resume the existing checkpoint with fine-tuning.

## Default weights

- `party_diversity_weight = 1.5`
- `party_balance_weight = 2.5`
- `party_level_tolerance = 8`

They can be overridden in the `RedGymEnv` config dictionary. Start with defaults; do not raise these aggressively, or the agent may grind low-level team members instead of advancing the story.

## TensorBoard

New scalar tags:

- `game/party_diversity_score_mean`
- `game/party_level_balance_score_mean`
- `game/party_level_spread_mean`
- `game/most_advanced_party_diversity_score`
- `game/most_advanced_party_level_balance_score`
- `game/most_advanced_party_level_spread`

The `game/party_visual/most_advanced` image now shows unique species count, balance score, and level spread.

## Install (Fish / Konsole)

Stop training and back up the files first:

```fish
cp red_gym_env_v2.py red_gym_env_v2.py.before_party_balance
cp tensorboard_callback.py tensorboard_callback.py.before_party_balance
```

Extract and copy the files from the patch folder into your `v2` directory:

```fish
unzip -o /path/to/pokemon_red_balanced_diverse_party_patch.zip -d /tmp/pokemon_red_party_balance
cp /tmp/pokemon_red_party_balance/pokemon_red_balanced_diverse_party/red_gym_env_v2.py .
cp /tmp/pokemon_red_party_balance/pokemon_red_balanced_diverse_party/tensorboard_callback.py .
cp /tmp/pokemon_red_party_balance/pokemon_red_balanced_diverse_party/test_party_balance.py .
cp /tmp/pokemon_red_party_balance/pokemon_red_balanced_diverse_party/test_capture_rewards.py .
```

Run checks with the project's `.venv` active:

```fish
python -m py_compile red_gym_env_v2.py tensorboard_callback.py test_party_balance.py test_capture_rewards.py
python test_party_balance.py
python test_capture_rewards.py
```

Restart parallel training with the same PPO checkpoint and your chosen session directory. Because rewards changed, the existing policy needs fine-tuning; it does not need to be trained from scratch. New reward metrics start after this patch is installed.

## Limitations

- Diversity means **distinct species**, not full elemental-type coverage. The existing HM system separately encourages functional move coverage.
- The balance score is based on active party levels, not EVs/IVs or battle roles.
- Tests validate scoring logic with synthetic party levels and preserve the existing capture/HM regression suite. A live PyBoy run is still required to verify ROM RAM reads and actual learning behaviour.
