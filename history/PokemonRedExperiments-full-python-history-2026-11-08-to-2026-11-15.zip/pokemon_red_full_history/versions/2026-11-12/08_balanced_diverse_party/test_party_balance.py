from __future__ import annotations
import importlib.util, sys, types
from pathlib import Path

# Runtime-only dependency stubs; no emulator or ROM required.
gym = types.ModuleType("gymnasium")
class Env: pass
class Spaces: pass
gym.Env, gym.spaces = Env, Spaces()
sys.modules["gymnasium"] = gym
pyboy = types.ModuleType("pyboy"); pyboy.PyBoy = type("PyBoy", (), {})
pyboy_utils = types.ModuleType("pyboy.utils"); pyboy_utils.WindowEvent = type("WindowEvent", (), {})
sys.modules["pyboy"] = pyboy; sys.modules["pyboy.utils"] = pyboy_utils
sys.modules["mediapy"] = types.ModuleType("mediapy")
global_map = types.ModuleType("global_map"); global_map.local_to_global=lambda *a:(0,0); global_map.GLOBAL_MAP_SHAPE=(48,48)
sys.modules["global_map"] = global_map
p=Path(__file__).with_name("red_gym_env_v2.py")
spec=importlib.util.spec_from_file_location("balance_env_test",p); mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)

def check(ok,msg):
    if not ok: raise AssertionError(msg)

class Fake(mod.RedGymEnv):
    def __init__(self, levels, species=None):
        self.party_level_tolerance=8
        self.levels=list(levels)
        self.species=list(species if species is not None else range(1,len(levels)+1))
    def read_party_snapshot(self):
        return [{"level":v} for v in self.levels]
    def read_unique_party_count(self):
        return len(set(self.species))

def test_full_team_scores_more_than_single_mon():
    one=Fake([20],[25]); six=Fake([20,19,18,20,17,16],[25,4,7,8,9,10])
    check(six.get_party_level_balance_score()>one.get_party_level_balance_score(),"six-member team should receive more coverage credit")

def test_balanced_team_scores_more_than_overlevelled_carry():
    balanced=Fake([20,19,18,20,17,16])
    carried=Fake([40,5,4,3,2,1])
    check(balanced.get_party_level_balance_score()>carried.get_party_level_balance_score(),"balanced team should score above a carry plus underlevelled reserves")

def test_tolerance_prevents_unnecessary_grind():
    close=Fake([20,12,13])
    check(close.get_party_level_balance_score()==3/6,"members within configured tolerance should receive full credit")

def test_duplicate_species_do_not_increase_diversity():
    varied=Fake([10,10,10],[25,4,7]); duplicate=Fake([10,10,10],[25,25,25])
    check(varied.get_party_diversity_score()>duplicate.get_party_diversity_score(),"unique species must be preferred")

for fn in (test_full_team_scores_more_than_single_mon,test_balanced_team_scores_more_than_overlevelled_carry,test_tolerance_prevents_unnecessary_grind,test_duplicate_species_do_not_increase_diversity):
    fn(); print("PASS",fn.__name__)
print("All party balance/diversity tests passed.")
