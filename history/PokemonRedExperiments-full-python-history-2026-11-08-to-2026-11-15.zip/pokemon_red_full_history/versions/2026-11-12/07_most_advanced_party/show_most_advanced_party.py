#!/usr/bin/env python3
"""Print the best saved Pokémon party snapshot for a TensorBoard session."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def main() -> int:
    session = Path(sys.argv[1]).expanduser() if len(sys.argv) > 1 else Path("runs")
    snapshot = session / "_trajectory_history" / "most_advanced_party.json"
    if not snapshot.is_file():
        print(f"No saved most-advanced party yet: {snapshot}")
        print("Start/resume parallel training with the updated tensorboard_callback.py.")
        return 2

    try:
        data = json.loads(snapshot.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"Could not read {snapshot}: {exc}", file=sys.stderr)
        return 1

    print("MOST ADVANCED RUN PARTY")
    print("-----------------------")
    print(f"Worker:            {data.get('worker_index', '?')}")
    print(f"Story-map progress:{data.get('best_map_progress', '?')}")
    print(f"Best map ID:       {data.get('best_map_id', '?')}")
    print(f"Badges:            {data.get('badges', '?')}")
    print(f"Pokédex owned:     {data.get('pokedex_owned', '?')}")
    print(f"Confirmed catches: {data.get('captures', '?')}")
    print(f"Saved timestep:    {data.get('timestep', '?')}")
    print()

    party = data.get("party_snapshot", [])
    if not party:
        print("Party is empty or unavailable in this snapshot.")
        return 0

    for slot, mon in enumerate(party, start=1):
        if not isinstance(mon, dict):
            print(f"{slot}. Unknown record")
            continue
        name = mon.get("species", "Unknown")
        level = mon.get("level", "?")
        hp = mon.get("hp", "?")
        max_hp = mon.get("max_hp", "?")
        status = mon.get("status", "?")
        moves = ", ".join(str(move) for move in mon.get("moves", [])) or "—"
        can_learn = ", ".join(mon.get("hm_can_learn", [])) or "—"
        knows = ", ".join(mon.get("hm_knows", [])) or "—"
        print(f"{slot}. {name} Lv.{level} | HP {hp}/{max_hp} | {status}")
        print(f"   Moves: {moves}")
        print(f"   HM can learn: {can_learn} | HM knows: {knows}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
