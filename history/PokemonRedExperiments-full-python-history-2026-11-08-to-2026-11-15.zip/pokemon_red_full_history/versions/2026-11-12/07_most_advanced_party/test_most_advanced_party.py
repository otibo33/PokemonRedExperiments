from __future__ import annotations

import importlib.util
import sys
import tempfile
import types
from pathlib import Path

# The production project supplies Stable-Baselines3 and TensorBoard. These tiny
# test doubles allow the ranking/persistence/rendering path to be checked in a
# lightweight build environment without importing an emulator or training run.
callbacks_mod = types.ModuleType("stable_baselines3.common.callbacks")

class BaseCallback:
    def __init__(self, verbose=0):
        self.verbose = verbose
        self.training_env = None
        self.logger = None
        self.num_timesteps = 0

callbacks_mod.BaseCallback = BaseCallback
logger_mod = types.ModuleType("stable_baselines3.common.logger")

class SB3Image:
    def __init__(self, array, dataformats):
        self.array = array
        self.dataformats = dataformats

logger_mod.Image = SB3Image
stable_mod = types.ModuleType("stable_baselines3")
common_mod = types.ModuleType("stable_baselines3.common")
common_mod.callbacks = callbacks_mod
common_mod.logger = logger_mod
sys.modules.setdefault("stable_baselines3", stable_mod)
sys.modules.setdefault("stable_baselines3.common", common_mod)
sys.modules["stable_baselines3.common.callbacks"] = callbacks_mod
sys.modules["stable_baselines3.common.logger"] = logger_mod

summary_mod = types.ModuleType("torch.utils.tensorboard")
class SummaryWriter:
    def __init__(self, *args, **kwargs): pass
    def flush(self): pass
    def close(self): pass
summary_mod.SummaryWriter = SummaryWriter
sys.modules.setdefault("torch.utils.tensorboard", summary_mod)

MODULE_PATH = Path(__file__).with_name("tensorboard_callback.py")
spec = importlib.util.spec_from_file_location("party_cb_tested", MODULE_PATH)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
TensorboardCallback = module.TensorboardCallback


def test_story_progress_beats_dex_and_party_tiebreakers():
    with tempfile.TemporaryDirectory() as tmp:
        cb = TensorboardCallback(tmp)
        cb.best_party_path = Path(tmp) / "most_advanced_party.json"
        cb.history_dir = Path(tmp)
        cb.best_party_rank = None
        cb.best_party_record = None
        party0 = [{"species": "Pidgey", "level": 8, "moves": []}]
        party1 = [{"species": "Squirtle", "level": 15, "moves": ["Tackle"]}]
        assert cb._consider_party_candidate(0, {
            "best_map_progress": 5, "badges": 2, "pokedex_owned": 10,
            "party_species_count": 5, "party_snapshot": party0,
        }, 100)
        assert cb._consider_party_candidate(1, {
            "best_map_progress": 6, "badges": 0, "pokedex_owned": 2,
            "party_species_count": 1, "party_snapshot": party1,
        }, 200)
        assert cb.best_party_record["worker_index"] == 1
        assert cb.best_party_record["party_snapshot"][0]["species"] == "Squirtle"


def test_badges_break_ties_and_record_persists():
    with tempfile.TemporaryDirectory() as tmp:
        cb = TensorboardCallback(tmp)
        cb.best_party_path = Path(tmp) / "most_advanced_party.json"
        cb.history_dir = Path(tmp)
        cb.best_party_rank = None
        cb.best_party_record = None
        cb._consider_party_candidate(0, {
            "best_map_progress": 7, "map_progress": 7, "badges": 1,
            "party_snapshot": [{"species": "Pikachu"}],
        }, 300)
        cb._consider_party_candidate(1, {
            "best_map_progress": 7, "map_progress": 7, "badges": 2,
            "party_snapshot": [{"species": "Raichu"}],
        }, 400)
        assert cb.best_party_record["worker_index"] == 1
        assert cb.best_party_path.is_file()
        cb2 = TensorboardCallback(tmp)
        cb2.best_party_path = cb.best_party_path
        cb2._load_persisted_history = lambda: None
        import json
        saved = json.loads(cb.best_party_path.read_text())
        assert saved["party_snapshot"][0]["species"] == "Raichu"


def test_terminal_snapshot_used_before_worker_auto_reset():
    with tempfile.TemporaryDirectory() as tmp:
        cb = TensorboardCallback(tmp)
        cb.best_party_path = Path(tmp) / "most_advanced_party.json"
        cb.history_dir = Path(tmp)
        cb.best_party_rank = None
        cb.best_party_record = None
        info = {
            "best_map_progress": 4,
            "party_snapshot": [{"species": "Charmander"}],
            "episode_snapshot": {
                "best_map_progress": 9,
                "best_map_id": 65,
                "badges": 3,
                "party_snapshot": [{"species": "Charizard"}],
            },
        }
        assert cb._consider_party_candidate(3, info, 500, terminal=True)
        assert cb.best_party_record["party_snapshot"][0]["species"] == "Charizard"
        assert cb.best_party_record["best_map_progress"] == 9


def test_board_renderer_returns_rgb_image():
    party = [{
        "species": "Bulbasaur", "national_dex": 1, "level": 12,
        "hp": 30, "max_hp": 35, "status": "OK",
        "moves": ["Tackle", "Vine Whip"],
        "hm_can_learn": ["Cut"], "hm_knows": [],
    }]
    board = TensorboardCallback._render_party_board(
        party, 4, 12345,
        progress_meta={"best_map_progress": 8, "best_map_id": 54,
                      "badges": 2, "pokedex_owned": 8, "captures": 6,
                      "timestep": 12345},
    )
    assert board.ndim == 3 and board.shape[2] == 3
    assert board.dtype.name == "uint8"


def test_logs_single_stable_most_advanced_tag():
    class FakeLogger:
        def __init__(self):
            self.records = {}
        def record(self, key, value, **kwargs):
            self.records[key] = value

    with tempfile.TemporaryDirectory() as tmp:
        cb = TensorboardCallback(tmp)
        cb.training_env = object()
        cb.logger = FakeLogger()
        cb.num_timesteps = 900
        cb.best_party_record = {
            "worker_index": 5,
            "timestep": 850,
            "best_map_progress": 10,
            "best_map_id": 61,
            "badges": 3,
            "pokedex_owned": 12,
            "captures": 8,
            "party_snapshot": [{"species": "Vaporeon", "level": 28,
                                "hp": 74, "max_hp": 74, "status": "OK",
                                "moves": ["Water Gun", "Surf"],
                                "hm_can_learn": ["Surf"], "hm_knows": ["Surf"]}],
        }
        assert cb._log_party_images() == 1
        assert "game/party_visual/most_advanced" in cb.logger.records
        assert "progress/most_advanced_worker_index" in cb.logger.records
        assert "game/party_visual/env_00" not in cb.logger.records


def test_same_best_worker_party_refreshes_when_team_changes():
    with tempfile.TemporaryDirectory() as tmp:
        cb = TensorboardCallback(tmp)
        cb.best_party_path = Path(tmp) / "most_advanced_party.json"
        cb.history_dir = Path(tmp)
        cb.best_party_rank = None
        cb.best_party_record = None
        base = {
            "best_map_progress": 8, "map_progress": 8, "badges": 2,
            "pokedex_owned": 7, "captures": 5, "party_species_count": 4,
        }
        first = dict(base, party_snapshot=[{"species": "Pidgey", "level": 12, "moves": ["Gust"]}])
        second = dict(base, party_snapshot=[{"species": "Pidgeotto", "level": 18, "moves": ["Wing Attack"]}])
        assert cb._consider_party_candidate(2, first, 100)
        assert cb._consider_party_candidate(2, second, 200)
        assert cb.best_party_record["party_snapshot"][0]["species"] == "Pidgeotto"


if __name__ == "__main__":
    tests = [
        test_story_progress_beats_dex_and_party_tiebreakers,
        test_badges_break_ties_and_record_persists,
        test_terminal_snapshot_used_before_worker_auto_reset,
        test_board_renderer_returns_rgb_image,
        test_logs_single_stable_most_advanced_tag,
        test_same_best_worker_party_refreshes_when_team_changes,
    ]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
    print(f"{len(tests)} tests passed")
