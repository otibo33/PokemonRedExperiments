# Most-advanced party snapshot for parallel Pokémon Red training

This patch changes only `tensorboard_callback.py`, the callback imported by the user's parallel trainer. It does not change the Gym observation space, rewards, PPO policy, actions, or emulator behavior.

## What counts as the most advanced worker

Workers are ranked lexicographically by:

1. `best_map_progress` — highest essential story-map milestone reached (primary key).
2. `badges`.
3. `map_progress`.
4. `hm_critical_ready`.
5. `pokedex_owned`.
6. `captures`.
7. `party_species_count`.

When a worker reaches a new best rank, its actual party snapshot is saved before any VecEnv automatic reset can replace its state. A terminal `episode_snapshot` is used on episode end. The best snapshot is persisted at:

`<session-dir>/_trajectory_history/most_advanced_party.json`

This persists across resumes as long as the same session directory is reused.

## TensorBoard tags

Only one party image is written:

- `game/party_visual/most_advanced`

Associated scalar tags:

- `progress/most_advanced_worker_index`
- `progress/most_advanced_map_progress`
- `progress/most_advanced_badges`
- `progress/most_advanced_pokedex_owned`
- `progress/most_advanced_captures`

Capture-progress overview scalars are also logged:

- `game/captures_mean`
- `game/pokedex_owned_mean`
- `game/party_species_count_mean`
- `game/pokeballs_mean`

## Install (Fish / CachyOS)

Stop the training process. From the project's `v2` directory:

```fish
cp tensorboard_callback.py tensorboard_callback.py.before_most_advanced_party
unzip -o /path/to/pokemon_red_most_advanced_party_patch.zip -d /tmp/pokemon_red_most_advanced_party_patch
cp /tmp/pokemon_red_most_advanced_party_patch/pokemon_red_most_advanced_party/tensorboard_callback.py .
cp /tmp/pokemon_red_most_advanced_party_patch/pokemon_red_most_advanced_party/show_most_advanced_party.py .
cp /tmp/pokemon_red_most_advanced_party_patch/pokemon_red_most_advanced_party/test_most_advanced_party.py .
```

Verify imports/syntax in the same project venv:

```fish
python -m py_compile tensorboard_callback.py show_most_advanced_party.py test_most_advanced_party.py
python test_most_advanced_party.py
```

Restart parallel training with the same `--session-dir` / `runs` directory and your latest checkpoint.

## View the snapshot

TensorBoard → Images → `game/party_visual/most_advanced`.

To read the saved party directly in Konsole:

```fish
python show_most_advanced_party.py runs
```

Replace `runs` with the session directory printed by the trainer, if different.

## Important limitation

This cannot reconstruct the party from an earlier running process if no party snapshot was logged at that time. The persisted `most_advanced_party.json` starts being populated after this callback is installed. On restart, the emulator workers reload their configured initial save state; the PPO checkpoint restores the learned policy, not the live emulator party. The callback therefore preserves the best party reached **from the point this patch is installed onward**.

The unit tests use fake worker/info records and validate selection, persistence, image generation, and the TensorBoard tag. A live PyBoy run is still required to validate the complete integration on the user's machine.
