#!/usr/bin/env python3
"""Download the optional Generation-I Red/Blue party sprites used by TensorBoard.

Sprites are obtained from the PokeAPI/sprites repository and cached locally so
training does not need network access. Run once from the patch directory:

    python download_gen1_sprites.py
"""

from __future__ import annotations

import concurrent.futures
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

SPRITE_DIR = Path(__file__).resolve().parent / "assets" / "gen1_sprites"
BASE_URL = (
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/"
    "versions/generation-i/red-blue/transparent/{dex}.png"
)


def download_one(dex: int) -> tuple[int, bool, str]:
    target = SPRITE_DIR / f"{dex}.png"
    if target.is_file() and target.stat().st_size > 100:
        return dex, True, "cached"
    request = urllib.request.Request(
        BASE_URL.format(dex=dex),
        headers={"User-Agent": "PokemonRed-TensorBoard-Party-Viewer/1.0"},
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            data = response.read()
        if not data.startswith(b"\x89PNG\r\n\x1a\n"):
            return dex, False, "response was not a PNG"
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_suffix(".png.tmp")
        temp.write_bytes(data)
        temp.replace(target)
        return dex, True, "downloaded"
    except (OSError, urllib.error.URLError, TimeoutError) as exc:
        return dex, False, str(exc)


def main() -> int:
    SPRITE_DIR.mkdir(parents=True, exist_ok=True)
    started = time.time()
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(download_one, dex) for dex in range(1, 152)]
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            results.append(result)
            dex, ok, detail = result
            if not ok:
                print(f"#{dex:03d}: FAILED: {detail}")
    ok_count = sum(1 for _, ok, _ in results if ok)
    failed = sorted(dex for dex, ok, _ in results if not ok)
    print(f"Sprites ready: {ok_count}/151 in {time.time() - started:.1f}s")
    print(f"Cache: {SPRITE_DIR}")
    if failed:
        print("Missing National Dex IDs:", ", ".join(map(str, failed)))
        print("The TensorBoard party viewer will use fallback icons for missing sprites.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
