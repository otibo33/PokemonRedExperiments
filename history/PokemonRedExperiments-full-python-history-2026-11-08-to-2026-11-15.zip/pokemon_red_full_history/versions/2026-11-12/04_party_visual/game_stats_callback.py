"""TensorBoard callback for Pokémon Red scalars, tables and visual party snapshots."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from stable_baselines3.common.callbacks import BaseCallback


SPRITE_DIR = Path(__file__).resolve().parent / "assets" / "gen1_sprites"
HM_ORDER = ("CUT", "FLY", "SURF", "STRENGTH", "FLASH")


class GameStatsCallback(BaseCallback):
    """Log game metrics and party snapshots for each parallel environment.

    - Text dashboard: detailed party table, refreshed every ``party_every``.
    - Images dashboard: six-slot visual party board, refreshed every
      ``image_every``.
    - Images dashboard: game frame composed beside the party board, when the
      environment exposes ``get_tensorboard_frame``.

    Visual snapshots are intentionally less frequent than text/scalar metrics
    to keep TensorBoard event files from growing too quickly.
    """

    KEYS = (
        "map_progress", "seen_tiles", "visited_maps", "badges", "events",
        "levels_sum", "deaths", "story_milestone_score", "pokedex_owned",
        "lifetime_best_owned_count", "new_dex_entries", "captures", "party_size",
        "party_species_count", "pokeballs", "hm_party_compatible", "hm_items_owned",
        "hm_moves_taught", "hm_field_ready", "hm_critical_ready",
        "hm_critical_candidates_complete", "hm_critical_ready_complete",
        "hm_candidate_coverage_gap", "hm_ready_coverage_gap",
        "hm_cut_party_compatible", "hm_cut_item_owned", "hm_cut_taught", "hm_cut_badge", "hm_cut_usable",
        "hm_fly_party_compatible", "hm_fly_item_owned", "hm_fly_taught", "hm_fly_badge", "hm_fly_usable",
        "hm_surf_party_compatible", "hm_surf_item_owned", "hm_surf_taught", "hm_surf_badge", "hm_surf_usable",
        "hm_strength_party_compatible", "hm_strength_item_owned", "hm_strength_taught", "hm_strength_badge", "hm_strength_usable",
        "hm_flash_party_compatible", "hm_flash_item_owned", "hm_flash_taught", "hm_flash_badge", "hm_flash_usable",
    )

    def __init__(
        self,
        every: int = 2560,
        party_every: int = 10240,
        image_every: int = 40960,
        verbose: int = 0,
    ):
        for name, value in (("every", every), ("party_every", party_every), ("image_every", image_every)):
            if value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        super().__init__(verbose=verbose)
        self.every = int(every)
        self.party_every = int(party_every)
        self.image_every = int(image_every)
        self._last_log_timestep = 0
        self._last_party_log_timestep = 0
        self._last_image_log_timestep = 0

    def _tensorboard_writers(self):
        """Get writers from SB3's configured TensorBoard output format."""
        writers = []
        for output_format in getattr(self.logger, "output_formats", ()):
            writer = getattr(output_format, "writer", None)
            if writer is not None and hasattr(writer, "add_text"):
                writers.append(writer)
        return writers

    @staticmethod
    def _party_markdown(party):
        if not party:
            return "**Party:** empty (no Pokémon currently in party)"
        lines = [
            "| Slot | Pokémon | Lv. | HP | Status | Moves | HM compatibility | HMs known |",
            "|---:|---|---:|---:|---|---|---|---|",
        ]
        for mon in party:
            hp = f"{mon.get('hp', '?')}/{mon.get('max_hp', '?')}"
            moves = ", ".join(mon.get("moves", [])) or "—"
            compatible = ", ".join(mon.get("hm_can_learn", [])) or "—"
            taught = ", ".join(mon.get("hm_knows", [])) or "—"
            lines.append(
                f"| {mon.get('slot', '?')} | {mon.get('species', 'Unknown')} "
                f"(0x{int(mon.get('species_index', 0)):02X}) | {mon.get('level', '?')} "
                f"| {hp} | {mon.get('status', 'Unknown')} | {moves} | {compatible} | {taught} |"
            )
        return "\n".join(lines)

    @staticmethod
    def _font(size: int, bold: bool = False):
        candidates = []
        if bold:
            candidates.extend((
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
            ))
        else:
            candidates.extend((
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                "/usr/share/fonts/TTF/DejaVuSans.ttf",
            ))
        for candidate in candidates:
            if Path(candidate).is_file():
                try:
                    return ImageFont.truetype(candidate, size=size)
                except OSError:
                    pass
        return ImageFont.load_default()

    @staticmethod
    def _hp_fraction(mon: dict[str, Any]) -> float:
        try:
            hp = max(0.0, float(mon.get("hp", 0)))
            max_hp = max(1.0, float(mon.get("max_hp", 1)))
            return max(0.0, min(1.0, hp / max_hp))
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _short_hm(values):
        values = [str(value).upper() for value in (values or [])]
        return " / ".join(name for name in HM_ORDER if name in values) or "—"

    @staticmethod
    def _load_sprite(national_dex: int | None, size=(116, 116)):
        """Load an optional local Red/Blue sprite; callers get None on miss."""
        if not national_dex or not (1 <= int(national_dex) <= 151):
            return None
        path = SPRITE_DIR / f"{int(national_dex)}.png"
        if not path.is_file():
            return None
        try:
            with Image.open(path) as source:
                sprite = source.convert("RGBA")
                sprite.thumbnail(size, Image.Resampling.NEAREST)
                return sprite.copy()
        except (OSError, ValueError):
            return None

    @classmethod
    def render_party_board(cls, party, env_index: int = 0, step: int = 0):
        """Render a 3x2, six-slot party dashboard as uint8 RGB HWC."""
        width, height = 1240, 760
        image = Image.new("RGB", (width, height), (17, 24, 39))
        draw = ImageDraw.Draw(image)
        title_font = cls._font(30, bold=True)
        header_font = cls._font(19, bold=True)
        body_font = cls._font(17)
        small_font = cls._font(14)

        draw.text((28, 20), f"POKEMON PARTY  |  ENV {env_index:02d}", font=title_font, fill=(243, 244, 246))
        draw.text((30, 61), f"Training timestep: {step:,}    |    {len(party)} / 6 party members", font=small_font, fill=(156, 163, 175))

        card_w, card_h, gap_x, gap_y = 386, 306, 18, 18
        start_x, start_y = 28, 102
        for slot in range(6):
            row, col = divmod(slot, 3)
            x = start_x + col * (card_w + gap_x)
            y = start_y + row * (card_h + gap_y)
            card = (x, y, x + card_w, y + card_h)
            draw.rounded_rectangle(card, radius=18, fill=(31, 41, 55), outline=(75, 85, 99), width=2)
            draw.text((x + 18, y + 15), f"SLOT {slot + 1}", font=small_font, fill=(156, 163, 175))

            if slot >= len(party):
                # Empty slots remain visible, making party capacity obvious.
                draw.rounded_rectangle((x + 22, y + 58, x + 122, y + 158), radius=16, fill=(24, 32, 45), outline=(75, 85, 99), width=2)
                draw.ellipse((x + 52, y + 88, x + 114, y + 150), outline=(107, 114, 128), width=5)
                draw.line((x + 57, y + 119, x + 109, y + 119), fill=(107, 114, 128), width=5)
                draw.text((x + 143, y + 81), "EMPTY SLOT", font=header_font, fill=(156, 163, 175))
                draw.text((x + 143, y + 113), "Available for a new teammate", font=small_font, fill=(107, 114, 128))
                continue

            mon = party[slot]
            sprite_box = (x + 18, y + 45, x + 132, y + 159)
            draw.rounded_rectangle(sprite_box, radius=14, fill=(24, 32, 45), outline=(55, 65, 81), width=1)
            sprite = cls._load_sprite(mon.get("national_dex"))
            if sprite is not None:
                px = sprite_box[0] + (114 - sprite.width) // 2
                py = sprite_box[1] + (114 - sprite.height) // 2
                image.paste(sprite, (px, py), sprite)
            else:
                # Offline fallback. The downloader script populates real
                # Red/Blue sprites without making training depend on network.
                dex = mon.get("national_dex")
                label = f"#{int(dex):03d}" if dex else "?"
                draw.ellipse((x + 47, y + 70, x + 103, y + 126), fill=(220, 228, 236), outline=(148, 163, 184), width=3)
                draw.ellipse((x + 62, y + 85, x + 88, y + 111), fill=(31, 41, 55), outline=(148, 163, 184), width=2)
                box = draw.textbbox((0, 0), label, font=small_font)
                draw.text((int(x + 75 - (box[2] - box[0]) / 2), y + 132), label, font=small_font, fill=(203, 213, 225))

            name = str(mon.get("species", "Unknown"))
            name = name.replace("Nidoran♂", "Nidoran-M").replace("Nidoran♀", "Nidoran-F")
            level = mon.get("level", "?")
            draw.text((x + 146, y + 49), name[:22], font=header_font, fill=(243, 244, 246))
            draw.text((x + 146, y + 80), f"Lv. {level}", font=body_font, fill=(203, 213, 225))
            status = str(mon.get("status", "Unknown"))
            status_color = (74, 222, 128) if status == "OK" else (251, 191, 36)
            draw.text((x + 146, y + 110), status[:20], font=small_font, fill=status_color)

            hp_fraction = cls._hp_fraction(mon)
            hp = mon.get("hp", "?")
            max_hp = mon.get("max_hp", "?")
            draw.text((x + 18, y + 171), f"HP  {hp}/{max_hp}", font=small_font, fill=(226, 232, 240))
            bar = (x + 18, y + 194, x + card_w - 18, y + 209)
            draw.rounded_rectangle(bar, radius=7, fill=(55, 65, 81))
            if hp_fraction > 0:
                fill_color = (34, 197, 94) if hp_fraction > 0.5 else ((234, 179, 8) if hp_fraction > 0.2 else (239, 68, 68))
                draw.rounded_rectangle((bar[0], bar[1], bar[0] + int((bar[2] - bar[0]) * hp_fraction), bar[3]), radius=7, fill=fill_color)

            moves = list(mon.get("moves", []))[:4]
            draw.text((x + 18, y + 220), "MOVES", font=small_font, fill=(156, 163, 175))
            move_text = "  /  ".join(str(m) for m in moves) if moves else "No moves"
            draw.text((x + 18, y + 241), move_text[:47], font=small_font, fill=(226, 232, 240))

            can_learn = cls._short_hm(mon.get("hm_can_learn", []))
            knows = cls._short_hm(mon.get("hm_knows", []))
            draw.text((x + 18, y + 266), f"CAN LEARN: {can_learn}"[:47], font=small_font, fill=(147, 197, 253))
            draw.text((x + 18, y + 286), f"KNOWS: {knows}"[:47], font=small_font, fill=(134, 239, 172))

        return np.asarray(image, dtype=np.uint8).copy()

    @staticmethod
    def compose_gameplay_party(game_frame, party_board):
        """Join a live game frame and party board into one TensorBoard image."""
        game = Image.fromarray(np.asarray(game_frame, dtype=np.uint8)).convert("RGB")
        board = Image.fromarray(np.asarray(party_board, dtype=np.uint8)).convert("RGB")
        target_h = 760
        # Preserve the native game-frame aspect while enlarging to the board height.
        game_w = max(1, int(game.width * target_h / max(game.height, 1)))
        game = game.resize((game_w, target_h), Image.Resampling.NEAREST)
        canvas = Image.new("RGB", (game_w + board.width, target_h), (12, 18, 28))
        canvas.paste(game, (0, 0))
        canvas.paste(board, (game_w, 0))
        return np.asarray(canvas, dtype=np.uint8).copy()

    def _log_party(self, infos):
        writers = self._tensorboard_writers()
        if not writers:
            return
        for env_index, info in enumerate(infos):
            if not isinstance(info, dict):
                continue
            party = info.get("party_snapshot")
            if not isinstance(party, (list, tuple)):
                continue
            markdown = self._party_markdown(party)
            for writer in writers:
                writer.add_text(
                    f"game/party/env_{env_index:02d}",
                    markdown,
                    global_step=self.num_timesteps,
                )
                for mon in party:
                    slot_prefix = f"game/party/env_{env_index:02d}/slot_{int(mon.get('slot', 0)):02d}"
                    writer.add_scalar(f"{slot_prefix}/level", float(mon.get("level", 0)), self.num_timesteps)
                    max_hp = max(float(mon.get("max_hp", 0)), 1.0)
                    writer.add_scalar(f"{slot_prefix}/hp_fraction", float(mon.get("hp", 0)) / max_hp, self.num_timesteps)
                    writer.add_scalar(f"{slot_prefix}/species_index", float(mon.get("species_index", 0)), self.num_timesteps)
        for writer in writers:
            writer.flush()

    def _get_game_frames(self):
        """Ask each VecEnv worker for a frame only at image-log intervals."""
        try:
            if self.training_env is None or not hasattr(self.training_env, "env_method"):
                return None
            frames = self.training_env.env_method("get_tensorboard_frame", scale=3)
            return list(frames) if frames is not None else None
        except Exception as exc:  # images must never interrupt PPO training
            if self.verbose:
                print(f"[GameStatsCallback] Could not collect game frames: {exc}")
            return None

    def _log_party_images(self, infos):
        writers = [writer for writer in self._tensorboard_writers() if hasattr(writer, "add_image")]
        if not writers:
            return

        frames = self._get_game_frames()
        for env_index, info in enumerate(infos):
            if not isinstance(info, dict):
                continue
            party = info.get("party_snapshot")
            if not isinstance(party, (list, tuple)):
                continue
            board = self.render_party_board(party, env_index=env_index, step=self.num_timesteps)
            for writer in writers:
                writer.add_image(
                    f"game/party_visual/env_{env_index:02d}",
                    board,
                    global_step=self.num_timesteps,
                    dataformats="HWC",
                )
                if frames is not None and env_index < len(frames) and frames[env_index] is not None:
                    combined = self.compose_gameplay_party(frames[env_index], board)
                    writer.add_image(
                        f"gameplay/with_party/env_{env_index:02d}",
                        combined,
                        global_step=self.num_timesteps,
                        dataformats="HWC",
                    )
        for writer in writers:
            writer.flush()

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", ())
        if self.num_timesteps - self._last_log_timestep >= self.every:
            self._last_log_timestep = self.num_timesteps
            for key in self.KEYS:
                values = []
                for info in infos:
                    if not isinstance(info, dict) or key not in info:
                        continue
                    value = info[key]
                    if isinstance(value, (int, float, np.number)):
                        values.append(float(value))
                if values:
                    self.logger.record(f"game/{key}", float(np.mean(values)))

        if self.num_timesteps - self._last_party_log_timestep >= self.party_every:
            self._last_party_log_timestep = self.num_timesteps
            self._log_party(infos)

        if self.num_timesteps - self._last_image_log_timestep >= self.image_every:
            self._last_image_log_timestep = self.num_timesteps
            self._log_party_images(infos)

        return True
