"""Offline tests for party-board and gameplay-plus-party TensorBoard images."""
import importlib.util
import sys
import types
from pathlib import Path

sb3 = types.ModuleType("stable_baselines3")
common = types.ModuleType("stable_baselines3.common")
callbacks = types.ModuleType("stable_baselines3.common.callbacks")
class BaseCallback:
    def __init__(self, verbose=0):
        self.verbose = verbose
        self.logger = None
        self.locals = {}
        self.num_timesteps = 0
        self.training_env = None
callbacks.BaseCallback = BaseCallback
sys.modules["stable_baselines3"] = sb3
sys.modules["stable_baselines3.common"] = common
sys.modules["stable_baselines3.common.callbacks"] = callbacks

path = Path(__file__).with_name("game_stats_callback.py")
spec = importlib.util.spec_from_file_location("party_visual_callback_test", path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)

class Writer:
    def __init__(self):
        self.images = []
        self.flushed = False
    def add_text(self, *args, **kwargs):
        pass
    def add_image(self, tag, image, global_step, dataformats):
        self.images.append((tag, image, global_step, dataformats))
    def flush(self):
        self.flushed = True

class OutputFormat:
    def __init__(self, writer):
        self.writer = writer

class FakeVecEnv:
    def env_method(self, method, **kwargs):
        assert method == "get_tensorboard_frame"
        assert kwargs == {"scale": 3}
        return [__import__("numpy").zeros((144 * 3, 160 * 3, 3), dtype="uint8")]

party = [{
    "slot": 1, "species_index": 0xB1, "national_dex": 7,
    "species": "Squirtle", "level": 12, "hp": 25, "max_hp": 30,
    "status": "OK", "moves": ["Surf", "Tackle"],
    "hm_can_learn": ["SURF", "STRENGTH"], "hm_knows": ["SURF"],
}]

# Render dimensions and a valid six-slot layout must be produced even when
# the sprite cache is empty (fallback Poké Ball/dex-number badge is used).
board = module.GameStatsCallback.render_party_board(party, env_index=0, step=40960)
assert board.shape == (760, 1240, 3)
assert board.dtype == __import__("numpy").uint8
combined = module.GameStatsCallback.compose_gameplay_party(
    __import__("numpy").zeros((432, 480, 3), dtype="uint8"), board
)
assert combined.shape[0] == 760 and combined.shape[1] > board.shape[1]

writer = Writer()
callback = module.GameStatsCallback(image_every=10)
callback.logger = types.SimpleNamespace(output_formats=[OutputFormat(writer)])
callback.training_env = FakeVecEnv()
callback.num_timesteps = 10
callback._log_party_images([{"party_snapshot": party}])
assert [item[0] for item in writer.images] == [
    "game/party_visual/env_00", "gameplay/with_party/env_00"
]
assert all(item[1].dtype == __import__("numpy").uint8 for item in writer.images)
assert all(item[3] == "HWC" for item in writer.images)
assert writer.flushed
print("All TensorBoard party image tests passed.")
