# Pokémon Red — party images in the actual parallel-training callback

## Why this patch is needed

The parallel trainer shown in the user's project imports and instantiates:

```python
from tensorboard_callback import TensorboardCallback
...
TensorboardCallback(sess_path)
```

It does **not** instantiate `GameStatsCallback`. The previous party-visualizer
work was added to `game_stats_callback.py`, which means its party-image methods
were never called by this trainer. This patch puts the party-image pipeline in
`tensorboard_callback.py`, the callback actually used by `baseline_run_paralell.py`.

## What it logs

Through Stable-Baselines3's existing `self.logger.record(..., Image(...))`
path (the same mechanism already used by `trajectory/explore_map`), it writes:

- `game/party_visual/env_00` through `game/party_visual/env_15`: 6-slot party
  dashboards for each parallel worker.
- `gameplay/with_party/env_00`: worker 0's current game frame beside its party
  dashboard.

An initial snapshot is queued at training start. Further snapshots are queued
every 40,960 aggregate environment timesteps by default (one rollout for the
usual 16-worker, 2,560-step configuration). No observation spaces, rewards,
actions, PPO settings, checkpoint files, or environment RAM reads are changed.

The party board uses a species-number fallback icon if optional sprite files
are not installed. If `assets/gen1_sprites/<national_dex>.png` exists next to
the callback, that sprite is used.

## Install (Fish / CachyOS)

Stop the current training process first. From the project's `v2` directory:

```fish
cp tensorboard_callback.py tensorboard_callback.py.before_party_images
unzip -o /path/to/pokemon_red_tensorboard_callback_fix.zip -d /tmp/pokemon_red_tensorboard_callback_fix
cp /tmp/pokemon_red_tensorboard_callback_fix/pokemon_red_party_tensorboard_integrated/tensorboard_callback.py .
```

No changes to `baseline_run_paralell.py`, `game_stats_callback.py`, or
`red_gym_env_v2.py` are required for the version previously checked by the user:
that environment already exposes `read_party_snapshot()` and
`get_tensorboard_frame()`.

Run the dependency-light callback recording test and syntax check:

```fish
python -m py_compile tensorboard_callback.py
python /tmp/pokemon_red_tensorboard_callback_fix/pokemon_red_party_tensorboard_integrated/test_party_image_logging.py
```

Then restart parallel training from the existing checkpoint, using the same
session/log directory configuration as before. A running Python process cannot
load the replacement callback without restarting.

## Where to look in TensorBoard

Open the newly created `poke_ppo_*` run under the same `runs` directory. In the
**Images** tab look for:

- `game/party_visual/env_00`
- `gameplay/with_party/env_00`

There should also be `game/party_visual/env_01` etc. for the other workers.

The initial image is queued at callback startup and is written when PPO next
dumps its logger values (normally at the end of the first rollout). Do not
expect images to appear in older event files created before this callback was
installed.

## Verification and limits

`test_party_image_logging.py` uses a fake VecEnv and a fake SB3 logger to verify
that the callback emits the expected SB3 image objects and tags. It does not
launch the user's ROM or prove a live multi-process PyBoy integration. The
actual runtime verification is that the new event file contains the two image
tag families above.
