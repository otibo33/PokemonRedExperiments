"""Robust Pokémon Red TensorBoard callback.

Preserves the user's original TensorboardCallback name and histogram/stat
logs. Fixes terminal-episode capture for SB3 VecEnv auto-resets and maintains
cumulative exploration maps/progression across episode resets and process
restarts (provided the same log_dir is reused).

Logs party-board and gameplay-plus-party images through the same SB3
TensorBoard stream as exploration maps. No rewards, policy observations, or
training actions are changed by this callback.
"""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any

import numpy as np
from einops import rearrange, reduce
from PIL import Image as PILImage, ImageDraw, ImageFont
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.logger import Image
from torch.utils.tensorboard import SummaryWriter


def merge_dicts(dicts):
    """Return numeric means and distributions, ignoring non-numeric fields."""
    values_by_key: dict[str, list[float]] = {}
    for item in dicts:
        if not isinstance(item, dict):
            continue
        for key, value in item.items():
            if isinstance(value, (int, float, np.number)) and not isinstance(value, (bool, np.bool_)):
                values_by_key.setdefault(key, []).append(float(value))

    means = {key: float(np.mean(values)) for key, values in values_by_key.items()}
    distributions = {
        key: np.asarray(values, dtype=np.float32)
        for key, values in values_by_key.items()
    }
    return means, distributions


def _as_uint8_map(value: Any, expected_shape: tuple[int, int] | None = None):
    if value is None:
        return None
    array = np.asarray(value)
    if array.ndim != 2:
        return None
    if expected_shape is not None and tuple(array.shape) != tuple(expected_shape):
        return None
    return np.ascontiguousarray(np.clip(array, 0, 255), dtype=np.uint8)


def _make_map_mosaic(maps: np.ndarray) -> np.ndarray:
    """Arrange N HxW maps in a roughly square grid; supports any N >= 1."""
    maps = np.asarray(maps, dtype=np.uint8)
    if maps.ndim != 3 or maps.shape[0] < 1:
        raise ValueError(f"Expected NxHxW maps, got {maps.shape}")
    count, height, width = maps.shape
    columns = int(math.ceil(math.sqrt(count)))
    rows = int(math.ceil(count / columns))
    canvas = np.zeros((rows * height, columns * width), dtype=np.uint8)
    for index, item in enumerate(maps):
        row, column = divmod(index, columns)
        canvas[
            row * height:(row + 1) * height,
            column * width:(column + 1) * width,
        ] = item
    return canvas


def _nearest_neighbor_scale(image: np.ndarray, scale: int) -> np.ndarray:
    if scale <= 1:
        return np.ascontiguousarray(image, dtype=np.uint8)
    return np.ascontiguousarray(
        np.repeat(np.repeat(image, scale, axis=0), scale, axis=1),
        dtype=np.uint8,
    )


class TensorboardCallback(BaseCallback):
    """Keep the original callback API while preserving complete map history.

    Existing use remains valid:
        TensorboardCallback(log_dir)
        TensorboardCallback(log_dir, verbose=1)

    Args:
        log_dir: Existing run/session directory. A `_trajectory_history`
            subdirectory is created here to persist map history between runs.
        verbose: Stable-Baselines3 callback verbosity.
        map_image_scale: Nearest-neighbour visual enlargement (default 2).
        scalar_log_every: Aggregate environment timesteps between progress
            scalar updates (default 2560).
        party_image_every: Aggregate timesteps between party dashboard images
            (default 40960); an initial image is also queued at startup.
    """

    def __init__(
        self,
        log_dir,
        verbose=0,
        map_image_scale=2,
        scalar_log_every=2560,
        map_log_every=10000,
        party_image_every=40960,
        party_frame_scale=3,
    ):
        super().__init__(verbose=verbose)
        self.log_dir = Path(log_dir).expanduser()
        self.writer = None
        self.map_image_scale = int(map_image_scale)
        self.scalar_log_every = int(scalar_log_every)
        self.map_log_every = int(map_log_every)
        self.party_image_every = int(party_image_every)
        self.party_frame_scale = int(party_frame_scale)
        if self.map_image_scale < 1:
            raise ValueError("map_image_scale must be a positive integer")
        if self.scalar_log_every < 1:
            raise ValueError("scalar_log_every must be a positive integer")
        if self.map_log_every < 1:
            raise ValueError("map_log_every must be a positive integer")
        if self.party_image_every < 1:
            raise ValueError("party_image_every must be a positive integer")
        if self.party_frame_scale < 1:
            raise ValueError("party_frame_scale must be a positive integer")

        self.history_dir = self.log_dir / "_trajectory_history"
        self.maps_path = self.history_dir / "worker_exploration_maps.npz"
        self.metadata_path = self.history_dir / "progress_metadata.json"
        self.worker_maps: np.ndarray | None = None
        self.map_shape: tuple[int, int] | None = None
        self.best_map_progress = -1
        self.best_map_id = -1
        self.episodes_completed = 0
        self.event_flags: dict[str, str] = {}
        self._last_scalar_log_timestep = 0
        self._last_map_log_timestep = 0
        self._last_party_image_timestep = 0
        self._warned_missing_snapshot = False
        self._warned_party_read = False

    def _on_training_start(self) -> None:
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.history_dir.mkdir(parents=True, exist_ok=True)
        self.writer = SummaryWriter(log_dir=str(self.log_dir / "histogram"))

        # Discover the fixed global map dimensions from the environments.
        try:
            existing_maps = self.training_env.get_attr("lifetime_explore_map")
            if existing_maps:
                first = np.asarray(existing_maps[0])
                if first.ndim == 2:
                    self.map_shape = tuple(int(v) for v in first.shape)
        except Exception:
            # We still support legacy environments for statistics. The
            # terminal-map tags require the patched red_gym_env_v2.py.
            self.map_shape = None

        self._load_persisted_history()
        # The trainer imports TensorboardCallback (this class), so party images
        # must be emitted here rather than in the unused GameStatsCallback.
        self._last_party_image_timestep = int(self.num_timesteps)
        initial_count = self._log_party_images()
        if initial_count:
            print(
                f"[TensorboardCallback] Initial party dashboard queued for "
                f"{initial_count}/{int(self.training_env.num_envs)} worker(s). "
                "It will be written with the next PPO TensorBoard dump."
            )

    def _load_persisted_history(self) -> None:
        n_envs = int(self.training_env.num_envs)
        self.worker_maps = None

        if self.maps_path.exists():
            try:
                with np.load(self.maps_path, allow_pickle=False) as saved:
                    old_maps = np.asarray(saved["worker_maps"], dtype=np.uint8)
                if old_maps.ndim == 3 and old_maps.shape[0] > 0:
                    if self.map_shape is None:
                        self.map_shape = tuple(int(v) for v in old_maps.shape[1:])
                    if tuple(old_maps.shape[1:]) == tuple(self.map_shape):
                        if old_maps.shape[0] == n_envs:
                            self.worker_maps = old_maps.copy()
                        else:
                            # If worker count changes, keep the complete prior
                            # union by seeding each new worker with that union.
                            merged = np.max(old_maps, axis=0)
                            self.worker_maps = np.repeat(merged[None, :, :], n_envs, axis=0)
            except Exception as exc:
                self._warn(f"Could not load saved exploration maps ({exc}); starting map history empty.")

        if self.worker_maps is None and self.map_shape is not None:
            self.worker_maps = np.zeros((n_envs, *self.map_shape), dtype=np.uint8)

        if self.metadata_path.exists():
            try:
                metadata = json.loads(self.metadata_path.read_text(encoding="utf-8"))
                self.best_map_progress = int(metadata.get("best_map_progress", -1))
                self.best_map_id = int(metadata.get("best_map_id", -1))
                self.episodes_completed = int(metadata.get("episodes_completed", 0))
                flags = metadata.get("event_flags", {})
                if isinstance(flags, dict):
                    self.event_flags = {str(k): str(v) for k, v in flags.items()}
            except Exception as exc:
                self._warn(f"Could not load progress metadata ({exc}); starting metadata fresh.")

    def _save_persisted_history(self) -> None:
        if self.worker_maps is not None:
            temp_path = self.maps_path.with_suffix(".npz.tmp")
            with temp_path.open("wb") as handle:
                np.savez_compressed(handle, worker_maps=self.worker_maps)
            os.replace(temp_path, self.maps_path)

        metadata = {
            "best_map_progress": int(self.best_map_progress),
            "best_map_id": int(self.best_map_id),
            "episodes_completed": int(self.episodes_completed),
            "event_flags": self.event_flags,
        }
        temp_meta = self.metadata_path.with_suffix(".json.tmp")
        temp_meta.write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")
        os.replace(temp_meta, self.metadata_path)

    def _warn(self, message: str) -> None:
        # Use plain stdout so this remains compatible with SB3 logger versions
        # that do not expose a Logger.warn() method.
        print(f"[TensorboardCallback] WARNING: {message}")

    def _get_infos_and_dones(self):
        infos = self.locals.get("infos", ())
        dones = self.locals.get("dones", ())
        if infos is None:
            infos = ()
        if dones is None:
            dones = ()
        try:
            dones = np.asarray(dones, dtype=bool).reshape(-1)
        except Exception:
            dones = np.zeros(len(infos), dtype=bool)
        return list(infos), dones

    def _update_maps_from_envs(self, infos, dones):
        n_envs = int(self.training_env.num_envs)
        if self.worker_maps is None:
            try:
                raw = self.training_env.get_attr("lifetime_explore_map")
                first = _as_uint8_map(raw[0])
                if first is None:
                    return []
                self.map_shape = tuple(first.shape)
                self.worker_maps = np.zeros((n_envs, *self.map_shape), dtype=np.uint8)
            except Exception as exc:
                self._warn(f"Environment does not expose lifetime_explore_map: {exc}")
                return []

        episode_maps = []
        snapshots_seen = 0
        for index in range(min(n_envs, len(infos), len(dones))):
            info = infos[index] if isinstance(infos[index], dict) else {}
            worker_best = info.get("best_map_progress")
            if isinstance(worker_best, (int, float, np.number)) and int(worker_best) > self.best_map_progress:
                self.best_map_progress = int(worker_best)
                self.best_map_id = int(info.get("best_map_id", info.get("map_id", -1)))
            if not dones[index]:
                continue
            snapshot = info.get("episode_snapshot")
            if not isinstance(snapshot, dict):
                continue
            snapshots_seen += 1

            episode_map = _as_uint8_map(snapshot.get("explore_map"), self.map_shape)
            lifetime_map = _as_uint8_map(snapshot.get("lifetime_explore_map"), self.map_shape)
            if episode_map is not None:
                episode_maps.append(episode_map)
            if lifetime_map is not None:
                self.worker_maps[index] = np.maximum(self.worker_maps[index], lifetime_map)
            elif episode_map is not None:
                self.worker_maps[index] = np.maximum(self.worker_maps[index], episode_map)

            stats = snapshot.get("agent_stats")
            if isinstance(stats, dict) and stats:
                self._completed_episode_stats.append(stats)

            progress = int(snapshot.get("best_map_progress", snapshot.get("map_progress", -1)))
            if progress > self.best_map_progress:
                self.best_map_progress = progress
                self.best_map_id = int(snapshot.get("best_map_id", snapshot.get("map_id", -1)))

            self.episodes_completed += 1
            flags = snapshot.get("lifetime_event_flags", snapshot.get("event_flags", {}))
            if isinstance(flags, dict):
                self.event_flags.update({str(k): str(v) for k, v in flags.items()})

        # Pull current cumulative maps from all workers. A completed worker has
        # already auto-reset, but its lifetime map intentionally survives reset.
        try:
            current_maps = self.training_env.get_attr("lifetime_explore_map")
            for index, raw_map in enumerate(current_maps[:n_envs]):
                current_map = _as_uint8_map(raw_map, self.map_shape)
                if current_map is not None:
                    self.worker_maps[index] = np.maximum(self.worker_maps[index], current_map)
        except Exception as exc:
            self._warn(f"Could not read lifetime maps from workers ({exc}).")

        # Fallback for a partially upgraded environment: at least collect named
        # event flags that are available after the VecEnv step.
        try:
            worker_flags = self.training_env.get_attr("lifetime_event_flags")
            for flags in worker_flags:
                if isinstance(flags, dict):
                    self.event_flags.update({str(k): str(v) for k, v in flags.items()})
        except Exception:
            pass

        if dones.size and np.any(dones) and snapshots_seen == 0 and not self._warned_missing_snapshot:
            self._warn(
                "An episode ended without info['episode_snapshot']. Replace red_gym_env_v2.py "
                "with the paired update; otherwise SB3's auto-reset can erase terminal maps before logging."
            )
            self._warned_missing_snapshot = True

        return episode_maps

    def _log_completed_episode_stats(self) -> None:
        if not self._completed_episode_stats:
            return
        means, distributions = merge_dicts(self._completed_episode_stats)
        for key, value in means.items():
            self.logger.record(f"env_stats/{key}", value)
        if self.writer is not None:
            for key, values in distributions.items():
                self.writer.add_histogram(
                    f"env_stats_distribs/{key}", values, self.num_timesteps
                )
                self.logger.record(f"env_stats_max/{key}", float(np.max(values)))
        self._completed_episode_stats.clear()

    def _log_map_images(self, episode_maps):
        if self.worker_maps is None or self.worker_maps.size == 0:
            return

        cumulative_sum = np.max(self.worker_maps, axis=0)
        cumulative_mosaic = _make_map_mosaic(self.worker_maps)
        cumulative_sum = _nearest_neighbor_scale(cumulative_sum, self.map_image_scale)
        cumulative_mosaic = _nearest_neighbor_scale(cumulative_mosaic, self.map_image_scale)

        # Preserve the original TensorBoard image tags, now showing lifetime
        # exploration rather than appearing to lose progress after each reset.
        self.logger.record(
            "trajectory/explore_sum",
            Image(cumulative_sum, "HW"),
            exclude=("stdout", "log", "json", "csv"),
        )
        self.logger.record(
            "trajectory/explore_map",
            Image(cumulative_mosaic, "HW"),
            exclude=("stdout", "log", "json", "csv"),
        )

        # Also keep a separate view of just the episode(s) that ended on this
        # VecEnv step. This makes a high-water episode easy to distinguish from
        # the all-time cumulative map.
        if episode_maps:
            episode_array = np.stack(episode_maps, axis=0).astype(np.uint8, copy=False)
            episode_sum = np.max(episode_array, axis=0)
            episode_mosaic = _make_map_mosaic(episode_array)
            episode_sum = _nearest_neighbor_scale(episode_sum, self.map_image_scale)
            episode_mosaic = _nearest_neighbor_scale(episode_mosaic, self.map_image_scale)
            self.logger.record(
                "trajectory/episode_explore_sum",
                Image(episode_sum, "HW"),
                exclude=("stdout", "log", "json", "csv"),
            )
            self.logger.record(
                "trajectory/episode_explore_map",
                Image(episode_mosaic, "HW"),
                exclude=("stdout", "log", "json", "csv"),
            )

    def _log_progress_scalars(self, infos):
        if self.num_timesteps - self._last_scalar_log_timestep < self.scalar_log_every:
            return
        self._last_scalar_log_timestep = int(self.num_timesteps)
        progress_values = []
        best_values = []
        seen_values = []
        for info in infos:
            if not isinstance(info, dict):
                continue
            for target, key in (
                (progress_values, "map_progress"),
                (best_values, "best_map_progress"),
                (seen_values, "seen_tiles"),
            ):
                value = info.get(key)
                if isinstance(value, (int, float, np.number)):
                    target.append(float(value))
            worker_best = info.get("best_map_progress")
            if isinstance(worker_best, (int, float, np.number)) and int(worker_best) > self.best_map_progress:
                self.best_map_progress = int(worker_best)
                self.best_map_id = int(info.get("best_map_id", info.get("map_id", -1)))
        if progress_values:
            self.logger.record("progress/current_map_progress_mean", float(np.mean(progress_values)))
        if best_values:
            self.logger.record("progress/worker_best_map_progress_mean", float(np.mean(best_values)))
        if seen_values:
            self.logger.record("progress/current_episode_seen_tiles_mean", float(np.mean(seen_values)))
        if self.best_map_progress >= 0:
            self.logger.record("progress/best_ever_map_progress", float(self.best_map_progress))
        self.logger.record("progress/episodes_completed_total", float(self.episodes_completed))

    @staticmethod
    def _party_font(size: int, bold: bool = False):
        candidates = (
            ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
             "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf")
            if bold else
            ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
             "/usr/share/fonts/TTF/DejaVuSans.ttf")
        )
        for candidate in candidates:
            if Path(candidate).is_file():
                try:
                    return ImageFont.truetype(candidate, size=size)
                except OSError:
                    pass
        return ImageFont.load_default()

    @staticmethod
    def _party_hm_text(values):
        order = ("CUT", "FLY", "SURF", "STRENGTH", "FLASH")
        names = {str(value).upper() for value in (values or [])}
        return " / ".join(name for name in order if name in names) or "—"

    @staticmethod
    def _party_hp_fraction(mon):
        try:
            hp = max(0.0, float(mon.get("hp", 0)))
            max_hp = max(1.0, float(mon.get("max_hp", 1)))
            return max(0.0, min(1.0, hp / max_hp))
        except (TypeError, ValueError):
            return 0.0

    @classmethod
    def _render_party_board(cls, party, env_index: int, step: int):
        """Build a visible 6-slot party image; no external sprite files required."""
        width, height = 1240, 760
        image = PILImage.new("RGB", (width, height), (17, 24, 39))
        draw = ImageDraw.Draw(image)
        title_font = cls._party_font(30, bold=True)
        header_font = cls._party_font(19, bold=True)
        body_font = cls._party_font(17)
        small_font = cls._party_font(14)

        draw.text((28, 20), f"POKEMON PARTY  |  ENV {env_index:02d}",
                  font=title_font, fill=(243, 244, 246))
        draw.text((30, 61),
                  f"Training timestep: {step:,}    |    {len(party)} / 6 party members",
                  font=small_font, fill=(156, 163, 175))

        card_w, card_h, gap_x, gap_y = 386, 306, 18, 18
        start_x, start_y = 28, 102
        for slot in range(6):
            row, col = divmod(slot, 3)
            x = start_x + col * (card_w + gap_x)
            y = start_y + row * (card_h + gap_y)
            draw.rounded_rectangle(
                (x, y, x + card_w, y + card_h), radius=18,
                fill=(31, 41, 55), outline=(75, 85, 99), width=2,
            )
            draw.text((x + 18, y + 15), f"SLOT {slot + 1}",
                      font=small_font, fill=(156, 163, 175))
            if slot >= len(party):
                draw.rounded_rectangle(
                    (x + 22, y + 58, x + 122, y + 158), radius=16,
                    fill=(24, 32, 45), outline=(75, 85, 99), width=2,
                )
                draw.ellipse((x + 52, y + 88, x + 114, y + 150),
                             outline=(107, 114, 128), width=5)
                draw.line((x + 57, y + 119, x + 109, y + 119),
                          fill=(107, 114, 128), width=5)
                draw.text((x + 143, y + 81), "EMPTY SLOT",
                          font=header_font, fill=(156, 163, 175))
                draw.text((x + 143, y + 113), "Available for a teammate",
                          font=small_font, fill=(107, 114, 128))
                continue

            mon = party[slot] if isinstance(party[slot], dict) else {}
            # Use installed Gen-I sprites when present; fallback to a clear
            # species label if the optional sprite pack has not been downloaded.
            dex = mon.get("national_dex")
            sprite_path = Path(__file__).resolve().parent / "assets" / "gen1_sprites" / f"{int(dex)}.png" if dex else None
            sprite_box = (x + 18, y + 45, x + 132, y + 159)
            draw.rounded_rectangle(sprite_box, radius=14,
                                   fill=(24, 32, 45), outline=(55, 65, 81), width=1)
            sprite = None
            if sprite_path is not None and sprite_path.is_file():
                try:
                    with PILImage.open(sprite_path) as source:
                        sprite = source.convert("RGBA")
                        sprite.thumbnail((106, 106), PILImage.Resampling.NEAREST)
                except (OSError, ValueError):
                    sprite = None
            if sprite is not None:
                px = sprite_box[0] + (114 - sprite.width) // 2
                py = sprite_box[1] + (114 - sprite.height) // 2
                image.paste(sprite, (px, py), sprite)
            else:
                label = f"#{int(dex):03d}" if dex else f"ID {int(mon.get('species_index', 0)):02X}"
                draw.ellipse((x + 47, y + 70, x + 103, y + 126),
                             fill=(220, 228, 236), outline=(148, 163, 184), width=3)
                draw.ellipse((x + 62, y + 85, x + 88, y + 111),
                             fill=(31, 41, 55), outline=(148, 163, 184), width=2)
                draw.text((x + 40, y + 132), label, font=small_font,
                          fill=(203, 213, 225))

            name = str(mon.get("species", "Unknown")).replace("Nidoran♂", "Nidoran-M").replace("Nidoran♀", "Nidoran-F")
            draw.text((x + 146, y + 49), name[:22], font=header_font, fill=(243, 244, 246))
            draw.text((x + 146, y + 80), f"Lv. {mon.get('level', '?')}",
                      font=body_font, fill=(203, 213, 225))
            status = str(mon.get("status", "Unknown"))
            draw.text((x + 146, y + 110), status[:20], font=small_font,
                      fill=(74, 222, 128) if status == "OK" else (251, 191, 36))

            hp = mon.get("hp", "?")
            max_hp = mon.get("max_hp", "?")
            draw.text((x + 18, y + 171), f"HP  {hp}/{max_hp}",
                      font=small_font, fill=(226, 232, 240))
            bar = (x + 18, y + 194, x + card_w - 18, y + 209)
            draw.rounded_rectangle(bar, radius=7, fill=(55, 65, 81))
            fraction = cls._party_hp_fraction(mon)
            if fraction > 0:
                color = (34, 197, 94) if fraction > 0.5 else ((234, 179, 8) if fraction > 0.2 else (239, 68, 68))
                draw.rounded_rectangle(
                    (bar[0], bar[1], bar[0] + int((bar[2] - bar[0]) * fraction), bar[3]),
                    radius=7, fill=color,
                )

            moves = [str(move) for move in mon.get("moves", [])[:4]]
            draw.text((x + 18, y + 220), "MOVES", font=small_font, fill=(156, 163, 175))
            draw.text((x + 18, y + 241), (" / ".join(moves) or "No moves")[:47],
                      font=small_font, fill=(226, 232, 240))
            can_learn = cls._party_hm_text(mon.get("hm_can_learn", []))
            knows = cls._party_hm_text(mon.get("hm_knows", []))
            draw.text((x + 18, y + 266), f"CAN LEARN: {can_learn}"[:47],
                      font=small_font, fill=(147, 197, 253))
            draw.text((x + 18, y + 286), f"KNOWS: {knows}"[:47],
                      font=small_font, fill=(134, 239, 172))

        return np.asarray(image, dtype=np.uint8).copy()

    @staticmethod
    def _compose_gameplay_party(game_frame, party_board):
        game = PILImage.fromarray(np.asarray(game_frame, dtype=np.uint8)).convert("RGB")
        board = PILImage.fromarray(np.asarray(party_board, dtype=np.uint8)).convert("RGB")
        target_h = 760
        game_w = max(1, int(game.width * target_h / max(game.height, 1)))
        game = game.resize((game_w, target_h), PILImage.Resampling.NEAREST)
        canvas = PILImage.new("RGB", (game_w + board.width, target_h), (12, 18, 28))
        canvas.paste(game, (0, 0))
        canvas.paste(board, (game_w, 0))
        return np.asarray(canvas, dtype=np.uint8).copy()

    def _log_party_images(self):
        """Record party images through SB3's active logger, next to map images.

        The trainer uses TensorboardCallback, not GameStatsCallback. Using
        logger.record(Image(...)) guarantees the images go into the same
        poke_ppo_* event stream that already contains trajectory/explore_map.
        """
        if self.training_env is None or self.logger is None:
            return 0
        try:
            snapshots = self.training_env.env_method("read_party_snapshot")
        except Exception as exc:
            if not self._warned_party_read:
                self._warn(f"Party image logging could not call read_party_snapshot on VecEnv workers: {exc}")
                self._warned_party_read = True
            return 0

        if not isinstance(snapshots, (list, tuple)):
            self._warn("Party snapshot result was not a list/tuple; skipping party images.")
            return 0

        logged = 0
        board_for_first = None
        for env_index, party in enumerate(snapshots):
            if not isinstance(party, (list, tuple)):
                continue
            board = self._render_party_board(party, env_index, int(self.num_timesteps))
            self.logger.record(
                f"game/party_visual/env_{env_index:02d}",
                Image(board, "HWC"),
                exclude=("stdout", "log", "json", "csv"),
            )
            if env_index == 0:
                board_for_first = board
            logged += 1

        # Add a combined game + party image for worker 0 only, keeping event
        # volume reasonable for 16-worker training.
        if board_for_first is not None:
            try:
                frames = self.training_env.env_method(
                    "get_tensorboard_frame", self.party_frame_scale, indices=[0]
                )
                if frames and frames[0] is not None:
                    combined = self._compose_gameplay_party(frames[0], board_for_first)
                    self.logger.record(
                        "gameplay/with_party/env_00",
                        Image(combined, "HWC"),
                        exclude=("stdout", "log", "json", "csv"),
                    )
            except Exception as exc:
                if self.verbose:
                    self._warn(f"Could not add gameplay frame beside party board: {exc}")

        if logged == 0 and not self._warned_party_read:
            self._warn("No worker returned a party list; party images were not recorded.")
            self._warned_party_read = True
        elif logged and self.verbose:
            print(
                f"[TensorboardCallback] Recorded {logged} party board image(s) at "
                f"timestep {self.num_timesteps:,}; tags: game/party_visual/env_XX"
            )
        return logged

    def _on_step(self) -> bool:
        infos, dones = self._get_infos_and_dones()
        self._log_progress_scalars(infos)

        any_done = bool(dones.size and np.any(dones))
        map_due = self.num_timesteps - self._last_map_log_timestep >= self.map_log_every
        if any_done or map_due:
            self._completed_episode_stats = []
            episode_maps = self._update_maps_from_envs(infos, dones)
            if any_done:
                self._log_completed_episode_stats()

            if self.best_map_progress >= 0:
                self.logger.record("progress/best_ever_map_progress", float(self.best_map_progress))
                self.logger.record("progress/best_map_id", float(self.best_map_id))
            self.logger.record("progress/episodes_completed_total", float(self.episodes_completed))
            self.logger.record("trajectory/all_flags", json.dumps(self.event_flags, sort_keys=True))

            self._log_map_images(episode_maps)
            self._save_persisted_history()
            self._last_map_log_timestep = int(self.num_timesteps)

        if self.num_timesteps - self._last_party_image_timestep >= self.party_image_every:
            self._log_party_images()
            self._last_party_image_timestep = int(self.num_timesteps)

        return True

    def _on_training_end(self) -> None:
        # Save current lifetime maps even if training stopped before any worker
        # reached its episode limit. This prevents a partial episode from being
        # lost when the run is resumed later.
        try:
            self._completed_episode_stats = []
            self._update_maps_from_envs([], np.zeros(int(self.training_env.num_envs), dtype=bool))
            self._save_persisted_history()
        except Exception as exc:
            self._warn(f"Could not save final exploration history ({exc}).")

        if self.writer is not None:
            self.writer.flush()
            self.writer.close()
            self.writer = None
