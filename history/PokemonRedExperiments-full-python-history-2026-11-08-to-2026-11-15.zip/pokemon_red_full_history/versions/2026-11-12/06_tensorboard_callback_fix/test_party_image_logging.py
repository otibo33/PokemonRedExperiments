#!/usr/bin/env python3
"""Dependency-light integration test for TensorboardCallback party image tags.

Uses small Stable-Baselines3/TensorBoard stubs so it can test the callback's
actual recording path without launching PyBoy or PPO workers.
"""
from __future__ import annotations

import importlib.util
import sys
import types
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent

# Minimal import stubs; production training uses the real packages.
sb3 = types.ModuleType("stable_baselines3")
common = types.ModuleType("stable_baselines3.common")
callbacks = types.ModuleType("stable_baselines3.common.callbacks")
logger_mod = types.ModuleType("stable_baselines3.common.logger")

class BaseCallback:
    def __init__(self, verbose=0):
        self.verbose = verbose
        self.logger = None
        self.training_env = None
        self.num_timesteps = 0

class SB3Image:
    def __init__(self, image, data_format):
        self.image = np.asarray(image)
        self.data_format = data_format

callbacks.BaseCallback = BaseCallback
logger_mod.Image = SB3Image
sys.modules.setdefault("stable_baselines3", sb3)
sys.modules.setdefault("stable_baselines3.common", common)
sys.modules.setdefault("stable_baselines3.common.callbacks", callbacks)
sys.modules.setdefault("stable_baselines3.common.logger", logger_mod)

# The callback's histogram writer is unrelated to party images; stub its
# import because the test only exercises SB3 logger.record(Image(...)).
torch_mod = types.ModuleType("torch")
torch_utils = types.ModuleType("torch.utils")
torch_tb = types.ModuleType("torch.utils.tensorboard")
class SummaryWriter:
    def __init__(self, *args, **kwargs): pass
    def add_histogram(self, *args, **kwargs): pass
    def flush(self): pass
    def close(self): pass
torch_tb.SummaryWriter = SummaryWriter
sys.modules.setdefault("torch", torch_mod)
sys.modules.setdefault("torch.utils", torch_utils)
sys.modules.setdefault("torch.utils.tensorboard", torch_tb)

spec = importlib.util.spec_from_file_location("patched_tensorboard_callback", ROOT / "tensorboard_callback.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
TensorboardCallback = module.TensorboardCallback

class FakeLogger:
    def __init__(self):
        self.records = {}
    def record(self, tag, value, **kwargs):
        self.records[tag] = value

class FakeVecEnv:
    num_envs = 2
    def env_method(self, method_name, *args, indices=None, **kwargs):
        if method_name == "read_party_snapshot":
            return [
                [{
                    "slot": 1, "species_index": 25, "species": "Pikachu",
                    "national_dex": 25, "level": 12, "hp": 30,
                    "max_hp": 30, "status": "OK", "moves": ["Thunder Shock", "Quick Attack"],
                    "hm_can_learn": ["FLASH"], "hm_knows": [],
                }],
                [],
            ]
        if method_name == "get_tensorboard_frame":
            assert indices == [0]
            return [np.zeros((144 * int(args[0]), 160 * int(args[0]), 3), dtype=np.uint8)]
        raise AttributeError(method_name)

callback = TensorboardCallback.__new__(TensorboardCallback)
callback.logger = FakeLogger()
callback.training_env = FakeVecEnv()
callback.num_timesteps = 123456
callback.party_frame_scale = 3
callback.verbose = 1
callback._warned_party_read = False

logged = callback._log_party_images()
expected = {
    "game/party_visual/env_00",
    "game/party_visual/env_01",
    "gameplay/with_party/env_00",
}
actual = set(callback.logger.records)
assert expected.issubset(actual), f"Missing image tags: {expected - actual}"
for tag in expected:
    item = callback.logger.records[tag]
    assert isinstance(item, SB3Image), f"{tag} was not recorded as an SB3 image"
    assert item.image.ndim == 3 and item.image.shape[2] == 3, (tag, item.image.shape)
assert logged == 2, f"Expected 2 party boards, logged {logged}"
print("PASS: TensorboardCallback recorded party boards and gameplay composite:")
for tag in sorted(expected):
    print(" -", tag, callback.logger.records[tag].image.shape)
