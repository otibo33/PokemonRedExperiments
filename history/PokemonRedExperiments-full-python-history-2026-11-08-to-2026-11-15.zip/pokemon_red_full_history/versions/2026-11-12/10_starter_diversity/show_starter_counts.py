#!/usr/bin/env python3
"""Print persistent starter-selection counts for a training session."""
from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

STARTERS = ("Bulbasaur", "Charmander", "Squirtle")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("session_dir", nargs="?", default="runs")
    args = parser.parse_args()
    database = Path(args.session_dir).expanduser() / "starter_choice_counts.sqlite3"
    if not database.is_file():
        print(f"No starter-choice history yet: {database}")
        return 1
    with sqlite3.connect(str(database), timeout=10) as connection:
        counts = dict(connection.execute("SELECT species, count FROM starter_counts"))
    total = sum(int(counts.get(name, 0)) for name in STARTERS)
    print(f"Starter selections recorded: {total}")
    for name in STARTERS:
        count = int(counts.get(name, 0))
        pct = (100.0 * count / total) if total else 0.0
        print(f"  {name:<10} {count:>6}  ({pct:5.1f}%)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
