#!/usr/bin/env python3
"""Verify whether a PyBoy save state is actually before starter selection."""
from __future__ import annotations

import argparse
from pathlib import Path

from pyboy import PyBoy

STARTER_NAMES = {0x99: "Bulbasaur", 0xB0: "Charmander", 0xB1: "Squirtle"}
PARTY_COUNT_ADDRESS = 0xD163
PARTY_FIRST_SPECIES_ADDRESS = 0xD164


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("rom", type=Path)
    parser.add_argument("state", type=Path)
    args = parser.parse_args()
    if not args.rom.is_file():
        parser.error(f"ROM not found: {args.rom}")
    if not args.state.is_file():
        parser.error(f"Save state not found: {args.state}")

    emulator = PyBoy(str(args.rom), window="null", sound_emulated=False)
    try:
        with args.state.open("rb") as handle:
            emulator.load_state(handle)
        party_count = int(emulator.memory[PARTY_COUNT_ADDRESS])
        first_species = int(emulator.memory[PARTY_FIRST_SPECIES_ADDRESS]) if party_count else 0
        first_name = STARTER_NAMES.get(first_species, f"internal species 0x{first_species:02X}")
        print(f"Save state: {args.state}")
        print(f"Party count: {party_count}")
        if party_count == 0:
            print("PASS: no Pokémon in the party; the AI can make the starter choice.")
            return 0
        print(f"FAIL: first party slot is {first_name}.")
        print("This state is after a Pokémon entered the party; the AI cannot choose from it.")
        return 2
    finally:
        emulator.stop()


if __name__ == "__main__":
    raise SystemExit(main())
