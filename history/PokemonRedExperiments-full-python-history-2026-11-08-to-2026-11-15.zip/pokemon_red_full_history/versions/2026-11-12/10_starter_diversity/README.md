# Pokémon Red — balanced party + starter-choice diversity update

This update builds on the existing balanced/diverse party environment and most-advanced-party TensorBoard callback. It does not force a starter or modify the action/observation spaces.

## Why the policy keeps selecting Charmander

The previous party patch rewarded collecting distinct Pokémon and balancing party levels, but it had no reward for choosing a less-used *starter*. A resumed PPO policy can therefore keep repeating a preference learned before the start state was changed.

## What this update changes

- Tracks Bulbasaur, Charmander, and Squirtle selections in `starter_choice_counts.sqlite3` inside the TensorBoard session directory.
- All parallel workers share this database. SQLite transactions serialize simultaneous choices safely.
- The currently least-selected starter gets the full novelty reward. Repeating an overrepresented starter earns less.
- The agent still chooses by taking its own movement and A-button actions. No worker is assigned a species and no action is injected.
- The choice history survives PPO checkpoint resumes as long as the same session directory is reused.
- TensorBoard adds `game/starter_choices/bulbasaur`, `game/starter_choices/charmander`, `game/starter_choices/squirtle`, and `game/starter_diversity_reward_mean`.
- `show_starter_counts.py` prints the three persistent counts.
- The balanced-party, capture, and HM objectives are preserved. Observation keys/shapes, action space, and PPO architecture are unchanged.

## Reward behaviour

Default `starter_diversity_weight` is 20.0. With the existing `reward_scale=0.5`, the first choice receives up to 10 reward points. The novelty bonus is:

`weight * (least_used_count + 1) / (chosen_starter_count + 1)`

For example, after Charmander has been selected once and Bulbasaur/Squirtle have not been selected, another Charmander receives half the bonus while either underrepresented starter receives the full bonus.

This encourages a balanced population of choices; it does not guarantee an exactly equal distribution. The policy still needs stochastic exploration to discover alternative action sequences.

## Install (Fish / Konsole)

Stop training and back up the current files:

```fish
cp red_gym_env_v2.py red_gym_env_v2.py.before_starter_diversity
cp tensorboard_callback.py tensorboard_callback.py.before_starter_diversity
```

Extract and copy the files into your `v2` directory:

```fish
unzip -o /path/to/pokemon_red_starter_diversity_patch.zip -d /tmp/pokemon_red_starter_diversity
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/red_gym_env_v2.py .
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/starter_diversity.py .
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/tensorboard_callback.py .
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/test_starter_diversity.py .
cp /tmp/pokemon_red_starter_diversity/pokemon_red_balanced_diverse_party/show_starter_counts.py .
```

Validate with the project's `.venv` active:

```fish
python -m py_compile red_gym_env_v2.py starter_diversity.py tensorboard_callback.py test_starter_diversity.py show_starter_counts.py
python test_starter_diversity.py
python show_starter_counts.py runs
```

## Resume training

Keep your single pre-starter save state (`../starter_choice.state`) and resume the existing PPO checkpoint. Add `--ent-coef 0.05` to fine-tune with more stochastic exploration, plus `--init-state ../starter_choice.state` if it is not already in your command. Keep the same session directory so starter counts persist.

Do not delete `starter_choice_counts.sqlite3` between resumes; it is the shared memory for population-level starter balance. Delete it only if you intentionally want to restart the starter-frequency experiment from zero.

## Notes

- If the start state already contains a starter in the party, the environment treats it as preselected and does not award a policy-choice bonus. The intended initial state has party count zero and all three Poké Balls available.
- `--ent-coef 0.05` raises policy entropy during fine-tuning; it may increase exploration in other parts of the game too. If that destabilizes progression, reduce it to `0.03`.
- This reward only affects choices discovered after installing the patch. Existing checkpoint weights are preserved and must be fine-tuned to learn the new objective.
- Unit tests cover reward ranking, persistence across process restarts, concurrent writes, and invalid species rejection. A live PyBoy/SB3 training run is still required to confirm the agent learns to vary its choices.
