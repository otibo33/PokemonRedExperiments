Pokémon Red TensorBoard party-image selection patch

What changed
------------
- Adds the exact TensorBoard image tag: game/party_visual/env
- That tag records one image only: the party belonging to the worker selected
  by the callback's best-progression ranking.
- Ranking prioritizes highest best_map_progress (furthest story-map milestone
  ever reached), then current map_progress, then badges and team readiness.
- Keeps game/party_visual/most_advanced as an identical compatibility tag.
- Leaves all other callback functionality unchanged.
- stream_agent_wrapper.py is not changed; it only streams coordinates and is
  not responsible for TensorBoard party images.

Install (Fish / Konsole)
------------------------
From the project's v2 directory:

  cp tensorboard_callback.py tensorboard_callback.py.backup
  cp /path/to/extracted/tensorboard_callback.py .

Replace /path/to/extracted/ with the directory where you extracted this ZIP.
Stop training before replacing the callback, then restart training as usual.

Checks performed
----------------
- Python syntax compilation passed.
- Mocked selection test: furthest best_map_progress wins.
- Mocked tie test: current map_progress beats a higher badge count.
- Mocked TensorBoard test: exactly one image is logged under
  game/party_visual/env, and the compatibility tag remains.

Live PyBoy/SB3 integration was not run in this environment.
