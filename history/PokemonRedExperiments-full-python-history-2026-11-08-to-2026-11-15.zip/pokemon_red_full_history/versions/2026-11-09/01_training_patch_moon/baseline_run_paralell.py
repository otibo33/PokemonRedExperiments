#!/usr/bin/env python3
"""Parallel Pokémon Red PPO training with safe checkpoint resume.

Default mode preserves the original observation structure for existing
checkpoints. Pass --nav to add map_id/extras observations; that mode uses a
separate runs_v3 directory and must start from a navigation-compatible model.
"""

from __future__ import annotations

import argparse
import re
import time
from pathlib import Path
from typing import Sequence

from red_gym_env_v2 import RedGymEnv
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback, CallbackList
from stable_baselines3.common.utils import set_random_seed
from stable_baselines3.common.vec_env import SubprocVecEnv

from game_stats_callback import GameStatsCallback


class RollingCheckpointCallback(BaseCallback):
    """Save checkpoints by aggregate timesteps and retain only the newest N."""

    def __init__(
        self,
        save_dir: Path,
        every_timesteps: int = 5_000_000,
        keep: int = 5,
        prefix: str = "poke",
        verbose: int = 1,
    ) -> None:
        super().__init__(verbose=verbose)
        if every_timesteps <= 0:
            raise ValueError("every_timesteps must be positive")
        if keep < 1:
            raise ValueError("keep must be at least 1")
        self.save_dir = Path(save_dir)
        self.every_timesteps = int(every_timesteps)
        self.keep = int(keep)
        self.prefix = prefix
        self.last_saved_timestep = 0

    def _init_callback(self) -> None:
        self.save_dir.mkdir(parents=True, exist_ok=True)
        # On resume, avoid immediately rewriting a checkpoint at timestep 0.
        self.last_saved_timestep = int(self.model.num_timesteps)

    def _on_step(self) -> bool:
        if self.num_timesteps - self.last_saved_timestep < self.every_timesteps:
            return True

        timestep = int(self.num_timesteps)
        checkpoint_stem = self.save_dir / f"{self.prefix}_{timestep}_steps"
        self.model.save(str(checkpoint_stem))
        self.last_saved_timestep = timestep
        self._prune_old_checkpoints()

        if self.verbose:
            print(f"[checkpoint] saved {checkpoint_stem}.zip")
        return True

    def _prune_old_checkpoints(self) -> None:
        pattern = re.compile(rf"^{re.escape(self.prefix)}_(\d+)_steps\.zip$")
        checkpoints: list[tuple[int, Path]] = []
        for path in self.save_dir.glob(f"{self.prefix}_*_steps.zip"):
            match = pattern.match(path.name)
            if match:
                checkpoints.append((int(match.group(1)), path))

        checkpoints.sort(key=lambda item: item[0], reverse=True)
        for _timestep, old_path in checkpoints[self.keep :]:
            old_path.unlink(missing_ok=True)


def make_env(rank: int, env_conf: dict, base_seed: int):
    """Build one emulator process; VecEnv supplies the seeded reset."""

    def _init():
        worker_seed = int(base_seed) + int(rank)
        set_random_seed(worker_seed)
        return RedGymEnv(dict(env_conf))

    return _init


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Parallel Pokémon Red PPO training")
    parser.add_argument("--resume", type=str, default=None, help="Checkpoint path (.zip optional)")
    parser.add_argument("--timesteps", type=int, default=500_000_000)
    parser.add_argument("--num-cpu", type=int, default=6)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--seed", type=int, default=None,
                        help="Random seed. Defaults to a time-derived seed.")
    parser.add_argument("--nav", action="store_true",
                        help="Use map_id/extras observations; starts a fresh runs_v3 session by default")
    parser.add_argument("--session-dir", type=str, default=None)
    parser.add_argument("--gb-path", type=str, default="../PokemonRed.gb")
    parser.add_argument("--init-state", action="append", dest="init_states",
                        help="Initial state path; repeat this option to configure weighted start states")
    parser.add_argument("--save-every", type=int, default=5_000_000,
                        help="Checkpoint interval in aggregate environment timesteps")
    parser.add_argument("--keep-checkpoints", type=int, default=5)
    parser.add_argument("--n-epochs", type=int, default=None,
                        help="Optional PPO epoch override (also applies after loading)")
    parser.add_argument("--ent-coef", type=float, default=None,
                        help="Optional PPO entropy coefficient override")
    return parser


def resolve_checkpoint(raw_path: str) -> Path:
    path = Path(raw_path).expanduser()
    candidates = [path]
    if path.suffix != ".zip":
        candidates.append(Path(f"{path}.zip"))
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"Checkpoint not found: {raw_path}")


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.num_cpu < 1:
        raise ValueError("--num-cpu must be at least 1")
    if args.timesteps < 1:
        raise ValueError("--timesteps must be positive")

    base_seed = int(args.seed) if args.seed is not None else int(time.time()) % 100_000
    set_random_seed(base_seed)

    # Preserve the original episode and PPO rollout dimensions.
    ep_length = 2048 * 80
    train_steps_batch = ep_length // 64

    if args.session_dir:
        sess_path = Path(args.session_dir).expanduser()
    else:
        sess_path = Path("runs_v3" if args.nav else "runs")
    sess_path.mkdir(parents=True, exist_ok=True)

    init_states = args.init_states or ["../init.state"]
    init_state_config: str | list[str]
    init_state_config = init_states[0] if len(init_states) == 1 else init_states

    env_config = {
        "headless": True,
        "save_final_state": False,
        "early_stop": False,
        "action_freq": 24,
        "init_state": init_state_config,
        "max_steps": ep_length,
        "print_rewards": False,
        "save_video": False,
        "fast_video": True,
        "session_path": sess_path,
        "gb_path": args.gb_path,
        "reward_scale": 0.5,
        "explore_weight": 0.25,
        "map_progress_weight": 5.0,
        "stuck_penalty_weight": 1.0,
        "new_map_weight": 0.5,
        "mt_moon_navigation_weight": 2.0,
        "include_navigation_obs": bool(args.nav),
    }

    print("\nPokémon Red Parallel PPO Training")
    print("---------------------------------")
    print(f"Parallel environments: {args.num_cpu}")
    print(f"Episode length: {ep_length:,}")
    print(f"PPO n_steps per environment: {train_steps_batch:,}")
    print(f"Aggregate rollout size: {train_steps_batch * args.num_cpu:,}")
    print(f"Training timesteps requested: {args.timesteps:,}")
    print(f"Device: {args.device}")
    print(f"Session directory: {sess_path}")
    print(f"Start states: {init_states}")
    print(f"Seed: {base_seed}")
    print(f"Navigation observations: {args.nav}")
    print(f"Resume checkpoint: {args.resume or 'None (new model)'}")
    print("---------------------------------\n")

    env = None
    model = None
    try:
        env = SubprocVecEnv(
            [make_env(i, env_config, base_seed) for i in range(args.num_cpu)],
            start_method="spawn",
        )
        # SubprocVecEnv applies these seeds on the next reset, including the
        # reset performed when learn() starts.
        env.seed(base_seed)

        checkpoint_callback = RollingCheckpointCallback(
            save_dir=sess_path,
            every_timesteps=args.save_every,
            keep=args.keep_checkpoints,
            prefix="poke",
            verbose=1,
        )
        callbacks = CallbackList([
            checkpoint_callback,
            GameStatsCallback(every=2560),
        ])

        if args.resume:
            checkpoint = resolve_checkpoint(args.resume)
            print(f"Loading checkpoint: {checkpoint}")
            try:
                # Supplying env=env makes SB3 validate observation/action spaces
                # before attaching the environment and rebuilding PPO's buffers.
                model = PPO.load(str(checkpoint), env=env, device=args.device)
            except ValueError as exc:
                message = str(exc).lower()
                if "spaces do not match" in message:
                    raise RuntimeError(
                        "Checkpoint/environment spaces do not match. "
                        "Do not force this resume. Use the legacy observation mode "
                        "for an old checkpoint, or start a fresh --nav run in runs_v3."
                    ) from exc
                raise

            # Ensure a loaded model writes logs into this session directory.
            model.tensorboard_log = str(sess_path)
            model.seed = base_seed
        else:
            print("Starting a new PPO model")
            model = PPO(
                "MultiInputPolicy",
                env,
                verbose=1,
                device=args.device,
                n_steps=train_steps_batch,
                batch_size=512,
                n_epochs=1,
                gamma=0.997,
                ent_coef=0.01,
                tensorboard_log=str(sess_path),
                seed=base_seed,
            )

        # Saved PPO hyperparameters take precedence on resume unless explicitly
        # overridden on the command line.
        if args.n_epochs is not None:
            model.n_epochs = int(args.n_epochs)
        if args.ent_coef is not None:
            model.ent_coef = float(args.ent_coef)

        print("\nPolicy:")
        print(model.policy)

        model.learn(
            total_timesteps=args.timesteps,
            callback=callbacks,
            tb_log_name="poke_ppo_nav" if args.nav else "poke_ppo",
            reset_num_timesteps=args.resume is None,
        )

        final_path = sess_path / "poke_final"
        model.save(str(final_path))
        print(f"\nTraining complete. Final model saved to {final_path}.zip")
        return 0

    except KeyboardInterrupt:
        print("\nTraining interrupted. Saving current model...")
        if model is not None:
            interrupted_path = sess_path / "poke_interrupted"
            model.save(str(interrupted_path))
            print(f"Interrupted model saved to {interrupted_path}.zip")
        return 130

    finally:
        if env is not None:
            env.close()


if __name__ == "__main__":
    raise SystemExit(main())
