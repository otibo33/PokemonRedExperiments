Pokemon Red PPO - Mt. Moon progression patch
============================================

What changed
------------
This patch addresses the Mt. Moon B2F bottleneck without changing the
observation-space keys or shapes. It is intended to be reward-only compatible
with the legacy PPO policy (still run the smoke test and let SB3 validate the
checkpoint before committing to a long run).

1) Confirmed Mt. Moon event milestones
   - Mt. Moon 1F trainer victories
   - Mt. Moon exit Super Nerd victory
   - Mt. Moon B2F Rocket trainer victories
   - Dome Fossil acquired
   - Helix Fossil acquired

   These event IDs are mapped to D7F5/D7F6 using the event flag base D747 and
   the MSB-first bit ordering already used by this environment's event logger.
   See pret/pokered/constants/event_constants.asm.

2) Coordinate shaping on Mt. Moon B2F
   - Map ID $3D (decimal 61) is Mt. Moon B2F.
   - Before the exit Super Nerd flag is set, shaping rewards best progress
     toward the scripted player trigger coordinate x=13, y=8.
   - After the Super Nerd is defeated, shaping rewards best progress into the
     fossil area (x=11..14, y=5..8).
   - The actual Super Nerd and fossil event flags, not proximity, determine
     whether those objectives are complete.

3) TensorBoard diagnostics
   Numeric info keys and callback metrics now include:
   map_id, x, y, mt_moon_stage, mt_moon_trainer_wins, mt_moon_approach,
   mt_moon_super_nerd_defeated, fossil_obtained.

Compatibility
-------------
- No observation fields were added or removed by this Mt. Moon patch.
- Do not enable/disable --nav when resuming: the checkpoint's observation mode
  must match the environment mode used to create it.
- The changed reward targets may cause explained_variance/value loss to shift
  while the critic adapts. Compare over several rollouts; don't judge it from
  the first few updates.
- Python syntax compilation was run here. PyBoy, Gymnasium and SB3 are not
  installed in this authoring runtime, so the real-ROM smoke test must be run
  in the project's virtual environment.

Recommended local sequence
--------------------------
1) Stop the active run with Ctrl+C so the training script saves
   runs/poke_interrupted.zip (or use the latest valid checkpoint).
2) Replace the corresponding environment, trainer and callback files with
   those in this patch.
3) From the project folder run:

   python smoke_test_env.py --gb-path ../PokemonRed.gb --init-state ../init.state

4) If the test passes, resume with the matching observation mode and checkpoint:

   python baseline_run_paralell.py --resume runs/poke_interrupted --timesteps 200000000

For a navigation-aware policy, use --nav only with a checkpoint trained with
that same observation schema. This patch does not require --nav.

Useful TensorBoard interpretation
---------------------------------
- in_mt_moon=1: the environment is currently on one of the three Mt. Moon maps.
- mt_moon_b2f_reached=1: B2F has been visited during this episode.
- mt_moon_stage=1: Mt. Moon entered, but the exit Super Nerd is not defeated.
- mt_moon_approach rising toward 1: the agent is approaching x=13,y=8.
- mt_moon_stage=2: Super Nerd victory flag is set; the fossil area is next.
- mt_moon_approach rising above 1: the agent is approaching the fossil area.
- fossil_obtained=1 and mt_moon_stage=3: Dome or Helix Fossil event flag is set.
