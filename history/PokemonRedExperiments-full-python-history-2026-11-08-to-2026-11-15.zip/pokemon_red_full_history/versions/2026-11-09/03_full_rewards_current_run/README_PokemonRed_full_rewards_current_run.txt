Pokémon Red PPO — full story-reward update for the existing run
===============================================================

Purpose
-------
This package updates the reward system and training/logging code while keeping
RedGymEnv's legacy observation dictionary and action space. It is intended to
resume the existing runs/poke_interrupted checkpoint, not to create a new
navigation-observation policy.

The current known training layout is preserved:
- ROM: ../PokemonRed.gb
- initial save state: ../init.state
- session/checkpoints: runs/
- six parallel environments by default
- PPO rollout size: 2,560 steps per environment
- PPO settings: batch_size=512, n_epochs=1, gamma=0.997, ent_coef=0.01
- CUDA by default

What is included
----------------
red_gym_env_v2.py
  Reward-only environment update. Preserves the existing observation keys,
  shapes, action count and Dict observation structure. Adds 83 curated story
  milestones, Mt. Moon objective shaping, capped healing, map visitation
  bonuses, and movement-only stuck tracking.

baseline_run_paralell.py
  Training script that automatically finds the newest versioned checkpoint in
  runs/. If none exists, it falls back to runs/poke_interrupted.zip and then
  runs/poke_final.zip. It retains checkpoint-space validation and does not
  overwrite the original checkpoint when saving later interrupted/final models.

game_stats_callback.py
  TensorBoard logging for the current map, exploration, story progress and
  Mt. Moon stages. Newly completed story flags are sent as small event tuples,
  not as 83 boolean keys on every worker step.

smoke_test_env.py
  Real-ROM/PyBoy smoke test for observation_space.contains() and finite rewards.

story_milestones.csv
  Full list of all 83 curated milestone event IDs and their additional rewards.

Checkpoint compatibility
------------------------
No new observation fields have been added. The legacy observation keys remain:
  screens, health, level, badges, events, map, recent_actions

Their declared shapes remain the legacy shapes:
  screens       (72, 80, 3) uint8
  health        scalar float32 Box (one feature after flattening)
  level         (8,) float32
  badges        (8,) MultiBinary
  events        (2488,) MultiBinary
  map           (48, 48, 1) uint8
  recent_actions (3,) MultiDiscrete([7, 7, 7])

The event observation vector remains MSB-first, exactly as the original code's
f"{value:08b}" construction. Story reward lookup uses the ROM constants'
LSB-first bit numbering. This distinction is intentional and is required to
keep the observation encoding stable while mapping milestone IDs correctly.

The trainer calls PPO.load(..., env=env), which checks the checkpoint's saved
spaces against the live environment. If the spaces do not match, it stops and
prints an explanation. Do not bypass that check or force-load an incompatible
policy.

Important: a Stable-Baselines3 PPO checkpoint saves the learned policy and
optimizer state; it does not save the live PyBoy emulator frame. Episodes still
start from ../init.state unless you pass a different --init-state. Resuming
runs/poke_interrupted therefore resumes the learned policy, not the exact
in-memory game position from the time Ctrl+C was pressed.

Reward design (default trainer configuration)
----------------------------------------------
The trainer uses:
  reward_scale=0.5
  explore_weight=0.25
  map_progress_weight=5.0
  new_map_weight=0.5
  stuck_penalty_weight=1.0

At reward_scale=0.5:
- Every newly-set generic event flag contributes +2.0.
- Each curated story milestone adds its CSV weight as an additional one-time
  bonus. The milestone bonuses stack with the generic event reward.
- Each increase in the existing curated map-progress ladder adds +2.5 to the
  cumulative progress score. The original known early-game map ordering is
  retained rather than extending it with unverified map-order guesses.
- Each distinct map visited adds +0.25 to the cumulative new-map score.
- Exploration adds +0.0125 per newly-seen coordinate.
- Badge reward is +5 per badge.
- Healing reward is capped at +2.5 per episode.
- The stuck penalty ramps after 10 directional movement attempts on the same
  tile and reaches -0.5 at 50 attempts. Button presses used for dialogue,
  menu navigation and object interaction do not increase this counter.

Mt. Moon has a separate stage-aware reward:
- B2F approach potential rises as the player approaches the Super Nerd trigger
  coordinate (13, 8).
- After the Super Nerd is defeated, potential rises as the player approaches
  the script-defined adjacent tiles for either fossil.
- The Dome Fossil ($57E) or Helix Fossil ($57F) event adds a +12 milestone bonus
  plus the generic +2 event reward.
- Leaving Mt. Moon after obtaining a fossil adds a further +1 exit reward.
- The Super Nerd event ($579) adds +6 extra, in addition to its generic event
  reward. Individual Mt. Moon trainer milestones are smaller (+0.5 or +0.75).

The fossil approach tiles are taken from the original MtMoonB2F script:
  Dome Fossil side: (12,7), (11,6), (12,5)
  Helix Fossil side: (13,7), (14,6), (14,5)

The curated event table is bounded by the legacy event-observation memory range.
It does not expand the event observation array to cover event constants beyond
that range, because doing so would change the checkpoint's observation space.

TensorBoard
-----------
The callback writes aggregate values under game/ including:
  map_progress, map_id, seen_tiles, visited_maps, badges, events, levels_sum,
  deaths, story_milestone_count, new_story_milestone_count,
  story_milestone_score, story_milestone_reward, in_mt_moon,
  mt_moon_b2f_reached, mt_moon_stage, mt_moon_trainer_wins,
  mt_moon_nerd_approach, mt_moon_fossil_approach, mt_moon_approach,
  mt_moon_super_nerd_defeated, dome_fossil_obtained,
  helix_fossil_obtained, fossil_obtained, mt_moon_exit_after_fossil,
  mt_moon_navigation_reward, mt_moon_exit_reward.

Each newly unlocked objective is also counted under story/unlocked/<slug>.
Mt. Moon stage meanings:
  0 = not reached
  1 = Mt. Moon entered
  2 = B2F reached, Super Nerd not defeated
  3 = Super Nerd defeated
  4 = fossil obtained, still inside Mt. Moon
  5 = fossil obtained and cave exited

Run instructions
-----------------
Run these commands from the project folder containing red_gym_env_v2.py,
global_map.py, events.json and the ROM/save-state paths shown above.

1) Test the real environment before a long run:
   python smoke_test_env.py --gb-path ../PokemonRed.gb --init-state ../init.state --steps 500

2) Validate the actual saved checkpoint against the live environment without
   starting PPO training (only one emulator worker is needed for this check):
   python baseline_run_paralell.py --check-only --num-cpu 1 --device cpu

3) Resume training from the newest checkpoint in runs/ (or the original known
   runs/poke_interrupted.zip if no versioned checkpoint exists):
   python baseline_run_paralell.py --timesteps 500000000 --num-cpu 6

The default resume selection checks versioned poke_<steps>_steps.zip,
poke_final_<steps>_steps.zip and poke_interrupted_<steps>_steps.zip files, then
falls back to runs/poke_interrupted.zip. Pass --resume <path> to choose a
specific checkpoint explicitly.

To start an entirely new policy instead:
   python baseline_run_paralell.py --fresh --timesteps 500000000 --num-cpu 6

To test/use multiple PyBoy start states, repeat --init-state:
   python smoke_test_env.py --gb-path ../PokemonRed.gb \
     --init-state states/pallet.state --init-state states/after_brock.state
   python baseline_run_paralell.py --init-state states/pallet.state \
     --init-state states/after_brock.state --timesteps 500000000

Checkpoint files
----------------
Periodic checkpoint:   runs/poke_<aggregate_timesteps>_steps.zip
Ctrl+C checkpoint:     runs/poke_interrupted_<aggregate_timesteps>_steps.zip
Completed model:       runs/poke_final_<aggregate_timesteps>_steps.zip

The periodic checkpoint callback retains the latest five periodic checkpoints.
Versioned interrupted/final checkpoints and the original runs/poke_interrupted.zip
are not deleted or overwritten.

Validation performed here
-------------------------
- Python syntax compilation passed for all four Python files.
- A mocked reward-logic test passed for all 83 unique milestone IDs, their event
  cache bounds, LSB reward mapping, MSB observation order, museum-ticket
  exclusion, corrected Bill/S.S. Ticket flags and Mt. Moon stage transitions.
- This authoring environment does not have PyBoy, Gymnasium or Stable-Baselines3
  installed, so it could not run the real-ROM smoke test or load the user's PPO
  checkpoint. Run steps 1 and 2 above in the project's .venv before the 500M run.
