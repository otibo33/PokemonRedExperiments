"""TensorBoard callback for progression metrics returned by RedGymEnv.step()."""

from __future__ import annotations

import numpy as np
from stable_baselines3.common.callbacks import BaseCallback


class GameStatsCallback(BaseCallback):
    """Average numeric game metrics across workers every ``every`` timesteps."""

    KEYS = (
        "map_progress",
        "map_id",
        "seen_tiles",
        "visited_maps",
        "badges",
        "events",
        "levels_sum",
        "deaths",
        "story_milestone_count",
        "new_story_milestone_count",
        "story_milestone_score",
        "story_milestone_reward",
        "in_mt_moon",
        "mt_moon_b2f_reached",
        "mt_moon_stage",
        "mt_moon_trainer_wins",
        "mt_moon_nerd_approach",
        "mt_moon_fossil_approach",
        "mt_moon_approach",
        "mt_moon_super_nerd_defeated",
        "dome_fossil_obtained",
        "helix_fossil_obtained",
        "fossil_obtained",
        "mt_moon_exit_after_fossil",
        "mt_moon_navigation_reward",
        "mt_moon_exit_reward",
    )

    def __init__(self, every: int = 2560, verbose: int = 0):
        if every <= 0:
            raise ValueError("every must be a positive integer")
        super().__init__(verbose=verbose)
        self.every = int(every)
        self._last_log_timestep = 0
        self._pending_milestone_counts: dict[str, int] = {}

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", ())

        # Capture one-time event transitions on every VecEnv step, not only
        # on metric-dump steps, so rare milestones cannot be missed.
        for info in infos:
            if not isinstance(info, dict):
                continue
            for slug in info.get("new_story_milestones", ()):
                self._pending_milestone_counts[slug] = (
                    self._pending_milestone_counts.get(slug, 0) + 1
                )

        if self.num_timesteps - self._last_log_timestep < self.every:
            return True

        self._last_log_timestep = self.num_timesteps

        # Fixed aggregate metrics.
        for key in self.KEYS:
            values = [
                float(info[key])
                for info in infos
                if isinstance(info, dict)
                and key in info
                and isinstance(info[key], (int, float, np.number))
            ]
            if values:
                self.logger.record(f"game/{key}", float(np.mean(values)))

        # These are counts accumulated since the last metric dump. A zero
        # row is omitted when nothing new happened during the interval.
        for slug, count in self._pending_milestone_counts.items():
            self.logger.record(f"story/unlocked/{slug}", float(count))
        self._pending_milestone_counts.clear()

        return True
