import uuid
from pathlib import Path

import numpy as np
from skimage.transform import downscale_local_mean
import matplotlib.pyplot as plt
from pyboy import PyBoy
#from pyboy.logger import log_level
import mediapy as media
from einops import repeat

from gymnasium import Env, spaces
from pyboy.utils import WindowEvent

from global_map import local_to_global, GLOBAL_MAP_SHAPE

event_flags_start = 0xD747
event_flags_end = 0xD87E # expand for SS Anne # old - 0xD7F6 
museum_ticket = (0xD754, 0)

# Pokémon Red's event constants are numbered low-bit first within each RAM
# byte. Keep this separate from read_event_bits(), whose MSB-first order is
# retained for compatibility with existing PPO observations.
MT_MOON_MAP_IDS = frozenset((0x3B, 0x3C, 0x3D))
MT_MOON_B2F_MAP_ID = 0x3D


def event_id_to_ram_key(event_id):
    """Convert a pret/pokered event constant into (RAM address, LSB bit)."""
    event_id = int(event_id)
    return event_flags_start + event_id // 8, event_id % 8


# (event constant, metric slug, readable name, extra reward weight).
# The reward weight is multiplied by reward_scale * 2; with the current
# reward_scale=0.5 this is the literal additional reward for the milestone.
# Trainer flags are intentionally modest because the generic event reward
# already pays for every newly-set event bit.
STORY_MILESTONE_DEFS = (
    (0x020, "followed_oak_into_lab_2", "Followed Oak into the lab", 1.0),
    (0x022, "got_starter", "Received starter Pokémon", 3.0),
    (0x023, "oak_lab_rival_battle", "Battled rival in Oak's lab", 1.5),
    (0x024, "got_pokeballs", "Received Poké Balls from Oak", 1.0),
    (0x025, "got_pokedex", "Received the Pokédex", 1.0),
    (0x026, "returned_pallet_after_pokeballs", "Returned to Pallet after receiving Poké Balls", 0.5),
    (0x027, "oak_appeared_pallet", "Oak appeared in Pallet", 0.5),
    (0x038, "oak_received_parcel", "Oak received the parcel", 1.0),
    (0x039, "got_oaks_parcel", "Obtained Oak's parcel", 0.5),
    (0x051, "beat_viridian_gym_giovanni", "Defeated Giovanni in the Viridian Gym", 6.0),
    (0x069, "got_old_amber", "Obtained the Old Amber", 0.75),
    (0x077, "beat_brock", "Defeated Brock", 5.0),
    (0x098, "cerulean_rival", "Defeated the Cerulean rival", 2.0),
    (0x0A7, "cerulean_rocket_thief", "Defeated the Cerulean Rocket thief", 2.0),
    (0x0BF, "beat_misty", "Defeated Misty", 5.0),
    (0x0C0, "got_bicycle", "Obtained the Bicycle", 1.0),
    (0x0EF, "pokemon_tower_rival", "Defeated the Pokémon Tower rival", 2.0),
    (0x10F, "ghost_marowak", "Defeated the ghost Marowak", 2.5),
    (0x117, "rescued_mr_fuji_tower", "Rescued Mr. Fuji from Pokémon Tower", 4.0),
    (0x128, "got_poke_flute", "Obtained the Poké Flute", 3.0),
    (0x151, "got_bike_voucher", "Obtained the Bike Voucher", 1.0),
    (0x167, "beat_lt_surge", "Defeated Lt. Surge", 5.0),
    (0x1A9, "beat_erika", "Defeated Erika", 5.0),
    (0x1B9, "found_rocket_hideout", "Found the Rocket Hideout", 1.5),
    (0x238, "got_strength_hm04", "Obtained HM04 Strength", 1.5),
    (0x239, "gave_gold_teeth", "Returned the Gold Teeth", 1.0),
    (0x259, "beat_koga", "Defeated Koga", 5.0),
    (0x299, "beat_blaine", "Defeated Blaine", 5.0),
    (0x2E0, "gave_fossil_to_lab", "Gave the fossil to the Cinnabar lab", 3.0),
    (0x350, "defeated_fighting_dojo", "Defeated the Fighting Dojo", 1.5),
    (0x351, "beat_karate_master", "Defeated the Karate Master", 1.0),
    (0x361, "beat_sabrina", "Defeated Sabrina", 5.0),
    (0x3D8, "got_hm05_flash", "Obtained HM05 Flash", 1.5),
    (0x469, "beat_zapdos", "Defeated Zapdos", 3.0),
    (0x48E, "started_route12_snorlax", "Started the Route 12 Snorlax encounter", 0.5),
    (0x48F, "beat_route12_snorlax", "Defeated the Route 12 Snorlax", 2.5),
    (0x4C8, "started_route16_snorlax", "Started the Route 16 Snorlax encounter", 0.5),
    (0x4C9, "beat_route16_snorlax", "Defeated the Route 16 Snorlax", 2.5),
    (0x4CF, "got_hm02_fly", "Obtained HM02 Fly", 2.0),
    (0x4D0, "rescued_mr_fuji", "Rescued Mr. Fuji", 3.0),
    (0x520, "route22_first_rival_battle_started", "Started the first Route 22 rival battle", 0.5),
    (0x521, "route22_second_rival_battle_started", "Started the second Route 22 rival battle", 0.5),
    (0x525, "route22_first_rival_battle_won", "Won the first Route 22 rival battle", 4.0),
    (0x526, "route22_second_rival_battle_won", "Won the second Route 22 rival battle", 4.0),
    (0x527, "route22_rival_wants_battle", "Route 22 rival challenged the player", 0.25),
    (0x53E, "beat_moltres", "Defeated Moltres", 2.0),
    (0x540, "got_nugget", "Obtained the Nugget", 0.75),
    (0x541, "beat_route24_rocket", "Defeated the Route 24 Rocket", 0.75),
    (0x550, "met_bill", "Met Bill", 1.0),
    (0x55B, "used_cell_separator_on_bill", "Used the Cell Separator on Bill", 0.5),
    (0x55C, "got_ss_ticket", "Obtained the S.S. Ticket", 2.0),
    (0x55D, "met_bill_again", "Spoke to Bill after the Cell Separator", 0.5),
    (0x55E, "bill_said_use_cell_separator", "Finished Bill's Cell Separator dialogue", 0.25),
    (0x55F, "finished_bill_house", "Finished helping Bill and left his house", 1.5),
    (0x562, "viridian_forest_trainer_0", "Defeated Viridian Forest trainer 0", 0.5),
    (0x563, "viridian_forest_trainer_1", "Defeated Viridian Forest trainer 1", 0.75),
    (0x564, "viridian_forest_trainer_2", "Defeated Viridian Forest trainer 2", 0.75),
    (0x571, "mt_moon_1f_trainer_0", "Defeated Mt. Moon 1F trainer 0", 0.5),
    (0x572, "mt_moon_1f_trainer_1", "Defeated Mt. Moon 1F trainer 1", 0.5),
    (0x573, "mt_moon_1f_trainer_2", "Defeated Mt. Moon 1F trainer 2", 0.5),
    (0x574, "mt_moon_1f_trainer_3", "Defeated Mt. Moon 1F trainer 3", 0.5),
    (0x575, "mt_moon_1f_trainer_4", "Defeated Mt. Moon 1F trainer 4", 0.5),
    (0x576, "mt_moon_1f_trainer_5", "Defeated Mt. Moon 1F trainer 5", 0.5),
    (0x577, "mt_moon_1f_trainer_6", "Defeated Mt. Moon 1F trainer 6", 0.5),
    (0x579, "mt_moon_exit_super_nerd", "Defeated the Mt. Moon exit Super Nerd", 6.0),
    (0x57A, "mt_moon_b2f_rocket_0", "Defeated Mt. Moon B2F Rocket 0", 0.75),
    (0x57B, "mt_moon_b2f_rocket_1", "Defeated Mt. Moon B2F Rocket 1", 0.75),
    (0x57C, "mt_moon_b2f_rocket_2", "Defeated Mt. Moon B2F Rocket 2", 0.75),
    (0x57D, "mt_moon_b2f_rocket_3", "Defeated Mt. Moon B2F Rocket 3", 0.75),
    (0x57E, "got_dome_fossil", "Obtained the Dome Fossil", 12.0),
    (0x57F, "got_helix_fossil", "Obtained the Helix Fossil", 12.0),
    (0x5E0, "got_hm01_cut", "Obtained HM01 Cut", 1.5),
    (0x5E1, "rubbed_captains_back", "Helped the S.S. Anne captain", 0.75),
    (0x5E2, "ss_anne_left", "The S.S. Anne departed", 2.0),
    (0x677, "entered_rocket_hideout", "Entered the Rocket Hideout", 1.0),
    (0x6A6, "got_rocket_lift_key", "Obtained the Rocket Hideout Lift Key", 3.0),
    (0x6A7, "beat_rocket_hideout_giovanni", "Defeated Giovanni in the Rocket Hideout", 5.0),
    (0x78D, "got_master_ball", "Obtained the Master Ball", 2.0),
    (0x78F, "beat_silph_co_giovanni", "Defeated Giovanni in Silph Co.", 5.0),
    (0x880, "got_hm03_surf", "Obtained HM03 Surf", 2.0),
    (0x8C1, "beat_mewtwo", "Defeated Mewtwo", 3.0),
    (0x8FE, "beat_lance", "Defeated Lance", 6.0),
    (0x901, "beat_champion_rival", "Defeated the Champion rival", 10.0),
)

class RedGymEnv(Env):
    def __init__(self, config=None):
        self.s_path = config["session_path"]
        self.save_final_state = config["save_final_state"]
        self.print_rewards = config["print_rewards"]
        self.headless = config["headless"]
        self.init_state = config["init_state"]
        if isinstance(self.init_state, (str, Path)):
            self.init_states = [Path(self.init_state)]
        else:
            self.init_states = [Path(state) for state in self.init_state]
        if not self.init_states:
            raise ValueError("config['init_state'] must contain at least one save-state path")
        self.act_freq = config["action_freq"]
        self.max_steps = config["max_steps"]
        self.save_video = config["save_video"]
        self.fast_video = config["fast_video"]
        self.frame_stacks = 3
        self.explore_weight = (
            1 if "explore_weight" not in config else config["explore_weight"]
        )
        # Reward for reaching the next important story map. This setting was
        # already present in the original environment but was never used.
        self.map_progress_weight = float(config.get("map_progress_weight", 5.0))
        # A small shaping penalty encourages the agent to leave tiles where it
        # has been looping for a long time.
        self.stuck_penalty_weight = float(config.get("stuck_penalty_weight", 1.0))
        self.new_map_weight = float(config.get("new_map_weight", 0.5))
        self.reward_scale = (
            1 if "reward_scale" not in config else config["reward_scale"]
        )
        self.instance_id = (
            str(uuid.uuid4())[:8]
            if "instance_id" not in config
            else config["instance_id"]
        )
        self.s_path.mkdir(exist_ok=True)
        self.full_frame_writer = None
        self.model_frame_writer = None
        self.map_frame_writer = None
        self.reset_count = 0
        self.all_runs = []

        # Preserve the original curated early-game route ordering. Beyond this
        # known sequence, the distinct-map reward still recognises new areas;
        # later story objectives are rewarded from confirmed event constants.
        self.essential_map_locations = {
            v: i for i, v in enumerate([
                40, 0, 12, 1, 13, 51, 2, 54, 14, 59, 60, 61, 15, 3, 65
            ])
        }

        # Event constants are the source of truth. In particular, the user's
        # D74B-0 / D74B-2 / D74B-5 flags correspond to event IDs $20 / $22 / $25.
        # RAM event bits are LSB-first; observations below remain MSB-first.
        self.story_milestones = {
            event_id: (slug, name, float(weight))
            for event_id, slug, name, weight in STORY_MILESTONE_DEFS
        }
        self.mt_moon_1f_trainer_ids = tuple(range(0x571, 0x578))
        self.mt_moon_b2f_rocket_ids = tuple(range(0x57A, 0x57E))
        self.mt_moon_trainer_ids = (
            self.mt_moon_1f_trainer_ids + self.mt_moon_b2f_rocket_ids
        )
        # These are the player's exact approach tiles used by the original
        # MtMoonB2F script when it moves the Super Nerd away from a fossil.
        self.mt_moon_dome_approach_tiles = ((12, 7), (11, 6), (12, 5))
        self.mt_moon_helix_approach_tiles = ((13, 7), (14, 6), (14, 5))
        self.mt_moon_fossil_approach_tiles = (
            self.mt_moon_dome_approach_tiles + self.mt_moon_helix_approach_tiles
        )

        # Set this in SOME subclasses
        self.metadata = {"render.modes": []}
        # This environment has both positive shaping rewards and a stuck penalty.
        self.reward_range = (-np.inf, np.inf)

        self.valid_actions = [
            WindowEvent.PRESS_ARROW_DOWN,
            WindowEvent.PRESS_ARROW_LEFT,
            WindowEvent.PRESS_ARROW_RIGHT,
            WindowEvent.PRESS_ARROW_UP,
            WindowEvent.PRESS_BUTTON_A,
            WindowEvent.PRESS_BUTTON_B,
            WindowEvent.PRESS_BUTTON_START,
        ]

        self.release_actions = [
            WindowEvent.RELEASE_ARROW_DOWN,
            WindowEvent.RELEASE_ARROW_LEFT,
            WindowEvent.RELEASE_ARROW_RIGHT,
            WindowEvent.RELEASE_ARROW_UP,
            WindowEvent.RELEASE_BUTTON_A,
            WindowEvent.RELEASE_BUTTON_B,
            WindowEvent.RELEASE_BUTTON_START
        ]

        self.output_shape = (72, 80, self.frame_stacks)
        self.coords_pad = 12

        # Set these in ALL subclasses
        self.action_space = spaces.Discrete(len(self.valid_actions))
        
        self.enc_freqs = 8

        observation_spaces = {
            "screens": spaces.Box(low=0, high=255, shape=self.output_shape, dtype=np.uint8),
            # Preserve the original checkpoint's scalar Box definition.
            # The old code declared Box(low=0, high=1) with shape=(),
            # even though it returned a one-element array. Returning a scalar
            # here makes observations valid without changing the policy's
            # flattened input width (still one feature).
            "health": spaces.Box(low=0.0, high=1.0, dtype=np.float32),
            "level": spaces.Box(
                low=-1.0, high=1.0,
                shape=(self.enc_freqs,), dtype=np.float32
            ),
            "badges": spaces.MultiBinary(8),
            "events": spaces.MultiBinary((event_flags_end - event_flags_start) * 8),
            "map": spaces.Box(low=0, high=255, shape=(
                self.coords_pad*4,self.coords_pad*4, 1), dtype=np.uint8),
            "recent_actions": spaces.MultiDiscrete([len(self.valid_actions)] * self.frame_stacks)
        }
        self.observation_space = spaces.Dict(observation_spaces)

        head = "null" if config["headless"] else "SDL2"

        #log_level("ERROR")
        self.pyboy = PyBoy(
            config["gb_path"],
            #debugging=False,
            #disable_input=False,
            window=head,
        )

        #self.screen = self.pyboy.botsupport_manager().screen()

        if not config["headless"]:
            self.pyboy.set_emulation_speed(6)

    def reset(self, seed=None, options=None):
        # Gymnasium uses this to initialize its RNG and keep reset API compliant.
        super().reset(seed=seed)
        options = options or {}
        # Training samples start states from the seeded RNG. The explicit
        # index option is provided for smoke tests so every configured state
        # can be tested deterministically once.
        if "start_state_index" in options:
            state_index = int(options["start_state_index"])
            if not 0 <= state_index < len(self.init_states):
                raise IndexError(
                    f"start_state_index {state_index} is outside "
                    f"0..{len(self.init_states) - 1}"
                )
        else:
            state_index = int(self.np_random.integers(len(self.init_states)))
        start_state = self.init_states[state_index]
        self.current_start_state = start_state
        with start_state.open("rb") as f:
            self.pyboy.load_state(f)

        self.init_map_mem()

        # Keep only the latest snapshot; callbacks generally consume stats[-1].
        self.agent_stats = []
        self.visited_maps = set()
        self._hp_fraction_cache = None

        self.explore_map_dim = GLOBAL_MAP_SHAPE
        self.explore_map = np.zeros(self.explore_map_dim, dtype=np.uint8)

        self.recent_screens = np.zeros( self.output_shape, dtype=np.uint8)
        
        self.recent_actions = np.zeros((self.frame_stacks,), dtype=np.uint8)

        self.levels_satisfied = False
        self.base_explore = 0
        self.max_opponent_level = 0
        self.max_event_rew = 0
        self.max_level_rew = 0
        self.last_health = 1
        self.total_healing_rew = 0
        self.died_count = 0
        self.party_size = 0
        self.step_count = 0

        # Read event memory once. The same cached bytes are used by the reward
        # calculation and observation, avoiding two full RAM scans per step.
        self.refresh_event_cache()
        initial_event_count = int(np.unpackbits(self._event_cache).sum())
        museum_ticket_offset = museum_ticket[0] - event_flags_start
        museum_ticket_set = (int(self._event_cache[museum_ticket_offset]) >> museum_ticket[1]) & 1
        # Keep the museum ticket excluded from both sides of the differential.
        self.base_event_flags = initial_event_count - museum_ticket_set
        # Milestones already set in init_state are part of the starting state,
        # not new achievements for this episode.
        self.base_story_milestone_score = self.get_story_milestone_score()

        # Establish HP/party baselines from the loaded save state, not placeholder
        # values. This makes healing detection correct from the first action and
        # for later milestone save-state starts.
        self.last_health = self.read_hp_fraction(refresh=True)
        self.party_size = self.read_m(0xD163)

        self.out_of_bounds_coords = 0

        # experiment! 
        # self.max_steps += 128

        self.max_map_progress = 0
        # Include the initial tile/map in the episode's baseline. This prevents
        # the first action from receiving a misleading exploration bonus.
        self.update_map_progress()
        self.update_seen_coords()
        self.update_explore_map()
        self.mt_moon_b2f_reached = False
        self.mt_moon_exit_after_fossil = False
        self.mt_moon_max_navigation_potential = 0.0
        self.update_mt_moon_progress()
        self.progress_reward = self.get_game_state_reward()
        self.total_reward = sum([val for _, val in self.progress_reward.items()])
        self.reset_count += 1
        return self._get_obs(), {}

    def init_map_mem(self):
        self.seen_coords = {}

    def render(self, reduce_res=True):
        game_pixels_render = self.pyboy.screen.ndarray[:,:,0:1]  # (144, 160, 3)
        if reduce_res:
            game_pixels_render = (
                downscale_local_mean(game_pixels_render, (2,2,1))
            ).astype(np.uint8)
        return game_pixels_render
    
    def _get_obs(self):
        
        screen = self.render()

        self.update_recent_screens(screen)
        
        # normalize to approx 0-1
        level_sum = 0.02 * sum([
            self.read_m(a) for a in [0xD18C, 0xD1B8, 0xD1E4, 0xD210, 0xD23C, 0xD268]
        ])

        observation = {
            "screens": self.recent_screens,
            "health": np.float32(self.read_hp_fraction()),
            "level": self.fourier_encode(level_sum),
            "badges": np.array([int(bit) for bit in f"{self.read_m(0xD356):08b}"], dtype=np.int8),
            "events": np.array(self.read_event_bits(), dtype=np.int8),
            "map": self.get_explore_map()[:, :, None],
            "recent_actions": self.recent_actions
        }
        return observation

    def step(self, action):

        if self.save_video and self.step_count == 0:
            self.start_video()

        previous_event_cache = self._event_cache.copy()
        self.run_action_on_emulator(action)
        self.refresh_event_cache()

        new_story_milestones = tuple(
            slug
            for event_id, (slug, _name, _weight) in self.story_milestones.items()
            if not self._event_id_set_in_cache(previous_event_cache, event_id)
            and self.is_event_id_set(event_id)
        )

        self.update_recent_actions(action)

        self.update_seen_coords(action)

        self.update_explore_map()

        current_hp_fraction = self.read_hp_fraction(refresh=True)
        self.update_heal_reward(current_hp_fraction)

        self.party_size = self.read_m(0xD163)
        self.last_health = current_hp_fraction

        # Update progression BEFORE calculating the reward.
        self.update_map_progress()
        self.update_mt_moon_progress()

        new_reward = self.update_reward()
        # Record the post-action state and the progression values just rewarded.
        self.append_agent_stats(action)

        step_limit_reached = self.check_if_done()

        obs = self._get_obs()

        # self.save_and_print_info(step_limit_reached, obs)

        current_x, current_y, current_map = self.get_game_coords()
        fossil_obtained = self.has_mt_moon_fossil()
        mt_moon_super_nerd_defeated = self.is_event_id_set(0x579)
        mt_moon_nerd_approach = self.get_mt_moon_nerd_approach()
        mt_moon_fossil_approach = self.get_mt_moon_fossil_approach()
        info = {
            "map_progress": int(self.max_map_progress),
            "map_id": int(current_map),
            "x": int(current_x),
            "y": int(current_y),
            "in_mt_moon": int(current_map in MT_MOON_MAP_IDS),
            "mt_moon_b2f_reached": int(self.mt_moon_b2f_reached),
            "mt_moon_stage": int(self.get_mt_moon_stage()),
            "mt_moon_trainer_wins": int(sum(self.is_event_id_set(eid) for eid in self.mt_moon_trainer_ids)),
            "mt_moon_nerd_approach": float(mt_moon_nerd_approach),
            "mt_moon_fossil_approach": float(mt_moon_fossil_approach),
            "mt_moon_approach": float(mt_moon_nerd_approach if not mt_moon_super_nerd_defeated else mt_moon_fossil_approach),
            "mt_moon_super_nerd_defeated": int(mt_moon_super_nerd_defeated),
            "dome_fossil_obtained": int(self.is_event_id_set(0x57E)),
            "helix_fossil_obtained": int(self.is_event_id_set(0x57F)),
            "fossil_obtained": int(fossil_obtained),
            "mt_moon_exit_after_fossil": int(self.mt_moon_exit_after_fossil),
            "seen_tiles": int(len(self.seen_coords)),
            "visited_maps": int(len(self.visited_maps)),
            "badges": int(self.get_badges()),
            "events": int(self.get_all_events_reward()),
            "levels_sum": int(self.get_levels_sum()),
            "deaths": int(self.died_count),
            "story_milestone_count": int(self.get_active_story_milestone_count()),
            "new_story_milestone_count": len(new_story_milestones),
            "story_milestone_score": float(self.get_story_milestone_score()),
            "story_milestone_reward": float(self.progress_reward.get("story_milestone", 0.0)),
            "mt_moon_navigation_reward": float(self.progress_reward.get("mt_moon_navigation", 0.0)),
            "mt_moon_exit_reward": float(self.progress_reward.get("mt_moon_exit", 0.0)),
            "new_story_milestones": new_story_milestones,
        }

        self.step_count += 1

        return obs, new_reward, False, step_limit_reached, info
    
    def run_action_on_emulator(self, action):
        # press button then release after some steps
        self.pyboy.send_input(self.valid_actions[action])
        # disable rendering when we don't need it
        render_screen = self.save_video or not self.headless
        press_step = 8
        self.pyboy.tick(press_step, render_screen)
        self.pyboy.send_input(self.release_actions[action])
        self.pyboy.tick(self.act_freq - press_step - 1, render_screen)
        self.pyboy.tick(1, True)
        if self.save_video and self.fast_video:
            self.add_video_frame()
        
    def append_agent_stats(self, action):
        x_pos, y_pos, map_n = self.get_game_coords()
        levels = [
            self.read_m(a) for a in [0xD18C, 0xD1B8, 0xD1E4, 0xD210, 0xD23C, 0xD268]
        ]
        latest_stats = {
                "step": self.step_count,
                "x": x_pos,
                "y": y_pos,
                "map": map_n,
                "max_map_progress": self.max_map_progress,
                "map_progress_reward": self.progress_reward.get("map_progress", 0.0),
                "story_milestone_reward": self.progress_reward.get("story_milestone", 0.0),
                "last_action": action,
                "pcount": self.read_m(0xD163),
                "levels": levels,
                "levels_sum": sum(levels),
                "ptypes": self.read_party(),
                "hp": self.read_hp_fraction(),
                "coord_count": len(self.seen_coords),
                "deaths": self.died_count,
                "badge": self.get_badges(),
                "event": self.progress_reward["event"],
                "healr": self.total_healing_rew,
            }
        self.agent_stats = [latest_stats]

    def start_video(self):

        if self.full_frame_writer is not None:
            self.full_frame_writer.close()
        if self.model_frame_writer is not None:
            self.model_frame_writer.close()
        if self.map_frame_writer is not None:
            self.map_frame_writer.close()

        base_dir = self.s_path / Path("rollouts")
        base_dir.mkdir(exist_ok=True)
        full_name = Path(
            f"full_reset_{self.reset_count}_id{self.instance_id}"
        ).with_suffix(".mp4")
        model_name = Path(
            f"model_reset_{self.reset_count}_id{self.instance_id}"
        ).with_suffix(".mp4")
        self.full_frame_writer = media.VideoWriter(
            base_dir / full_name, (144, 160), fps=60, input_format="gray"
        )
        self.full_frame_writer.__enter__()
        self.model_frame_writer = media.VideoWriter(
            base_dir / model_name, self.output_shape[:2], fps=60, input_format="gray"
        )
        self.model_frame_writer.__enter__()
        map_name = Path(
            f"map_reset_{self.reset_count}_id{self.instance_id}"
        ).with_suffix(".mp4")
        self.map_frame_writer = media.VideoWriter(
            base_dir / map_name,
            (self.coords_pad*4, self.coords_pad*4), 
            fps=60, input_format="gray"
        )
        self.map_frame_writer.__enter__()

    def add_video_frame(self):
        self.full_frame_writer.add_image(
            self.render(reduce_res=False)[:,:,0]
        )
        self.model_frame_writer.add_image(
            self.render(reduce_res=True)[:,:,0]
        )
        self.map_frame_writer.add_image(
            self.get_explore_map()
        )

    def get_game_coords(self):
        return (self.read_m(0xD362), self.read_m(0xD361), self.read_m(0xD35E))

    def update_seen_coords(self, action=None):
        # Count only directional movement attempts. Button presses used for
        # menus, dialogue and object interaction must not trigger stuck cost.
        if action is not None and int(action) >= 4:
            return
        # if not in battle
        if self.read_m(0xD057) == 0:
            x_pos, y_pos, map_n = self.get_game_coords()
            coord_string = f"x:{x_pos} y:{y_pos} m:{map_n}"
            if coord_string in self.seen_coords.keys():
                self.seen_coords[coord_string] += 1
            else:
                self.seen_coords[coord_string] = 1
            #self.seen_coords[coord_string] = self.step_count

    def get_current_coord_count_reward(self):
        """Return a 0..1 penalty intensity for repeatedly staying on one tile.

        The old threshold of 600 actions was so high that it rarely helped the
        agent escape an early loop. The penalty now ramps up after 10 visits and
        reaches its cap at 50 visits. It is a state-potential term, so moving to
        a less-visited tile gives some reward back.
        """
        x_pos, y_pos, map_n = self.get_game_coords()
        coord_string = f"x:{x_pos} y:{y_pos} m:{map_n}"
        count = self.seen_coords.get(coord_string, 0)
        return float(np.clip((count - 10) / 40.0, 0.0, 1.0))

    def get_global_coords(self):
        x_pos, y_pos, map_n = self.get_game_coords()
        return local_to_global(y_pos, x_pos, map_n)

    def update_explore_map(self):
        r, c = self.get_global_coords()
        height, width = self.explore_map.shape
        if 0 <= r < height and 0 <= c < width:
            self.explore_map[r, c] = 255
        else:
            # Avoid printing on every step if a map coordinate is unmapped.
            self.out_of_bounds_coords += 1

    def get_explore_map(self):
        """Return a fixed-size, zero-padded local map around the player.

        The old NumPy slice could become smaller than 24x24 near a map edge
        (or behave unexpectedly for negative indices), violating the declared
        observation shape. This implementation always returns 48x48.
        """
        r, c = self.get_global_coords()
        height, width = self.explore_map.shape
        size = self.coords_pad * 2
        out = np.zeros((size, size), dtype=np.uint8)

        if not (0 <= r < height and 0 <= c < width):
            return out.repeat(2, axis=0).repeat(2, axis=1)

        src_r0 = max(r - self.coords_pad, 0)
        src_r1 = min(r + self.coords_pad, height)
        src_c0 = max(c - self.coords_pad, 0)
        src_c1 = min(c + self.coords_pad, width)

        dst_r0 = src_r0 - (r - self.coords_pad)
        dst_c0 = src_c0 - (c - self.coords_pad)
        out[
            dst_r0:dst_r0 + (src_r1 - src_r0),
            dst_c0:dst_c0 + (src_c1 - src_c0),
        ] = self.explore_map[src_r0:src_r1, src_c0:src_c1]

        return out.repeat(2, axis=0).repeat(2, axis=1)
    
    def update_recent_screens(self, cur_screen):
        self.recent_screens = np.roll(self.recent_screens, 1, axis=2)
        self.recent_screens[:, :, 0] = cur_screen[:,:, 0]

    def update_recent_actions(self, action):
        self.recent_actions = np.roll(self.recent_actions, 1)
        self.recent_actions[0] = action

    def update_reward(self):
        # compute reward
        self.progress_reward = self.get_game_state_reward()
        new_total = sum(
            [val for _, val in self.progress_reward.items()]
        )
        new_step = new_total - self.total_reward

        self.total_reward = new_total
        return new_step

    def group_rewards(self):
        prog = self.progress_reward
        # These values are only used by the recurrent policy's reward memory.
        scale = max(abs(self.reward_scale), 1e-8)
        explore_scale = max(abs(self.explore_weight * self.reward_scale), 1e-8)
        return (
            prog["level"] * 100 / scale,
            self.read_hp_fraction() * 2000,
            prog["explore"] * 150 / explore_scale,
        )

    def check_if_done(self):
        done = self.step_count >= self.max_steps - 1
        # done = self.read_hp_fraction() == 0 # end game on loss
        return done

    def save_and_print_info(self, done, obs):
        if self.print_rewards:
            prog_string = f"step: {self.step_count:6d}"
            for key, val in self.progress_reward.items():
                prog_string += f" {key}: {val:5.2f}"
            prog_string += f" sum: {self.total_reward:5.2f}"
            print(f"\r{prog_string}", end="", flush=True)

        if self.step_count % 50 == 0:
            plt.imsave(
                self.s_path / Path(f"curframe_{self.instance_id}.jpeg"),
                self.render(reduce_res=False)[:,:, 0],
            )

        if self.print_rewards and done:
            print("", flush=True)
            if self.save_final_state:
                fs_path = self.s_path / Path("final_states")
                fs_path.mkdir(exist_ok=True)
                plt.imsave(
                    fs_path
                    / Path(
                        f"frame_r{self.total_reward:.4f}_{self.reset_count}_explore_map.jpeg"
                    ),
                    obs["map"][:,:, 0],
                )
                plt.imsave(
                    fs_path
                    / Path(
                        f"frame_r{self.total_reward:.4f}_{self.reset_count}_full_explore_map.jpeg"
                    ),
                    self.explore_map,
                )
                plt.imsave(
                    fs_path
                    / Path(
                        f"frame_r{self.total_reward:.4f}_{self.reset_count}_full.jpeg"
                    ),
                    self.render(reduce_res=False)[:,:, 0],
                )

        if self.save_video and done:
            self.full_frame_writer.close()
            self.model_frame_writer.close()
            self.map_frame_writer.close()

    def read_m(self, addr):
        #return self.pyboy.get_memory_value(addr)
        return self.pyboy.memory[addr]

    def read_bit(self, addr, bit: int) -> bool:
        # add padding so zero will read '0b100000000' instead of '0b0'
        return bin(256 + self.read_m(addr))[-bit - 1] == "1"

    def _read_event_bytes(self):
        # PyBoy supports contiguous memory slices; this is substantially cheaper
        # than issuing one Python-level memory read per byte.
        return np.asarray(
            self.pyboy.memory[event_flags_start:event_flags_end], dtype=np.uint8
        )

    def refresh_event_cache(self):
        self._event_cache = self._read_event_bytes()
        return self._event_cache

    def read_event_bits(self):
        # np.unpackbits defaults to MSB-first, matching the original f"{value:08b}".
        if not hasattr(self, "_event_cache"):
            self.refresh_event_cache()
        return np.unpackbits(self._event_cache).astype(np.int8)

    def get_levels_sum(self):
        min_poke_level = 2
        starter_additional_levels = 4
        poke_levels = [
            max(self.read_m(a) - min_poke_level, 0)
            for a in [0xD18C, 0xD1B8, 0xD1E4, 0xD210, 0xD23C, 0xD268]
        ]
        return max(sum(poke_levels) - starter_additional_levels, 0)

    def get_levels_reward(self):
        explore_thresh = 22
        scale_factor = 4
        level_sum = self.get_levels_sum()
        if level_sum < explore_thresh:
            scaled = level_sum
        else:
            scaled = (level_sum - explore_thresh) / scale_factor + explore_thresh
        self.max_level_rew = max(self.max_level_rew, scaled)
        return self.max_level_rew

    def get_badges(self):
        return self.bit_count(self.read_m(0xD356))

    def read_party(self):
        return [
            self.read_m(addr)
            for addr in [0xD164, 0xD165, 0xD166, 0xD167, 0xD168, 0xD169]
        ]

    def _is_event_flag_set(self, address, bit_index):
        """Read an event bit using Pokémon Red's LSB-first constant numbering."""
        if not hasattr(self, "_event_cache"):
            self.refresh_event_cache()
        offset = int(address) - event_flags_start
        if offset < 0 or offset >= len(self._event_cache):
            return False
        if not 0 <= int(bit_index) <= 7:
            return False
        # Event IDs use LSB-first bit numbering (event $20 is byte offset
        # $04, bit 0 => D74B-0, matching the supplied confirmed flag mapping).
        mask = 1 << int(bit_index)
        return bool(int(self._event_cache[offset]) & mask)

    def _event_id_set_in_cache(self, cache, event_id):
        address, bit_index = event_id_to_ram_key(event_id)
        offset = address - event_flags_start
        if offset < 0 or offset >= len(cache) or not 0 <= bit_index <= 7:
            return False
        return bool(int(cache[offset]) & (1 << bit_index))

    def is_event_id_set(self, event_id):
        address, bit_index = event_id_to_ram_key(event_id)
        return self._is_event_flag_set(address, bit_index)

    def get_story_milestone_score(self):
        """Weighted sum of confirmed story flags currently set in RAM."""
        return float(sum(
            weight
            for event_id, (_slug, _name, weight) in self.story_milestones.items()
            if self.is_event_id_set(event_id)
        ))

    def get_active_story_milestones(self):
        """Readable names of the confirmed story flags currently set."""
        return [
            name
            for event_id, (_slug, name, _weight) in self.story_milestones.items()
            if self.is_event_id_set(event_id)
        ]

    def get_active_story_milestone_count(self):
        return sum(self.is_event_id_set(event_id) for event_id in self.story_milestones)

    def has_mt_moon_fossil(self):
        return self.is_event_id_set(0x57E) or self.is_event_id_set(0x57F)

    def get_mt_moon_nerd_approach(self):
        """0..1 proximity to the exact B2F trigger tile (13, 8)."""
        if int(self.read_m(0xD35E)) != MT_MOON_B2F_MAP_ID:
            return 0.0
        if self.is_event_id_set(0x579):
            return 0.0
        x_pos, y_pos, _map = self.get_game_coords()
        distance = abs(int(x_pos) - 13) + abs(int(y_pos) - 8)
        return float(np.clip(1.0 - distance / 24.0, 0.0, 1.0))

    def get_mt_moon_fossil_approach(self):
        """0..1 proximity to a player tile scripted adjacent to either fossil."""
        if int(self.read_m(0xD35E)) != MT_MOON_B2F_MAP_ID:
            return 0.0
        if not self.is_event_id_set(0x579) or self.has_mt_moon_fossil():
            return 0.0
        x_pos, y_pos, _map = self.get_game_coords()
        distance = min(
            abs(int(x_pos) - tx) + abs(int(y_pos) - ty)
            for tx, ty in self.mt_moon_fossil_approach_tiles
        )
        return float(np.clip(1.0 - distance / 16.0, 0.0, 1.0))

    def get_mt_moon_navigation_potential(self):
        """Monotonic stage-aware shaping potential for the Mt. Moon objective."""
        current_map = int(self.read_m(0xD35E))
        if current_map != MT_MOON_B2F_MAP_ID:
            return 0.0
        if self.has_mt_moon_fossil():
            return 2.0
        if self.is_event_id_set(0x579):
            # One point for beating the Super Nerd, then approach the adjacent
            # tiles that trigger his scripted movement away from the fossil.
            return 1.0 + self.get_mt_moon_fossil_approach()
        return self.get_mt_moon_nerd_approach()

    def update_mt_moon_progress(self):
        """Track Mt. Moon state transitions without changing policy observations."""
        current_map = int(self.read_m(0xD35E))
        # Also infer that B2F was reached when resuming from a later save
        # state where the Super Nerd/fossil event is already set.
        if (
            current_map == MT_MOON_B2F_MAP_ID
            or self.is_event_id_set(0x579)
            or self.has_mt_moon_fossil()
        ):
            self.mt_moon_b2f_reached = True
        if (
            self.has_mt_moon_fossil()
            and self.mt_moon_b2f_reached
            and current_map not in MT_MOON_MAP_IDS
        ):
            self.mt_moon_exit_after_fossil = True
        self.mt_moon_max_navigation_potential = max(
            self.mt_moon_max_navigation_potential,
            self.get_mt_moon_navigation_potential(),
        )

    def get_mt_moon_stage(self):
        current_map = int(self.read_m(0xD35E))
        in_mt_moon = current_map in MT_MOON_MAP_IDS
        if self.mt_moon_exit_after_fossil:
            return 5
        if self.has_mt_moon_fossil():
            return 4 if in_mt_moon else 5
        if self.is_event_id_set(0x579):
            return 3
        if self.mt_moon_b2f_reached:
            return 2
        if in_mt_moon:
            return 1
        return 0

    def get_all_events_reward(self):
        # Count cached event flags and exclude the museum ticket as before.
        if not hasattr(self, "_event_cache"):
            self.refresh_event_cache()
        event_count = int(np.unpackbits(self._event_cache).sum())
        ticket_offset = museum_ticket[0] - event_flags_start
        ticket_set = (int(self._event_cache[ticket_offset]) >> museum_ticket[1]) & 1
        return max((event_count - ticket_set) - self.base_event_flags, 0)

    def get_game_state_reward(self, print_stats=False):
        # addresses from https://datacrystal.romhacking.net/wiki/Pok%C3%A9mon_Red/Blue:RAM_map
        # https://github.com/pret/pokered/blob/91dc3c9f9c8fd529bb6e8307b58b96efa0bec67e/constants/event_constants.asm
        state_scores = {
            "event": self.reward_scale * self.update_max_event_rew() * 4,
            "level": self.reward_scale * self.get_levels_reward() * 0.5,
            "heal": self.reward_scale * min(self.total_healing_rew, 0.5) * 10,
            #"op_lvl": self.reward_scale * self.update_max_op_level() * 0.2,
            #"dead": self.reward_scale * self.died_count * -0.1,
            "badge": self.reward_scale * self.get_badges() * 10,
            # Important story-map milestones. This uses the config value that
            # existed in the original file but was not connected to rewards.
            "map_progress": (
                self.reward_scale * self.map_progress_weight * self.max_map_progress
            ),
            # Small one-time bonus for each distinct map, including maps beyond
            # the hand-authored essential-map progression list.
            "new_maps": self.reward_scale * self.new_map_weight * len(self.visited_maps),
            # Extra shaping for meaningful story events. This is cumulative
            # potential; subtracting the init_state baseline below prevents
            # rewards for milestones that were already complete at reset.
            "story_milestone": (
                self.reward_scale * max(
                    self.get_story_milestone_score() - self.base_story_milestone_score,
                    0.0,
                ) * 2.0
            ),
            # Stage-aware shaping helps with the cave's scripted sequence while
            # remaining reward-only compatible with the current PPO policy.
            "mt_moon_navigation": (
                self.reward_scale * 2.0 * self.mt_moon_max_navigation_potential
            ),
            "mt_moon_exit": (
                self.reward_scale * 2.0 * float(self.mt_moon_exit_after_fossil)
            ),
            "explore": self.reward_scale * self.explore_weight * len(self.seen_coords) * 0.1,
            "stuck": (
                -self.reward_scale * self.stuck_penalty_weight
                * self.get_current_coord_count_reward()
            ),
        }

        return state_scores

    def update_max_op_level(self):
        opp_base_level = 5
        opponent_level = (
            max([
                self.read_m(a)
                for a in [0xD8C5, 0xD8F1, 0xD91D, 0xD949, 0xD975, 0xD9A1]
            ])
            - opp_base_level
        )
        self.max_opponent_level = max(self.max_opponent_level, opponent_level)
        return self.max_opponent_level

    def update_max_event_rew(self):
        cur_rew = self.get_all_events_reward()
        self.max_event_rew = max(cur_rew, self.max_event_rew)
        return self.max_event_rew

    def update_heal_reward(self, cur_health=None):
        if cur_health is None:
            cur_health = self.read_hp_fraction(refresh=True)
        # if health increased and party size did not change
        if cur_health > self.last_health and self.read_m(0xD163) == self.party_size:
            if self.last_health > 0:
                heal_amount = cur_health - self.last_health
                self.total_healing_rew += heal_amount * heal_amount
            else:
                self.died_count += 1

    def read_hp_fraction(self, refresh=False):
        if not refresh and self._hp_fraction_cache is not None:
            return self._hp_fraction_cache
        hp_sum = sum([
            self.read_hp(add)
            for add in [0xD16C, 0xD198, 0xD1C4, 0xD1F0, 0xD21C, 0xD248]
        ])
        max_hp_sum = sum([
            self.read_hp(add)
            for add in [0xD18D, 0xD1B9, 0xD1E5, 0xD211, 0xD23D, 0xD269]
        ])
        max_hp_sum = max(max_hp_sum, 1)
        self._hp_fraction_cache = float(hp_sum / max_hp_sum)
        return self._hp_fraction_cache

    def read_hp(self, start):
        return 256 * self.read_m(start) + self.read_m(start + 1)

    # built-in since python 3.10
    def bit_count(self, bits):
        return bin(bits).count("1")
    
    def fourier_encode(self, val):
        return np.sin(val * 2 ** np.arange(self.enc_freqs)).astype(np.float32)
    
    def update_map_progress(self):
        map_idx = int(self.read_m(0xD35E))
        self.visited_maps.add(map_idx)
        self.max_map_progress = max(self.max_map_progress, self.get_map_progress(map_idx))
    
    def get_map_progress(self, map_idx):
        if map_idx in self.essential_map_locations.keys():
            return self.essential_map_locations[map_idx]
        else:
            return -1

    def close(self):
        """Close any open video writers and stop the emulator cleanly."""
        for writer_name in ("full_frame_writer", "model_frame_writer", "map_frame_writer"):
            writer = getattr(self, writer_name, None)
            if writer is not None:
                try:
                    writer.close()
                finally:
                    setattr(self, writer_name, None)

        stop = getattr(self.pyboy, "stop", None)
        if callable(stop):
            stop()
