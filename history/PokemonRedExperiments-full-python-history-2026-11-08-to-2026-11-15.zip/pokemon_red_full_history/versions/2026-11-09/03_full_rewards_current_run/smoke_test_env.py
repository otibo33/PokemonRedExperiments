#!/usr/bin/env python3
"""Local smoke test for RedGymEnv using the real ROM and PyBoy installation.

Run from the same project directory as red_gym_env_v2.py and global_map.py:
    python smoke_test_env.py --gb-path ../PokemonRed.gb --init-state ../init.state

Pass --init-state repeatedly to test multiple states. Example:
    python smoke_test_env.py --gb-path ../PokemonRed.gb \
      --init-state states/pallet.state --init-state states/after_brock.state
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from red_gym_env_v2 import RedGymEnv


def parse_args():
    parser = argparse.ArgumentParser(
        description="Smoke-test the legacy/checkpoint-compatible RedGymEnv"
    )
    parser.add_argument("--gb-path", default="../PokemonRed.gb")
    parser.add_argument("--init-state", action="append", dest="init_states")
    parser.add_argument("--steps", type=int, default=500)
    parser.add_argument("--seed", type=int, default=1)
    return parser.parse_args()


def main():
    args = parse_args()
    if args.steps < 1:
        raise ValueError("--steps must be at least 1")
    init_states = args.init_states or ["../init.state"]

    config = {
        "headless": True,
        "save_final_state": False,
        "print_rewards": False,
        "init_state": init_states if len(init_states) > 1 else init_states[0],
        "action_freq": 24,
        "max_steps": max(args.steps + 1, 2),
        "save_video": False,
        "fast_video": True,
        "session_path": Path("smoke_test_output"),
        "gb_path": args.gb_path,
        "reward_scale": 0.5,
        "explore_weight": 0.25,
        "map_progress_weight": 5.0,
    }

    env = RedGymEnv(config)
    try:
        for state_index, state_path in enumerate(init_states):
            obs, reset_info = env.reset(
                seed=args.seed + state_index,
                options={"start_state_index": state_index},
            )
            assert env.observation_space.contains(obs), (
                f"observation space mismatch immediately after reset: {state_path}"
            )

            first_reward = None
            last_info = {}
            for step_index in range(args.steps):
                action = env.action_space.sample()
                obs, reward, terminated, truncated, info = env.step(action)
                if first_reward is None:
                    first_reward = float(reward)
                assert env.observation_space.contains(obs), (
                    f"observation space mismatch after step {step_index + 1} "
                    f"for state {state_path}"
                )
                assert np.isfinite(reward), (
                    f"non-finite reward {reward!r} after step {step_index + 1}"
                )
                last_info = info
                if terminated or truncated:
                    break

            print({
                "state": str(state_path),
                "steps_tested": step_index + 1,
                "first_step_reward": first_reward,
                "final_info": last_info,
            })

        print("Smoke test passed: observations match the declared spaces and rewards are finite.")
    finally:
        env.close()


if __name__ == "__main__":
    main()
