# Safe TensorBoard screenshot update for Pokémon Red v2

This update is based on the user's existing working `TensorboardCallback`.
It preserves:
- the public class name `TensorboardCallback`
- the original constructor usage `TensorboardCallback(log_dir)`
- episode-end `env_stats` and histogram logging
- `trajectory/explore_sum`, `trajectory/explore_map`, and `trajectory/all_flags`
- the `SummaryWriter` histogram lifecycle

It adds optional high-resolution RGB gameplay screenshots under the tag
`gameplay/screen_4x_rgb`. Screenshot failures are caught and warned once;
they do not interrupt the original statistics callback.

## Install safely

1. In the `v2` project directory, back up your currently working callback:

   ```fish
   cp tensorboard_callback.py tensorboard_callback.py.backup
   ```

2. Replace `tensorboard_callback.py` with the supplied file of the same name.

3. Ensure `red_gym_env_v2.py` contains the method `get_tensorboard_frame(scale=4)`.
   The supplied environment file includes this method. It does not alter the
   model's existing 72x80 grayscale observations; it only exposes a separate
   full-colour 160x144 screen enlarged to 640x576 for logging.

4. Keep your training import unchanged:

   ```python
   from tensorboard_callback import TensorboardCallback
   ```

5. Your existing callback construction remains valid:

   ```python
   TensorboardCallback(log_dir)
   ```

   Optional arguments, only if needed:

   ```python
   TensorboardCallback(log_dir, image_log_freq=2000, image_scale=4)
   ```

   `image_log_freq` is in callback calls. Set it to `None` to disable only the
   new gameplay screenshots while leaving all original logs active.

## Verify before training

```fish
python -c "from tensorboard_callback import TensorboardCallback; print('TensorboardCallback import OK')"
python -c "from red_gym_env_v2 import RedGymEnv; print('RedGymEnv import OK')"
```

The Python files were syntax-checked when this package was prepared. Full
runtime verification requires the project's installed dependencies and ROM.
