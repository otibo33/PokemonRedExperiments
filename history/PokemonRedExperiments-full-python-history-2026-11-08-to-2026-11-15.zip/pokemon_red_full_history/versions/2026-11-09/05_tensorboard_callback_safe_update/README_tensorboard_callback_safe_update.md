# Safe TensorBoard callback update

This is a drop-in update for the user's existing `tensorboard_callback.py`.
It preserves the original `TensorboardCallback` class name and its existing
statistics, histograms, explore-map images, event flag logging, and SummaryWriter
lifecycle. High-resolution gameplay image logging is additive and guarded: if
image capture fails, a warning is emitted once and the existing callback keeps
running.

## Install

1. Back up the working file:

   ```fish
   cp tensorboard_callback.py tensorboard_callback.py.backup
   ```

2. Copy the supplied `tensorboard_callback.py` over the existing file in:

   `~/Projects/PokemonRedExperiments/v2/`

3. Keep your training script unchanged. Its existing import remains valid:

   ```python
   from tensorboard_callback import TensorboardCallback
   ```

4. Keep the environment method `get_tensorboard_frame(scale=4)` in
   `red_gym_env_v2.py` for full-colour images. The previously supplied updated
   environment file contains this method. If the method is missing, the callback
   falls back to `render(False)` and logs an enlarged grayscale screenshot
   instead; it does not abort training.

## Existing constructor remains valid

```python
TensorboardCallback(log_dir)
TensorboardCallback(log_dir, verbose=1)
```

Optional settings can be supplied without changing the training script's
current call:

```python
TensorboardCallback(
    log_dir,
    image_log_freq=2000,  # callback calls, not raw emulator frames
    image_scale=4,        # 160x144 becomes 640x576
    image_env_index=0,    # first vector-env worker
)
```

Set `image_log_freq=None` to disable only gameplay image logging.

## Image tag

TensorBoard image tag: `gameplay/screen_4x_rgb`.
