# TensorBoard callback: enlarged exploration maps only

This version deliberately does **not** log gameplay screenshots.

It preserves the callback's original logging:

- `env_stats/*` mean values
- `env_stats_max/*` maxima
- `env_stats_distribs/*` histograms
- `trajectory/explore_sum`
- `trajectory/explore_map`
- `trajectory/all_flags`

The only visual change is that `trajectory/explore_sum` and
`trajectory/explore_map` are enlarged by 2x in both dimensions using
nearest-neighbour pixel replication. This keeps tile boundaries sharp and
changes only the images recorded to TensorBoard. It does not change the
underlying exploration maps, observations, rewards, or PPO behaviour.

## Install

From the v2 project directory, back up the current callback:

```fish
cp tensorboard_callback.py tensorboard_callback.py.backup
```

Replace it with the supplied `tensorboard_callback.py`.

Your existing import and constructor call stay the same:

```python
from tensorboard_callback import TensorboardCallback

# Existing call remains valid:
TensorboardCallback(log_dir)
```

Optional scaling:

```python
TensorboardCallback(log_dir, map_image_scale=2)
```

Set `map_image_scale=3` or `4` for larger map panels. Larger scales increase
TensorBoard event-file size and memory use.
