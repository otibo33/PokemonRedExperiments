"""Existing Pokémon Red TensorBoard callback with optional high-res screenshots.

This keeps the original TensorboardCallback name, constructor compatibility,
episode statistics, histograms, explore-map images, event flags, and SummaryWriter
lifecycle. Gameplay screenshots are an additive feature and fail safely: a
screenshot problem will not stop the existing statistics callback or training.
"""

import os
import json
import warnings

from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.logger import Image
from torch.utils.tensorboard import SummaryWriter
import numpy as np
from einops import rearrange, reduce


def merge_dicts(dicts):
    sum_dict = {}
    count_dict = {}
    distrib_dict = {}

    for d in dicts:
        for k, v in d.items():
            if isinstance(v, (int, float)):
                sum_dict[k] = sum_dict.get(k, 0) + v
                count_dict[k] = count_dict.get(k, 0) + 1
                distrib_dict.setdefault(k, []).append(v)

    mean_dict = {}
    for k in sum_dict:
        mean_dict[k] = sum_dict[k] / count_dict[k]
        distrib_dict[k] = np.array(distrib_dict[k])

    return mean_dict, distrib_dict


class TensorboardCallback(BaseCallback):
    """Preserve the original metrics callback and optionally log game images.

    Existing usage remains valid:
        TensorboardCallback(log_dir)
        TensorboardCallback(log_dir, verbose=1)

    Optional image settings:
        image_log_freq=2000  # callback calls between images; None disables
        image_scale=4        # native 160x144 -> 640x576
        image_env_index=0    # capture the first vector-env worker
    """

    def __init__(
        self,
        log_dir,
        verbose=0,
        image_log_freq=2000,
        image_scale=4,
        image_env_index=0,
        map_image_scale=2,
    ):
        super().__init__(verbose)
        self.log_dir = log_dir
        self.writer = None

        if image_log_freq is not None and int(image_log_freq) < 1:
            raise ValueError("image_log_freq must be a positive integer or None")
        if int(image_scale) < 1:
            raise ValueError("image_scale must be a positive integer")
        if int(image_env_index) < 0:
            raise ValueError("image_env_index must be >= 0")
        if int(map_image_scale) < 1:
            raise ValueError("map_image_scale must be a positive integer")

        self.image_log_freq = (
            None if image_log_freq is None else int(image_log_freq)
        )
        self.image_scale = int(image_scale)
        self.image_env_index = int(image_env_index)
        # Exploration maps are raster maps (not camera frames). Nearest-neighbour
        # enlargement makes each visited tile easier to inspect without changing
        # the underlying map, reward, or policy observation.
        self.map_image_scale = int(map_image_scale)
        self._image_warning_emitted = False

    def _on_training_start(self):
        if self.writer is None:
            self.writer = SummaryWriter(log_dir=os.path.join(self.log_dir, 'histogram'))

    def _warn_image_once(self, message):
        if not self._image_warning_emitted:
            warnings.warn(
                message + " Existing TensorBoard statistics will continue normally.",
                RuntimeWarning,
            )
            self._image_warning_emitted = True

    def _get_gameplay_frame(self):
        """Fetch an RGB screenshot; fall back to the original full-size render."""
        frames = self.training_env.env_method(
            "get_tensorboard_frame",
            self.image_scale,
            indices=[self.image_env_index],
        )
        if not frames:
            raise RuntimeError("The selected environment returned no gameplay frame")

        frame = np.asarray(frames[0])
        if frame.ndim == 2:
            frame = np.repeat(frame[:, :, None], 3, axis=2)
        elif frame.ndim == 3 and frame.shape[2] == 1:
            frame = np.repeat(frame, 3, axis=2)
        elif frame.ndim == 3 and frame.shape[2] >= 3:
            frame = frame[:, :, :3]
        else:
            raise ValueError(f"Unexpected gameplay frame shape: {frame.shape}")

        if frame.dtype != np.uint8:
            frame = np.clip(frame, 0, 255).astype(np.uint8)
        return np.ascontiguousarray(frame)

    def _log_gameplay_image(self):
        """Log one enlarged RGB frame without interfering with other metrics."""
        if self.image_log_freq is None or self.n_calls % self.image_log_freq != 0:
            return

        try:
            frame = self._get_gameplay_frame()
            self.logger.record(
                "gameplay/screen_4x_rgb",
                Image(frame, "HWC"),
                exclude=("stdout", "log", "json", "csv"),
            )
        except Exception as exc:
            # Older environment copies may not yet have get_tensorboard_frame().
            # Try the existing full-resolution grayscale render as a fallback.
            try:
                fallback = self.training_env.env_method(
                    "render", False, indices=[self.image_env_index]
                )
                if not fallback:
                    raise RuntimeError("The selected environment returned no frame")
                frame = np.asarray(fallback[0])
                if frame.ndim == 3 and frame.shape[2] == 1:
                    frame = frame[:, :, 0]
                if frame.ndim != 2:
                    raise ValueError(f"Unexpected fallback render shape: {frame.shape}")
                frame = np.repeat(frame[:, :, None], 3, axis=2)
                frame = np.repeat(
                    np.repeat(frame, self.image_scale, axis=0),
                    self.image_scale,
                    axis=1,
                ).astype(np.uint8, copy=False)
                self.logger.record(
                    "gameplay/screen_4x_rgb",
                    Image(np.ascontiguousarray(frame), "HWC"),
                    exclude=("stdout", "log", "json", "csv"),
                )
                self._warn_image_once(
                    "Could not use get_tensorboard_frame(); logged the existing "
                    "full-resolution grayscale render instead. Add "
                    "get_tensorboard_frame(scale=4) to RedGymEnv for RGB images."
                )
            except Exception as fallback_exc:
                self._warn_image_once(
                    "Could not log a gameplay image. Original error: "
                    f"{exc!r}; fallback error: {fallback_exc!r}."
                )

    def _on_step(self) -> bool:
        # Image logging is independent of episode-end statistics and is guarded
        # so it cannot break the established callback if capture is unavailable.
        self._log_gameplay_image()

        if self.training_env.env_method("check_if_done", indices=[0])[0]:
            all_infos = self.training_env.get_attr("agent_stats")
            all_final_infos = [stats[-1] for stats in all_infos]
            mean_infos, distributions = merge_dicts(all_final_infos)
            # TODO log distributions, and total return
            for key, val in mean_infos.items():
                self.logger.record(f"env_stats/{key}", val)

            for key, distrib in distributions.items():
                self.writer.add_histogram(f"env_stats_distribs/{key}", distrib, self.n_calls)
                self.logger.record(f"env_stats_max/{key}", max(distrib))

            # Original trajectory/image logging (left unchanged).
            # images = self.training_env.get_attr("recent_screens")
            # images_row = rearrange(np.array(images), "(r f) h w c -> (r c h) (f w)", r=2)
            # self.logger.record("trajectory/image", Image(images_row, "HW"), exclude=("stdout", "log", "json", "csv"))

            explore_map = np.asarray(self.training_env.get_attr("explore_map"))
            map_sum = reduce(explore_map, "f h w -> h w", "max")
            map_row = rearrange(explore_map, "(r f) h w -> (r h) (f w)", r=2)

            # Enlarge only the images sent to TensorBoard. np.repeat is
            # nearest-neighbour scaling, so explored/unexplored tile boundaries
            # remain crisp and the environment's stored maps stay unchanged.
            if self.map_image_scale > 1:
                scale = self.map_image_scale
                map_sum = np.repeat(np.repeat(map_sum, scale, axis=0), scale, axis=1)
                map_row = np.repeat(np.repeat(map_row, scale, axis=0), scale, axis=1)

            self.logger.record(
                "trajectory/explore_sum",
                Image(np.ascontiguousarray(map_sum, dtype=np.uint8), "HW"),
                exclude=("stdout", "log", "json", "csv"),
            )
            self.logger.record(
                "trajectory/explore_map",
                Image(np.ascontiguousarray(map_row, dtype=np.uint8), "HW"),
                exclude=("stdout", "log", "json", "csv"),
            )

            list_of_flag_dicts = self.training_env.get_attr("current_event_flags_set")
            merged_flags = {k: v for d in list_of_flag_dicts for k, v in d.items()}
            self.logger.record("trajectory/all_flags", json.dumps(merged_flags))

        return True

    def _on_training_end(self):
        if self.writer:
            self.writer.close()
