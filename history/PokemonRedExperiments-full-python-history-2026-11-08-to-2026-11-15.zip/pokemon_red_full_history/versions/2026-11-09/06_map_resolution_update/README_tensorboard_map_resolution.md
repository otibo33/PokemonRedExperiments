# TensorBoard exploration-map resolution update

This is a drop-in update to the `TensorboardCallback` version provided in the conversation.

## What changes

- `trajectory/explore_sum`: enlarged 2x in both dimensions.
- `trajectory/explore_map`: enlarged 2x in both dimensions.
- Enlargement uses nearest-neighbour pixel replication (`numpy.repeat`) so visited/unvisited tile edges remain crisp.
- Original tags remain unchanged, so the images continue to appear in the same TensorBoard panels.
- The environment's `explore_map`, model observations, rewards, and PPO behaviour are not modified.
- Existing stats, histograms, event flags, and gameplay screenshot logging are preserved.

## Install

From the v2 project directory, back up the current callback and replace it with the supplied `tensorboard_callback.py`:

```fish
cp tensorboard_callback.py tensorboard_callback.py.backup
# Copy the downloaded tensorboard_callback.py into this directory
```

No environment-file changes are required for the map enlargement.

## Optional scaling

The callback constructor now accepts `map_image_scale`, defaulting to `2`:

```python
TensorboardCallback(log_dir, map_image_scale=2)
```

You can set it to `3` or `4` for larger map images, at the cost of substantially more image memory and TensorBoard event-file space. The default 2x is a conservative choice, especially for `trajectory/explore_map`, which tiles all worker maps into one large image.

The scale affects only the image recorded to TensorBoard. It does not create additional map detail; it makes each existing map pixel easier to inspect.
