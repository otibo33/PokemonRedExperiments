# High-resolution TensorBoard gameplay images

Files in this bundle:

- `red_gym_env_v2.py`: your uploaded environment with `get_tensorboard_frame(scale=4)` added. The policy's 72x80 grayscale observation path is unchanged.
- `tensorboard_game_image_callback.py`: Stable-Baselines3 callback that logs a full-colour screenshot from one vector-environment worker.

## Install

Copy both `.py` files into `~/Projects/PokemonRedExperiments/v2/`, replacing the existing `red_gym_env_v2.py` with the supplied updated version. Keep `tensorboard_game_image_callback.py` beside `baseline_fast_v2.py`.

## Wire the callback into training

Add this import to `baseline_fast_v2.py`:

```python
from tensorboard_game_image_callback import TensorBoardGameImageCallback
```

Then pass the callback to the existing `model.learn(...)` call:

```python
image_callback = TensorBoardGameImageCallback(
    log_freq=2000,  # callback calls; with 16 envs, ~32,000 timesteps
    scale=4,        # 160x144 -> 640x576
    env_index=0,    # screenshot from the first worker
)

model.learn(
    total_timesteps=...,  # keep your existing value
    callback=image_callback,
    # keep your other existing model.learn arguments
)
```

If the script already passes another callback, combine them with `CallbackList` rather than replacing it:

```python
from stable_baselines3.common.callbacks import CallbackList
callback = CallbackList([existing_callback, image_callback])
```

TensorBoard must also be enabled on the model, e.g. `tensorboard_log="runs/tensorboard"` in the PPO/A2C constructor. Preserve your existing log directory if it is already configured.

Open TensorBoard on the matching log directory. The image tag is `gameplay/screen_4x_rgb`.

## Notes

- The native Game Boy frame is 160x144; 4x nearest-neighbour enlargement yields 640x576. This makes pixels larger and clearer but does not invent additional detail.
- The agent still receives exactly the same observation shape and values as before.
- The screenshot is fetched from environment index 0 only, so the callback has minimal overhead.
- To log less often, increase `log_freq`; to log more often, decrease it (for 16 environments, `log_freq=500` means about 8,000 environment timesteps between images).
