"""Pokémon Red TensorBoard callback with enlarged exploration-map images.

Preserves the existing TensorboardCallback API and logging:
- env_stats averages and distributions
- env_stats_distribs histograms and env_stats_max values
- trajectory/explore_sum and trajectory/explore_map
- trajectory/all_flags

Only the two exploration-map images are enlarged for TensorBoard. No gameplay
screenshots are captured, and the environment maps, observations, rewards, and
training behaviour are not modified.
"""

import os
import json

from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.logger import Image
from torch.utils.tensorboard import SummaryWriter
import numpy as np
from einops import rearrange, reduce


def merge_dicts(dicts):
    sum_dict = {}
    count_dict = {}
    distrib_dict = {}

    for d in dicts:
        for k, v in d.items():
            if isinstance(v, (int, float)):
                sum_dict[k] = sum_dict.get(k, 0) + v
                count_dict[k] = count_dict.get(k, 0) + 1
                distrib_dict.setdefault(k, []).append(v)

    mean_dict = {}
    for k in sum_dict:
        mean_dict[k] = sum_dict[k] / count_dict[k]
        distrib_dict[k] = np.array(distrib_dict[k])

    return mean_dict, distrib_dict


class TensorboardCallback(BaseCallback):
    """Log the existing training statistics and enlarged exploration maps.

    The original constructor remains compatible:
        TensorboardCallback(log_dir)
        TensorboardCallback(log_dir, verbose=1)

    Optional map_image_scale controls display-only enlargement (default 2).
    Set it to 1 to use the original map image dimensions.
    """

    def __init__(self, log_dir, verbose=0, map_image_scale=2):
        super().__init__(verbose)
        self.log_dir = log_dir
        self.writer = None

        if int(map_image_scale) < 1:
            raise ValueError("map_image_scale must be a positive integer")
        self.map_image_scale = int(map_image_scale)

    def _on_training_start(self):
        if self.writer is None:
            self.writer = SummaryWriter(
                log_dir=os.path.join(self.log_dir, "histogram")
            )

    def _on_step(self) -> bool:
        if self.training_env.env_method("check_if_done", indices=[0])[0]:
            all_infos = self.training_env.get_attr("agent_stats")
            all_final_infos = [stats[-1] for stats in all_infos if stats]
            if all_final_infos:
                mean_infos, distributions = merge_dicts(all_final_infos)

                for key, val in mean_infos.items():
                    self.logger.record(f"env_stats/{key}", val)

                for key, distrib in distributions.items():
                    self.writer.add_histogram(
                        f"env_stats_distribs/{key}", distrib, self.n_calls
                    )
                    self.logger.record(f"env_stats_max/{key}", max(distrib))

            # Keep the existing exploration-map aggregation and layout.
            explore_map = np.asarray(self.training_env.get_attr("explore_map"))
            map_sum = reduce(explore_map, "f h w -> h w", "max")
            map_row = rearrange(
                explore_map, "(r f) h w -> (r h) (f w)", r=2
            )

            # Enlarge only the TensorBoard images. Nearest-neighbour scaling
            # keeps tile edges crisp and does not mutate the stored maps.
            if self.map_image_scale > 1:
                scale = self.map_image_scale
                map_sum = np.repeat(
                    np.repeat(map_sum, scale, axis=0), scale, axis=1
                )
                map_row = np.repeat(
                    np.repeat(map_row, scale, axis=0), scale, axis=1
                )

            self.logger.record(
                "trajectory/explore_sum",
                Image(np.ascontiguousarray(map_sum, dtype=np.uint8), "HW"),
                exclude=("stdout", "log", "json", "csv"),
            )
            self.logger.record(
                "trajectory/explore_map",
                Image(np.ascontiguousarray(map_row, dtype=np.uint8), "HW"),
                exclude=("stdout", "log", "json", "csv"),
            )

            list_of_flag_dicts = self.training_env.get_attr(
                "current_event_flags_set"
            )
            merged_flags = {
                k: v for d in list_of_flag_dicts for k, v in d.items()
            }
            self.logger.record(
                "trajectory/all_flags", json.dumps(merged_flags)
            )

        return True

    def _on_training_end(self):
        if self.writer:
            self.writer.close()
            self.writer = None
