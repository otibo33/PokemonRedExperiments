# TensorBoard callback: enlarged exploration maps only

This version retains the user's existing `TensorboardCallback` and all its
original statistics/event logging. It does **not** capture or log gameplay
screenshots.

## Install

1. Back up the working file:

   ```fish
   cp tensorboard_callback.py tensorboard_callback.py.backup
   ```

2. Place the supplied `tensorboard_callback.py` in
   `~/Projects/PokemonRedExperiments/v2/`, replacing the old callback.

3. Keep the existing training import unchanged:

   ```python
   from tensorboard_callback import TensorboardCallback
   ```

4. Keep the existing callback construction unchanged:

   ```python
   TensorboardCallback(log_dir)
   ```

## Image sizes

Both `trajectory/explore_sum` and `trajectory/explore_map` are enlarged by 2x
using nearest-neighbour scaling. The original `explore_map` arrays are not
modified. Gameplay screenshot logging is completely omitted.

To use a different map scale, pass the optional argument:

```python
TensorboardCallback(log_dir, map_image_scale=3)
```

Use `map_image_scale=1` to disable enlargement.
