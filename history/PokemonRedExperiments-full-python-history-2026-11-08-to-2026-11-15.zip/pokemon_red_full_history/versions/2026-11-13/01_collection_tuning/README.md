# Pokémon Red collection-focused reward tuning

This patch responds to the supplied TensorBoard metrics. It leaves the level-spread target at 10 and does not increase its reward: the reported 92.4% mean balance is already high, while party size/captures/balls are the bottleneck.

## Changed environment defaults
- capture reward weight: 16 -> 32
- distinct active-party species reward: 3 -> 8
- current party-diversity shaping: 1.5 -> 2.5
- Poké Ball high-water reward: 0.5 -> 4.0 (goal remains 10)
- starter novelty reward weight: 20 -> 40
- level spread target remains 10; level balance weight remains 5

At reward_scale=0.5, each new high-water Poké Ball is worth 2 reward points, a new distinct party species is worth 4 points, and a confirmed first-time capture is worth 16 points. These are potential-based high-water increments; they are not repeated every step.

## Diagnostics
The environment now includes `capture_marker_species`, `capture_pending_steps`, and `pending_dex_entries` in step info and terminal snapshots. The updated GameStatsCallback logs these along with captures, balls, party size, and Dex counts. This will distinguish “the agent never attempts a capture” from “the capture marker is seen but not paired with a Dex update.”

## Install (Fish)
Stop training, then from the project `v2` directory:

```fish
cp red_gym_env_v2.py red_gym_env_v2.py.before_collection_tuning
cp game_stats_callback.py game_stats_callback.py.before_collection_tuning
cp /path/to/red_gym_env_v2_collection_tuned.py red_gym_env_v2.py
cp /path/to/game_stats_callback_collection_diagnostics.py game_stats_callback.py
cp /path/to/tensorboard_callback_collection_tuned.py tensorboard_callback.py  # only if your runner imports TensorboardCallback
python -m py_compile red_gym_env_v2.py game_stats_callback.py tensorboard_callback.py
```

The updated environment expects the existing `starter_diversity.py` module and the same pre-starter state. It does not change observation or action spaces, so the PPO checkpoint remains compatible.

## Resume
Keep the same PPO checkpoint and session directory so the SQLite starter counts persist. Add `--ent-coef 0.05 --n-epochs 3` to your existing command. The script's resume path only overrides saved entropy/epochs when these flags are supplied.

Do not reset `starter_choice_counts.sqlite3`; it contains the 90-choice history. The agent is still free to choose any starter.
