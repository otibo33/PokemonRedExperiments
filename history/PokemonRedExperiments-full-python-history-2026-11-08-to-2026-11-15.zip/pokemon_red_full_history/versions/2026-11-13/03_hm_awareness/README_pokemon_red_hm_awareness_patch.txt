POKEMON RED — HM CARRIER + FIELD-USE AWARENESS PATCH
====================================================

WHAT IT CHANGES
---------------
This is an additive patch for the existing RedGymEnv and TensorBoard callback.
It is designed to preserve the current PPO checkpoint's model-facing spaces.

HM carrier preference (species must still be legally compatible in Red/Blue):
  Cut      -> prefer a non-starter Grass-type carrier
  Fly      -> prefer a non-starter Flying-type carrier
  Surf     -> prefer a non-starter Water-type carrier
  Strength -> prefer a non-starter Fighting- or Rock-type carrier

The reward ladder separately rewards:
  1. Having a compatible non-starter in the active party.
  2. Having a non-starter whose type matches that HM's preferred role.
  3. Teaching the move to a non-starter.
  4. Teaching it to the preferred type-role carrier.
  5. Having that preferred carrier actually field-ready (HM item + move + badge).

It does not force a Pokémon to learn an HM. If there is no compatible non-starter,
the existing system can still use the starter/another compatible party member.
The preferred type is only a tie-breaker among Pokémon that can legally learn
that HM; type alone never grants HM compatibility.

FIELD-USE SIGNALS
-----------------
  Cut: first entry into Route 9 or Route 16 while Cut is field-ready. These map
       transitions are progression proxies for passing Cut-tree gates, not a
       detector for every single Cut animation.
  Surf: first entry into Routes 19, 20 or 21 while Surf is field-ready. These are
        route-entry proxies, not a detector for every possible Surf activation.
  Strength: newly-set game event flags for the Seafoam Islands / Victory Road
            boulder switches. These are direct puzzle-event signals.
  Fly: teaching/readiness is tracked, but Fly activation is not given a use
       reward because a map transition alone cannot reliably distinguish Fly
       from ordinary walking/door transitions.

The route IDs and Gen-I type IDs follow pret/pokered constants. Strength boulder
flags are read directly from WRAM by event index; the policy observation shape
is not enlarged to include those later event bytes.

CHECKPOINT COMPATIBILITY
------------------------
No action-space or observation-space field, order, shape, or dtype is changed.
The patch changes the reward function and TensorBoard/info metadata only, so the
existing PPO policy/checkpoint remains structurally loadable. As with any reward
change, continued PPO training will adapt from the current policy rather than
reproduce the old reward objective exactly.

Important limitation: this is checkpoint-compatible reward shaping, not a new
symbolic HM-state input channel to the neural policy. The agent still has its
existing game-screen / observation inputs; the new HM state is used for reward
and diagnostics. A dedicated structured HM observation would change the model
input and would require a new compatible policy architecture/training setup.

The patch does not replace update_pokemon_progress() or the capture-marker logic.
It adds to the current environment source, preserving the newer capture
instrumentation already present in your local file.

SAFE INSTALL
------------
1. Stop the current trainer normally (Ctrl+C) so it can save its latest model.
   Do not delete the run directory, checkpoints, or starter_choice_counts DB.
2. Copy this .patch file into your v2 project directory, alongside:
       red_gym_env_v2.py
       tensorboard_callback.py
3. Make backups:
       cp red_gym_env_v2.py red_gym_env_v2.py.pre_hm_awareness
       cp tensorboard_callback.py tensorboard_callback.py.pre_hm_awareness
4. First run a dry check:
       patch -p0 --dry-run < pokemon_red_hm_awareness.patch
5. Only if every hunk reports that it can be applied, apply it:
       patch -p0 < pokemon_red_hm_awareness.patch
6. Run syntax and structural checks:
       python -m py_compile red_gym_env_v2.py tensorboard_callback.py
       python test_hm_awareness_patch.py

If the dry run reports a failed hunk, DO NOT force it and do not copy the
reference environment file over your active file. It means the local source has
drifted from the patch base; retain your backups and provide the current files
for a direct merge instead.

The test script is included in this package. Put it in the project directory
before running the command above. It verifies the expected HM roles, route and
boulder flags, callback metrics, preservation of capture instrumentation, and
exact hashes of the original action/observation-space assignments.

After the checks pass, resume from the same checkpoint and TensorBoard session
using your existing resume command. The callback will add game/hm_*_mean tags
and the most-advanced party image will display each member's type, STARTER /
TEAMMATE status, and preferred HM carrier roles.
