# Pokémon Red TensorBoard logger key-collision fix

The callback was recording both
`game/most_advanced_party_level_balance_eligible` and
`game/most_advanced_party_level_balance_score`.

Stable-Baselines3's human-readable output formatter truncates keys to 36
characters by default. Those two names truncate to the same display label,
causing `logger.dump()` to raise `ValueError` and stop training.

The updated `tensorboard_callback.py` keeps both original metric names for
TensorBoard, CSV and JSON, but excludes them from only the narrow `stdout` and
`log` text-table formats. No training reward, observation, action, checkpoint,
or TensorBoard tag is changed.

## Install (Fish shell)

Stop the training process and all its worker processes first. From the `v2`
project directory:

```fish
cp tensorboard_callback.py tensorboard_callback.py.before_logger_key_fix
unzip -o ~/Downloads/pokemon_red_logger_key_fix.zip -d /tmp/pokemon_logger_fix
cp /tmp/pokemon_logger_fix/tensorboard_callback.py .
cp /tmp/pokemon_logger_fix/test_logger_key_collision.py .
python -m py_compile tensorboard_callback.py
python test_logger_key_collision.py
```

Resume from the newest checkpoint. Keep the same TensorBoard session directory.
