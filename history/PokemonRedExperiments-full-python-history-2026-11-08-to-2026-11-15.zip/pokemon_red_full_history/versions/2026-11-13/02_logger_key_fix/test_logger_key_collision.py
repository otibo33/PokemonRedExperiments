"""Regression check for the SB3 stdout key-truncation collision.

This is dependency-free: it mirrors HumanOutputFormat's 36-character key
truncation and verifies the two colliding callback tags are excluded from
stdout and the text log, while retaining their original TensorBoard names.
"""
from __future__ import annotations

import ast
from pathlib import Path

CALLBACK = Path(__file__).with_name("tensorboard_callback.py")
EXPECTED = {
    "game/most_advanced_party_level_balance_eligible",
    "game/most_advanced_party_level_balance_score",
}


def main() -> None:
    source = CALLBACK.read_text(encoding="utf-8")
    tree = ast.parse(source)
    records: dict[str, tuple[str, ...]] = {}

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        if not (isinstance(func, ast.Attribute) and func.attr == "record"):
            continue
        if not (isinstance(func.value, ast.Attribute) and func.value.attr == "logger"):
            continue
        if not node.args or not isinstance(node.args[0], ast.Constant):
            continue
        key = node.args[0].value
        if not isinstance(key, str):
            continue
        excluded: tuple[str, ...] = ()
        for kw in node.keywords:
            if kw.arg == "exclude" and isinstance(kw.value, (ast.Tuple, ast.List)):
                excluded = tuple(
                    item.value for item in kw.value.elts
                    if isinstance(item, ast.Constant) and isinstance(item.value, str)
                )
        records[key] = excluded

    missing = EXPECTED - records.keys()
    assert not missing, f"Missing expected TensorBoard tags: {sorted(missing)}"
    for key in EXPECTED:
        assert {"stdout", "log"}.issubset(records[key]), (
            f"{key} must exclude stdout/log but preserve its TensorBoard tag"
        )

    def truncate(value: str, width: int = 36) -> str:
        return value if len(value) <= width else value[: width - 3] + "..."

    displayed: set[tuple[str, str]] = set()
    for key, excluded in sorted(records.items()):
        if "stdout" in excluded or "log" in excluded:
            continue
        if "/" in key:
            tag = key[: key.find("/") + 1]
            shortened = "   " + key[len(tag):]
        else:
            tag = ""
            shortened = key
        display_key = (tag, truncate(shortened))
        assert display_key not in displayed, f"stdout key truncation collision: {key}"
        displayed.add(display_key)

    print("PASS: long balance tags remain in TensorBoard and no stdout key collision remains")


if __name__ == "__main__":
    main()
