POKEMON RED — CAPTURE COUNTER + HM AWARENESS PATCH
==================================================

SCOPE
-----
This patch updates only red_gym_env_v2.py and tensorboard_callback.py. It keeps
the existing action and observation spaces unchanged. The PPO checkpoint
remains structurally compatible and can be resumed. Rewards and TensorBoard
diagnostics change, so subsequent PPO updates optimize a changed objective.
It does NOT add an explicit symbolic HM input vector to the policy observation;
that would require a new policy input shape.

CAPTURE COUNTER FIX
------------------
The successful-capture marker in Red/Blue WRAM (wCapturedMonSpecies, 0xD11C)
is counted directly. A new Pokédex bit is no longer required for a catch to be
counted, so catching a species already owned can still increment captures.
Pokédex additions remain tracked independently; gifts/evolutions do not count
as catches unless the capture marker is also observed.

The marker is sampled at the normal environment update cadence. If two
identical catches occur without the emulator ever exposing the intervening
zero marker to an environment update, the second can still be missed. The
included test covers repeat catches when the game's marker reset is observed.

HM CARRIERS
-----------
The agent receives separate shaping rewards for keeping a compatible carrier
in the active party, preferring a non-starter, preferring the requested type,
teaching the HM, and making the carrier field-ready (HM item + move + badge).
Gen-I species compatibility is mandatory; type preference alone never makes a
Pokémon HM-compatible.

Preferred roles (only when legally compatible in Red/Blue):
  Cut      -> non-starter Grass-type
  Fly      -> non-starter Flying-type
  Surf     -> non-starter Water-type
  Strength -> non-starter Fighting- or Rock-type

If no compatible non-starter is available, a compatible starter/other party
member can still provide the HM. The patch does not force a move-learning
choice or automate menu input to teach the move.

FIELD USE DIAGNOSTICS / REWARDS
------------------------------
  Cut: first entry into Route 9 or Route 16 while Cut is field-ready. This is a
       progression proxy for passing a Cut-tree gate, not direct detection of
       every Cut animation.
  Surf: first entry into Routes 19, 20 or 21 while Surf is field-ready. This is
        a route-entry proxy, not direct detection of every Surf activation.
  Strength: newly-set boulder-switch event flags associated with Seafoam
            Islands and Victory Road. These are direct puzzle-event signals.
  Fly: carrier/readiness is tracked, but no Fly-use reward is inferred from a
       generic map transition because it cannot distinguish Fly from normal
       walking, doors, or other transitions.

The type preference is a team-building heuristic, not an assertion that every
Grass/Flying/Water/Fighting/Rock type can learn the relevant HM. The actual
Red/Blue species compatibility table remains authoritative.

SAFE INSTALL (FISH SHELL)
-------------------------
1. Stop the trainer normally with Ctrl+C so it can save the latest model. Do
   not delete runs/, checkpoints, TensorBoard logs or the starter-choice DB.

2. Copy this patch and the test files into your v2 project directory, beside
   red_gym_env_v2.py and tensorboard_callback.py.

3. Back up both active files:

   cp red_gym_env_v2.py red_gym_env_v2.py.pre_capture_hm
   cp tensorboard_callback.py tensorboard_callback.py.pre_capture_hm

4. Dry-run first:

   patch -p0 --dry-run < pokemon_red_capture_and_hm_awareness.patch

5. Only if every hunk succeeds, apply:

   patch -p0 < pokemon_red_capture_and_hm_awareness.patch

6. Syntax-check and run tests:

   python -m py_compile red_gym_env_v2.py tensorboard_callback.py
   python test_capture_rewards.py
   python test_party_balance.py
   python test_starter_diversity.py
   python test_callback_party_metrics.py
   python test_hm_awareness_patch.py

7. Resume with the same PPO checkpoint and run/session configuration.

IMPORTANT
---------
If dry-run reports a failed hunk, stop. Do not use --force and do not
replace active source with an older complete file. Your local source then
differs from this patch's base and needs a direct merge. This patch was prepared
against the saved party-completion environment and logger-key-fixed callback.
The tests verify model I/O assignment hashes and source-level behavior; they
are not a live PyBoy training integration test.
