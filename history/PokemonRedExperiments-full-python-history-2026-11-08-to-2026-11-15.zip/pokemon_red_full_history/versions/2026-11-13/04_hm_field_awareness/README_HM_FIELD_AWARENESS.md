# Pokémon Red HM assignment and field-use awareness patch

This patch builds on the party-completion/capture-aware environment version whose
`red_gym_env_v2.py` includes `CATCH_BALL_ITEM_IDS`, `capture_pending_steps`,
`pending_dex_entries`, and `get_hm_info_metrics()`.

## Behaviour added

- **HM carrier preference:** for each HM, a compatible non-starter is preferred
  whenever one is present in the active party. The starter is a fallback only
  when no active non-starter can learn that HM. Starter identity is tracked by
  OT ID + DVs, so evolution and party reordering do not normally change the tag.
- **Assignment shaping:** rewards are provided for non-starter HM candidates,
  teaching the HM to the preferred carrier, and reaching field-ready status.
  A penalty is applied when only the starter knows an HM despite an eligible
  non-starter teammate being available. There is an additional specialist bonus
  for teaching **Strength to a compatible Fighting- or Rock-type teammate** and
  **Fly to a compatible Flying-type teammate**. The specialist must be a
  non-starter; if no such teammate exists, the ordinary compatible non-starter
  preference remains the fallback.
- **Successful field use:** confirmed Cut use on trees, tall grass, and gym trees;
  transition into the Surfing state; and successful Strength boulder pushes are
  recorded and rewarded once per unique obstacle/map event.
- **TensorBoard diagnostics:** aggregate and most-advanced-worker metrics record
  candidate HMs, non-starter teaching, Fighting/Rock/Flying specialist matches,
  wrong starter assignments, field readiness, Cut uses, Surf starts, and Strength
  boulder pushes. Party cards show each Pokémon's types and label a starter who
  also carries an HM as `STARTER + HM`.
- **Capture detection fix:** the trainer now samples `wCapturedMonSpecies`
  frame-by-frame during battles and latches its rising edge before the game clears
  it. Successful repeat captures count even when that species was already in the
  Pokédex. The scripted Old Man tutorial catch is excluded. This fixes the previous
  design's dependence on seeing both the transient capture flag and a new Dex bit.
- **Ball inventory correction:** Safari Balls (item ID `0x08`) now count as
  catch-capable balls alongside Poké, Great, Ultra, and Master Balls.

The compatibility table is specific to the English Red/Blue game, rather than
assuming that every Pokémon of a particular type can learn an HM. Fly is rewarded
as an HM assignment/readiness goal for compatible species. Fly field use is not
currently detected as a separate event.

## Important gameplay interpretation

- **Cut** is rewarded when the game confirms cutting a tree, tall grass, or a
  gym tree. The tile/action-result checks distinguish a successful use from
  pressing A at an invalid obstacle.
- **Surf** is rewarded when the overworld state actually changes into Surfing.
- **Strength** is rewarded when the game sets its boulder-pushed flag; simply
  carrying Strength does not count as field use.
- Strength is a **Normal-type** move, not a Fighting- or Rock-type move. Fighting
  and Rock are preferred *carrier roles*, but a Pokémon is considered only when
  it can actually learn Strength in Red/Blue.
- Fly carrier preference is similarly Flying-type plus actual Red/Blue Fly
  compatibility; a Flying-type Pokémon that cannot learn Fly is not a candidate
  (for example, Charizard cannot learn Fly in Red/Blue).

## Checkpoint compatibility and scope

No observation keys, observation tensor dimensions, action count, or PPO policy
architecture are changed. The existing checkpoint should therefore remain
structurally compatible with the environment when loaded through SB3's normal
space validation. Reward shaping has changed, so this is a continuation under a
new reward function, not an identical reproduction of the old training dynamics.

The extra HM awareness is implemented through reward shaping and diagnostics;
it does **not** add explicit HM candidate/obstacle flags to the policy observation.
That avoids invalidating the existing checkpoint, but the policy still has to
infer menu choices and obstacle context from the existing screen/event inputs.

The tests below use mocked RAM and pure helpers. They do not replace a live
PyBoy smoke test on the user's ROM/save state.

## Tests run while preparing this patch

- `python test_capture_rewards.py` — all 19 checks passed, including Safari Ball
  counting, non-starter HM carrier preference, Fighting/Rock/Flying role
  preferences, and short-lived repeated-capture marker latching.
- `python -m unittest -v test_hm_field_logic.py` — 6 tests passed.
- `python test_party_balance.py` — 5 tests passed.
- `python test_starter_diversity.py` — 4 tests passed.
- `python test_callback_party_metrics.py` — passed.
- `python -m py_compile ...` — passed for the patched modules and test files.

These are local unit/compile checks only; no live PyBoy training process was run.

## Install (Fish shell)

Stop training first and let the current process save its checkpoint. From the
project's `v2` directory, back up the files that this patch replaces:

```fish
cp red_gym_env_v2.py red_gym_env_v2.py.before_hm_field_awareness
cp tensorboard_callback.py tensorboard_callback.py.before_hm_field_awareness
cp game_stats_callback.py game_stats_callback.py.before_hm_field_awareness
```

Extract the ZIP to a temporary directory (replace the path with wherever the
browser saved the ZIP):

```fish
unzip -o /path/to/pokemon_red_hm_field_awareness_patch.zip -d /tmp/pokemon_red_hm_field_awareness
cp /tmp/pokemon_red_hm_field_awareness/red_gym_env_v2.py .
cp /tmp/pokemon_red_hm_field_awareness/hm_field_logic.py .
cp /tmp/pokemon_red_hm_field_awareness/tensorboard_callback.py .
cp /tmp/pokemon_red_hm_field_awareness/game_stats_callback.py .
cp /tmp/pokemon_red_hm_field_awareness/test_hm_field_logic.py .
cp /tmp/pokemon_red_hm_field_awareness/test_capture_rewards.py .
```

With the project's virtual environment active, run:

```fish
python -m py_compile red_gym_env_v2.py hm_field_logic.py tensorboard_callback.py game_stats_callback.py
python test_capture_rewards.py
python -m unittest -v test_hm_field_logic.py
python test_party_balance.py
python test_starter_diversity.py
python test_callback_party_metrics.py
```

Resume the same checkpoint and keep using the same `runs` session directory.
Do not delete or reset the checkpoint, TensorBoard run data, or
`starter_choice_counts.sqlite3`.
