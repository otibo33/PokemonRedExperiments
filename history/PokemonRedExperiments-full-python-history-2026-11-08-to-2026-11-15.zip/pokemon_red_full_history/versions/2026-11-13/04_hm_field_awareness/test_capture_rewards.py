from __future__ import annotations

import importlib.util
import sys
import types
from pathlib import Path

# Stub runtime-only libraries so the RAM/reward helpers can be tested without
# launching PyBoy or installing the full training stack in this build sandbox.
gym = types.ModuleType('gymnasium')
class Env: pass
class Spaces: pass
gym.Env = Env
gym.spaces = Spaces()
sys.modules['gymnasium'] = gym

pyboy = types.ModuleType('pyboy')
class PyBoy: pass
pyboy.PyBoy = PyBoy
pyboy_utils = types.ModuleType('pyboy.utils')
class WindowEvent: pass
pyboy_utils.WindowEvent = WindowEvent
sys.modules['pyboy'] = pyboy
sys.modules['pyboy.utils'] = pyboy_utils

mediapy = types.ModuleType('mediapy')
sys.modules['mediapy'] = mediapy

global_map = types.ModuleType('global_map')
global_map.local_to_global = lambda *args: (0, 0)
global_map.GLOBAL_MAP_SHAPE = (48, 48)
sys.modules['global_map'] = global_map

module_path = Path(__file__).with_name('red_gym_env_v2.py')
spec = importlib.util.spec_from_file_location('red_gym_env_capture_test', module_path)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

class FakeEnv(mod.RedGymEnv):
    def __init__(self):
        self.memory = {}
        self.base_owned_count = 0
        self.max_owned_count = 0
        self.last_owned_count = 0
        self.last_captured_species = 0
        self.capture_pending_steps = 0
        self.pending_dex_entries = 0
        self._capture_marker_last_frame = 0
        self._capture_species_latched = 0
        self._capture_battle_type_latched = 0
        self.pending_dex_steps = 0
        self.capture_count = 0
        self.new_dex_entries = 0
        self.lifetime_best_owned_count = 0
        self.base_party_size = 1
        self.max_party_size = 1
        self.base_unique_party_count = 1
        self.max_unique_party_count = 1
        self.base_pokeballs = 5
        self.max_pokeballs = 5
        self.ball_goal = 10
        self.reward_scale = 0.5
        self.capture_reward_weight = 16.0
        self.dex_reward_weight = 2.0
        self.party_reward_weight = 3.0
        self.party_size_reward_weight = 12.0
        self.party_diversity_weight = 1.5
        self.party_balance_weight = 2.5
        self.party_level_tolerance = 8
        self.ball_reward_weight = 0.5
        self.hm_candidate_reward_weight = 2.0
        self.hm_item_reward_weight = 0.75
        self.hm_taught_reward_weight = 1.5
        self.hm_ready_reward_weight = 2.5
        self.hm_candidate_loss_penalty_weight = 1.0
        self.hm_ready_loss_penalty_weight = 0.5
        self.hm_nonstarter_candidate_reward_weight = 1.25
        self.hm_preferred_taught_reward_weight = 4.0
        self.hm_preferred_ready_reward_weight = 1.0
        self.hm_starter_wrong_assignment_penalty_weight = 2.0
        self.hm_role_taught_reward_weight = 2.5
        self.hm_cut_use_reward_weight = 4.0
        self.hm_surf_use_reward_weight = 4.0
        self.hm_strength_use_reward_weight = 6.0
        self.hm_field_use_counts = {
            "cut_tree": 0, "cut_grass": 0, "cut_gym_tree": 0,
            "surf_start": 0, "strength_boulder": 0,
        }
        self.hm_field_use_total = 0
        self.base_hm_nonstarter_candidate_score = 0.0
        self.base_hm_preferred_taught_score = 0.0
        self.base_hm_preferred_ready_score = 0.0
        self.base_hm_role_taught_score = 0.0
        self.max_hm_role_taught_score = 0.0
        self.max_hm_nonstarter_candidate_score = 0.0
        self.max_hm_preferred_taught_score = 0.0
        self.max_hm_preferred_ready_score = 0.0
        self.base_hm_candidate_score = 0.0
        self.base_hm_item_score = 0.0
        self.base_hm_taught_score = 0.0
        self.base_hm_ready_score = 0.0
        self.max_hm_candidate_score = 0.0
        self.max_hm_item_score = 0.0
        self.max_hm_taught_score = 0.0
        self.max_hm_ready_score = 0.0
        self.current_hm_status = {}
        self.starter_mon_signature = None
        self.starter_species = None
        self.current_hm_party_compatible_count = 0
        self.current_hm_items_owned_count = 0
        self.current_hm_moves_taught_count = 0
        self.current_hm_field_ready_count = 0
        self.current_hm_critical_party_compatible_count = 0
        self.current_hm_critical_items_owned_count = 0
        self.current_hm_critical_moves_taught_count = 0
        self.current_hm_critical_ready_count = 0
        self.current_hm_nonstarter_candidate_count = 0
        self.current_hm_nonstarter_moves_taught_count = 0
        self.current_hm_preferred_moves_taught_count = 0
        self.current_hm_preferred_field_ready_count = 0
        self.current_hm_starter_wrong_assignments_count = 0
        self.current_hm_role_candidates_count = 0
        self.current_hm_role_taught_count = 0
        self.max_event_rew = 0
        self.max_level_rew = 0
        self.total_healing_rew = 0
        self.explore_weight = 0.25
        self.map_progress_weight = 5.0
        self.stuck_penalty_weight = 1.0
        self.max_map_progress = 0
        self.seen_coords = {}
        self._event_cache = [0] * (mod.event_flags_end - mod.event_flags_start)

    def read_m(self, address):
        return self.memory.get(address, 0)

    def update_max_event_rew(self): return 0
    def get_levels_reward(self): return 0
    def get_badges(self): return 0
    def get_current_coord_count_reward(self): return 0


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def test_dex_count_masks_unused_bit():
    env = FakeEnv()
    env.memory[0xD2F7] = 0b00000011  # two valid species
    env.memory[0xD309] = 0b11000000  # #151 bit valid; #152 bit ignored
    check(env.read_pokedex_owned_count() == 3, 'Dex bit counting/mask failed')


def test_party_and_bag_parsing():
    env = FakeEnv()
    env.memory[mod.PARTY_COUNT_ADDRESS] = 3
    env.memory[0xD164] = 25
    env.memory[0xD165] = 4
    env.memory[0xD166] = 25
    check(env.read_unique_party_count() == 2, 'Unique party count failed')
    env.memory[mod.NUM_BAG_ITEMS_ADDRESS] = 4
    for idx, (item, qty) in enumerate([(4, 6), (0x14, 2), (3, 3), (0x08, 2)]):
        env.memory[mod.BAG_ITEMS_START + idx * 2] = item
        env.memory[mod.BAG_ITEMS_START + idx * 2 + 1] = qty
    check(env.read_pokeball_count() == 11, 'catch-ball inventory count failed (Safari Balls must count)')


def test_capture_marker_then_dex():
    env = FakeEnv()
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 25
    env._sample_capture_marker()
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 0
    env._sample_capture_marker()
    env.update_pokemon_progress()
    check(env.capture_count == 1,
          'Frame-latched capture must count even after the transient marker clears')
    env.memory[0xD2F7] = 1
    env._capture_species_latched = 0  # next PPO action begins with a fresh per-action latch
    env.update_pokemon_progress()
    check(env.capture_count == 1, 'The later Pokédex bit must not double-count the capture')


def test_dex_then_capture_marker():
    env = FakeEnv()
    env.memory[0xD2F7] = 1
    env.update_pokemon_progress()
    check(env.pending_dex_entries == 0 and env.capture_count == 0,
          'A Dex increase alone must remain distinct from a capture')
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 4
    env.update_pokemon_progress()
    check(env.capture_count == 1, 'Capture was not counted when the marker appeared after the Dex bit')


def test_evolution_or_gift_is_not_mislabelled_without_capture_marker():
    env = FakeEnv()
    env.memory[0xD2F7] = 1
    env.update_pokemon_progress()
    check(env.capture_count == 0, 'Dex increase alone must not count as a capture')


def test_rewards_are_monotonic_and_capture_is_weighted():
    env = FakeEnv()
    env.capture_count = 1
    env.max_owned_count = 2
    env.max_unique_party_count = 2
    env.max_pokeballs = 10
    rewards = env.get_game_state_reward()
    check(rewards['capture'] == 8.0, 'Capture reward weight/scale incorrect')
    check(rewards['dex'] == 2.0, 'Dex reward incorrect')
    check(rewards['party'] == 1.5, 'Party reward incorrect')
    check(rewards['balls'] == 1.25, 'Ball supply reward incorrect')
    env.memory[mod.PARTY_COUNT_ADDRESS] = 3
    rewards = env.get_game_state_reward()
    check(rewards['party_size'] == 3.0, 'Party-size reward should be one point per active slot at reward_scale=0.5')


def test_hm_internal_species_compatibility_is_red_blue_specific():
    env = FakeEnv()
    env.memory[mod.PARTY_COUNT_ADDRESS] = 2
    # Charizard (B4) can learn Cut/Strength in Red/Blue, but Fly is Yellow-only.
    env.memory[mod.PARTY_SPECIES_START] = 0xB4
    env.memory[mod.PARTY_SPECIES_START + 1] = 0xFF
    env.memory[mod.PARTY_MON_DATA_START] = 0xB4
    # Diglett (3B) has no HM compatibility in the Red/Blue chart; it must not count for Cut.
    env.memory[mod.PARTY_SPECIES_START + 1] = 0x3B
    env.memory[mod.PARTY_MON_DATA_START + mod.PARTY_MON_DATA_STRIDE] = 0x3B
    status = env.read_hm_status()
    check(status['cut']['party_can_learn'], 'Charizard should be a Cut candidate')
    check(status['strength']['party_can_learn'], 'Charizard should be a Strength candidate')
    check(not status['fly']['party_can_learn'], 'Charizard must not be counted as a Fly candidate in Red/Blue')
    check(mod.HM_COMPATIBLE_INTERNAL_SPECIES['cut'].__contains__(0xB4), 'Charizard Cut compatibility missing')
    # Verify Diglett is not incorrectly treated as a Cut learner in Red/Blue.
    env.memory[mod.PARTY_COUNT_ADDRESS] = 1
    env.memory[mod.PARTY_SPECIES_START] = 0x3B
    env.memory[mod.PARTY_MON_DATA_START] = 0x3B
    status = env.read_hm_status()
    check(not status['cut']['party_can_learn'], 'Diglett must not be counted as a Cut candidate')


def test_hm_party_moves_item_and_badge_are_separate_gates():
    env = FakeEnv()
    env.memory[mod.PARTY_COUNT_ADDRESS] = 1
    env.memory[mod.PARTY_SPECIES_START] = 0x40  # Farfetch'd: Cut + Fly candidate
    env.memory[mod.PARTY_MON_DATA_START] = 0x40
    env.memory[mod.PARTY_MON_DATA_START + mod.PARTY_MON_MOVE_OFFSET] = 0x0F  # Cut
    env.memory[mod.NUM_BAG_ITEMS_ADDRESS] = 1
    env.memory[mod.BAG_ITEMS_START] = 0xC4  # HM01 Cut
    env.memory[mod.BAG_ITEMS_START + 1] = 1
    env.memory[mod.BADGES_ADDRESS] = 0  # no Cascade Badge yet
    status = env.read_hm_status()['cut']
    check(status['party_can_learn'], 'Farfetchd should be compatible with Cut')
    check(status['item_owned'], 'HM01 item should be detected in the bag')
    check(status['party_knows_move'], 'Cut move should be read from the party record')
    check(not status['badge_owned'], 'Cascade Badge should be required')
    check(not status['field_ready'], 'Cut must not be field-ready without Cascade Badge')
    env.memory[mod.BADGES_ADDRESS] = 1 << 1
    status = env.read_hm_status()['cut']
    check(status['field_ready'], 'Cut should be field-ready once all three gates are met')


def test_hm_party_data_move_slots_and_items():
    env = FakeEnv()
    env.memory[mod.PARTY_COUNT_ADDRESS] = 1
    env.memory[mod.PARTY_SPECIES_START] = 0x4E  # Krabby can learn Cut/Surf/Strength
    base = mod.PARTY_MON_DATA_START
    env.memory[base] = 0x4E
    env.memory[base + mod.PARTY_MON_MOVE_OFFSET] = 0x39  # Surf
    env.memory[base + mod.PARTY_MON_MOVE_OFFSET + 1] = 0x46  # Strength
    env.memory[mod.NUM_BAG_ITEMS_ADDRESS] = 2
    env.memory[mod.BAG_ITEMS_START] = 0xC6  # HM03 Surf
    env.memory[mod.BAG_ITEMS_START + 1] = 1
    env.memory[mod.BAG_ITEMS_START + 2] = 0xC7  # HM04 Strength
    env.memory[mod.BAG_ITEMS_START + 3] = 1
    env.memory[mod.BADGES_ADDRESS] = (1 << 4) | (1 << 3)
    status = env.read_hm_status()
    check(status['surf']['party_can_learn'] and status['strength']['party_can_learn'], 'Krabby HM compatibility failed')
    check(status['surf']['party_knows_move'] and status['strength']['party_knows_move'], 'Move-slot parsing failed')
    check(status['surf']['field_ready'] and status['strength']['field_ready'], 'Surf/Strength readiness failed')


def test_non_obvious_red_blue_hm_compatibility_entries():
    # Compatibility table uses Red/Blue internal species IDs, not National Dex IDs.
    expected = {
        "surf": 0x0B,       # Lickitung
        "strength": 0x1D,   # Pinsir
        "strength_magmar": 0x33,
        "strength_electabuzz": 0x35,
        "flash": 0x68,      # Jolteon
    }
    check(expected["surf"] in mod.HM_COMPATIBLE_INTERNAL_SPECIES["surf"],
          'Lickitung should be able to learn Surf')
    check(expected["strength"] in mod.HM_COMPATIBLE_INTERNAL_SPECIES["strength"],
          'Pinsir should be able to learn Strength')
    check(expected["strength_magmar"] in mod.HM_COMPATIBLE_INTERNAL_SPECIES["strength"],
          'Magmar should be able to learn Strength')
    check(expected["strength_electabuzz"] in mod.HM_COMPATIBLE_INTERNAL_SPECIES["strength"],
          'Electabuzz should be able to learn Strength')
    check(expected["flash"] in mod.HM_COMPATIBLE_INTERNAL_SPECIES["flash"],
          'Jolteon should be able to learn Flash')



def test_hm_coverage_retention_penalizes_losing_only_party_access():
    env = FakeEnv()
    env.current_hm_status = {
        name: {
            "party_can_learn": False,
            "item_owned": False,
            "party_knows_move": False,
            "badge_owned": False,
            "field_ready": False,
            "nonstarter_can_learn": False,
            "starter_can_learn": False,
            "nonstarter_knows_move": False,
            "starter_knows_move": False,
            "preferred_taught": False,
            "preferred_field_ready": False,
            "role_type_candidate": False,
            "role_type_nonstarter_candidate": False,
            "role_type_taught": False,
            "role_type_nonstarter_taught": False,
            "role_taught": False,
            "starter_wrong_assignment": False,
            "compatible_party_species": (),
        }
        for name in mod.HM_DEFINITIONS
    }
    env.current_hm_status["cut"].update({"party_can_learn": False})
    env.max_hm_candidate_score = 2.0
    env.max_hm_ready_score = 2.0
    rewards = env.get_game_state_reward()
    check(rewards["hm_candidate_retention"] == -1.0,
          'Losing all previously achieved HM-compatible party coverage should be penalized')
    check(rewards["hm_ready_retention"] == -0.5,
          'Losing previously achieved HM field readiness should be penalized')



def test_hm_critical_completion_metrics():
    env = FakeEnv()
    env.current_hm_status = {
        name: {
            "party_can_learn": name in {"cut", "surf", "strength"},
            "item_owned": False,
            "party_knows_move": False,
            "badge_owned": False,
            "field_ready": False,
            "nonstarter_can_learn": False,
            "starter_can_learn": False,
            "nonstarter_knows_move": False,
            "starter_knows_move": False,
            "preferred_taught": False,
            "preferred_field_ready": False,
            "role_type_candidate": False,
            "role_type_nonstarter_candidate": False,
            "role_type_taught": False,
            "role_type_nonstarter_taught": False,
            "role_taught": False,
            "starter_wrong_assignment": False,
            "compatible_party_species": (),
        }
        for name in mod.HM_DEFINITIONS
    }
    env.current_hm_critical_party_compatible_count = 3
    env.current_hm_critical_ready_count = 2
    env._refresh_hm_counts = lambda: None
    metrics = env.get_hm_info_metrics()
    check(metrics["hm_critical_candidates_complete"] == 1,
          "All three story-critical HM candidate flags should be reported")
    check(metrics["hm_critical_ready_complete"] == 0,
          "Critical HM readiness must remain incomplete until all three are usable")
    env.current_hm_status["strength"]["field_ready"] = True
    env.current_hm_critical_ready_count = 3
    metrics = env.get_hm_info_metrics()
    check(metrics["hm_critical_ready_complete"] == 1,
          "Critical HM readiness should report complete at 3/3")


def test_hm_progress_uses_high_water_scores():
    env = FakeEnv()
    env.memory[mod.PARTY_COUNT_ADDRESS] = 1
    env.memory[mod.PARTY_SPECIES_START] = 0x4E  # Krabby gives Cut, Surf, Strength coverage
    env.memory[mod.PARTY_MON_DATA_START] = 0x4E
    env.reset_hm_progress_baseline()
    baseline = env.max_hm_candidate_score
    env.memory[mod.PARTY_COUNT_ADDRESS] = 2
    env.memory[mod.PARTY_SPECIES_START + 1] = 0x24  # Pidgey adds Fly
    env.memory[mod.PARTY_MON_DATA_START + mod.PARTY_MON_DATA_STRIDE] = 0x24
    env.update_hm_progress()
    check(env.max_hm_candidate_score > baseline, 'New HM-compatible species should increase candidate coverage')
    high = env.max_hm_candidate_score
    env.memory[mod.PARTY_COUNT_ADDRESS] = 1
    env.update_hm_progress()
    check(env.max_hm_candidate_score == high, 'HM candidate reward score must be a high-water mark')




def test_party_snapshot_includes_names_level_hp_moves_and_hm_roles():
    env = FakeEnv()
    env.memory[mod.PARTY_COUNT_ADDRESS] = 1
    env.memory[mod.PARTY_SPECIES_START] = 0xB1  # Squirtle
    base = mod.PARTY_MON_DATA_START
    env.memory[base] = 0xB1
    env.memory[base + 0x01] = 0
    env.memory[base + 0x02] = 25
    env.memory[base + 0x04] = 0
    env.memory[base + 0x08] = 0x39  # Surf
    env.memory[base + 0x21] = 12
    env.memory[base + 0x22] = 0
    env.memory[base + 0x23] = 30
    party = env.read_party_snapshot()
    check(len(party) == 1, 'Party snapshot should contain the active party member')
    mon = party[0]
    check(mon['species'] == 'Squirtle', 'Internal species index should resolve to Squirtle')
    check(mon['level'] == 12 and mon['hp'] == 25 and mon['max_hp'] == 30,
          'Party level/HP fields were parsed incorrectly')
    check('Surf' in mon['moves'], 'HM moves should have readable labels')
    check('SURF' in mon['hm_can_learn'], 'Squirtle should be marked as a Surf learner')
    check('SURF' in mon['hm_knows'], 'Squirtle should be marked as knowing Surf')


def test_hm_carrier_prefers_compatible_nonstarter_over_starter():
    env = FakeEnv()
    env.starter_species = "Charmander"
    env.memory[mod.PARTY_COUNT_ADDRESS] = 2

    # Starter Charizard (B4) and non-starter Farfetch'd (40) can both learn Cut.
    # OT ID + DVs identify the starter independently of its species/evolution.
    starter_base = mod.PARTY_MON_DATA_START
    teammate_base = starter_base + mod.PARTY_MON_DATA_STRIDE
    env.memory[mod.PARTY_SPECIES_START] = 0xB4
    env.memory[mod.PARTY_SPECIES_START + 1] = 0x40
    env.memory[starter_base] = 0xB4
    env.memory[teammate_base] = 0x40
    starter_signature = (0x12, 0x34, 0x56, 0x78)
    for offset, value in zip((0x0C, 0x0D, 0x1B, 0x1C), starter_signature):
        env.memory[starter_base + offset] = value
    env.starter_mon_signature = starter_signature

    cut = mod.HM_DEFINITIONS["cut"]
    env.memory[starter_base + mod.PARTY_MON_MOVE_OFFSET] = cut["move_id"]
    env.memory[mod.NUM_BAG_ITEMS_ADDRESS] = 1
    env.memory[mod.BAG_ITEMS_START] = cut["item_id"]
    env.memory[mod.BAG_ITEMS_START + 1] = 1
    env.memory[mod.BADGES_ADDRESS] = cut["badge_mask"]

    status = env.read_hm_status()["cut"]
    check(status["nonstarter_can_learn"], "Farfetch'd should be identified as a non-starter Cut candidate")
    check(status["starter_wrong_assignment"], "Starter-only Cut should be flagged when a compatible teammate exists")
    check(not status["preferred_taught"], "Starter-only Cut should not count as preferred while a non-starter can learn it")

    # Teaching Cut to the teammate should satisfy the preferred-carrier rule.
    env.memory[teammate_base + mod.PARTY_MON_MOVE_OFFSET] = cut["move_id"]
    status = env.read_hm_status()["cut"]
    check(status["nonstarter_knows_move"], "Non-starter Cut move should be detected")
    check(status["preferred_taught"], "Compatible non-starter should become the preferred HM carrier")
    check(status["preferred_field_ready"], "Non-starter carrier plus HM and badge should be field-ready")
    check(not status["starter_wrong_assignment"], "Correct assignment should clear the wrong-starter flag")


def test_capture_marker_frame_latch_counts_repeat_species_without_new_dex_bit():
    env = FakeEnv()
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 0
    env.memory[mod.BATTLE_TYPE_ADDRESS] = 0
    env._capture_marker_last_frame = 0

    # First capture: marker appears briefly and is cleared before the action ends.
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 0x24
    env._sample_capture_marker()
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 0
    env._sample_capture_marker()
    env.update_pokemon_progress()
    check(env.capture_count == 1, "A latched successful capture should count even after the RAM marker clears")

    # Catch the same species again: no new owned-Dex bit is set, but the marker
    # rises from zero again and must count as another capture.
    env._capture_species_latched = 0
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 0x24
    env._sample_capture_marker()
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 0
    env._sample_capture_marker()
    env.update_pokemon_progress()
    check(env.capture_count == 2, "Repeat captures must count even when Pokédex ownership does not increase")

    # The scripted Old Man tutorial catch sets the same RAM marker but is not
    # a Pokémon the player actually captures, so it must not increment the total.
    env._capture_species_latched = 0
    env.memory[mod.BATTLE_TYPE_ADDRESS] = mod.BATTLE_TYPE_OLD_MAN
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 0x24
    env._sample_capture_marker()
    env.memory[mod.CAPTURED_MON_SPECIES_ADDRESS] = 0
    env._sample_capture_marker()
    env.update_pokemon_progress()
    check(env.capture_count == 2, "Old Man tutorial capture must not be counted")


def test_strength_and_fly_prefer_role_appropriate_nonstarter_types():
    env = FakeEnv()
    env.starter_species = "Charmander"
    env.memory[mod.PARTY_COUNT_ADDRESS] = 3
    base = mod.PARTY_MON_DATA_START
    stride = mod.PARTY_MON_DATA_STRIDE

    # Starter Charizard can learn Strength; Onix is a compatible Rock-type teammate.
    env.memory[mod.PARTY_SPECIES_START] = 0xB4
    env.memory[mod.PARTY_SPECIES_START + 1] = 0x22
    env.memory[mod.PARTY_SPECIES_START + 2] = 0x24
    env.memory[base] = 0xB4
    env.memory[base + stride] = 0x22
    env.memory[base + 2 * stride] = 0x24
    env.starter_mon_signature = (0x11, 0x22, 0x33, 0x44)
    for offset, value in zip((0x0C, 0x0D, 0x1B, 0x1C), env.starter_mon_signature):
        env.memory[base + offset] = value

    # Gen-I party record type IDs: Rock=0x05, Ground=0x04; Flying=0x02.
    env.memory[base + stride + 0x05] = 0x05
    env.memory[base + stride + 0x06] = 0x04
    env.memory[base + 2 * stride + 0x05] = 0x00
    env.memory[base + 2 * stride + 0x06] = 0x02

    strength_move = mod.HM_DEFINITIONS["strength"]["move_id"]
    fly_move = mod.HM_DEFINITIONS["fly"]["move_id"]
    env.memory[base + mod.PARTY_MON_MOVE_OFFSET] = strength_move
    env.memory[base + 2 * stride + mod.PARTY_MON_MOVE_OFFSET] = fly_move

    status = env.read_hm_status()
    check(status["strength"]["role_type_candidate"], "Onix should be recognized as a Strength role candidate")
    check(not status["strength"]["role_taught"], "Starter-only Strength should not satisfy the Rock/Fighting teammate role")
    check(status["fly"]["role_type_candidate"], "Pidgey should be recognized as a Flying-type Fly candidate")
    check(status["fly"]["role_taught"], "Fly taught to the Flying-type teammate should satisfy its role")
    env.current_hm_status = status
    metrics = env.get_hm_info_metrics()
    check(metrics["hm_fly_role_type_candidate"] == 1,
          "Flying-type Fly candidate should be included in TensorBoard diagnostics")
    check(metrics["hm_fly_role_type_taught"] == 1,
          "Flying-type Fly assignment should be included in TensorBoard diagnostics")

    env.memory[base + stride + mod.PARTY_MON_MOVE_OFFSET] = strength_move
    status = env.read_hm_status()
    check(status["strength"]["role_taught"], "Strength taught to the Rock-type teammate should satisfy its role")
    env.current_hm_status = status
    metrics = env.get_hm_info_metrics()
    check(metrics["hm_strength_role_type_candidate"] == 1,
          "Rock-type Strength candidate should be included in TensorBoard diagnostics")
    check(metrics["hm_strength_role_type_taught"] == 1,
          "Rock-type Strength assignment should be included in TensorBoard diagnostics")


def test_generation_one_move_name_table_is_complete():
    check(len(mod.MOVE_NAMES) == 0xA5, 'Move-name lookup must cover Gen-I move IDs 0x01..0xA5')
    check(mod.MOVE_NAMES[0x0F] == 'Cut', 'Cut move label incorrect')
    check(mod.MOVE_NAMES[0x13] == 'Fly', 'Fly move label incorrect')
    check(mod.MOVE_NAMES[0x39] == 'Surf', 'Surf move label incorrect')
    check(mod.MOVE_NAMES[0x46] == 'Strength', 'Strength move label incorrect')
    check(mod.MOVE_NAMES[0x94] == 'Flash', 'Flash move label incorrect')


def test_internal_species_name_map_known_anchors():
    check(mod.INTERNAL_SPECIES_NAMES[0x01] == 'Rhydon', 'Internal index 0x01 name anchor failed')
    check(mod.INTERNAL_SPECIES_NAMES[0x15] == 'Mew', 'Internal index 0x15 name anchor failed')
    check(mod.INTERNAL_SPECIES_NAMES[0x70] == 'Weedle', 'Internal index 0x70 name anchor failed')
    check(mod.INTERNAL_SPECIES_NAMES[0x85] == 'Magikarp', 'Internal index 0x85 name anchor failed')
    check(mod.INTERNAL_SPECIES_NAMES[0x99] == 'Bulbasaur', 'Internal index 0x99 name anchor failed')
    check(mod.INTERNAL_SPECIES_NAMES[0xB0] == 'Charmander', 'Internal index 0xB0 name anchor failed')
    check(mod.INTERNAL_SPECIES_NAMES[0xB1] == 'Squirtle', 'Internal index 0xB1 name anchor failed')


for test in (
    test_dex_count_masks_unused_bit,
    test_party_and_bag_parsing,
    test_capture_marker_then_dex,
    test_dex_then_capture_marker,
    test_evolution_or_gift_is_not_mislabelled_without_capture_marker,
    test_rewards_are_monotonic_and_capture_is_weighted,
    test_hm_internal_species_compatibility_is_red_blue_specific,
    test_hm_party_moves_item_and_badge_are_separate_gates,
    test_hm_party_data_move_slots_and_items,
    test_non_obvious_red_blue_hm_compatibility_entries,
    test_hm_coverage_retention_penalizes_losing_only_party_access,
    test_hm_critical_completion_metrics,
    test_hm_progress_uses_high_water_scores,
    test_party_snapshot_includes_names_level_hp_moves_and_hm_roles,
    test_hm_carrier_prefers_compatible_nonstarter_over_starter,
    test_capture_marker_frame_latch_counts_repeat_species_without_new_dex_bit,
    test_strength_and_fly_prefer_role_appropriate_nonstarter_types,
    test_internal_species_name_map_known_anchors,
    test_generation_one_move_name_table_is_complete,
):
    test()
    print('PASS', test.__name__)
print('All capture-aware reward tests passed.')

