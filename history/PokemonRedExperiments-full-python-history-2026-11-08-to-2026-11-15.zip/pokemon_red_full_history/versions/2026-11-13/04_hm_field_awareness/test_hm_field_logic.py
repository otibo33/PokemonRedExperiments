import unittest

from hm_field_logic import classify_party_starters, detect_hm_field_events


class HmAssignmentTests(unittest.TestCase):
    def test_starter_identity_survives_evolution_and_reordering(self):
        records = [
            {"species_index": 0x2E, "identity_signature": (1, 2, 3, 4)},
            {"species_index": 0xB0, "identity_signature": (5, 6, 7, 8)},
        ]
        tagged = classify_party_starters(records, starter_signature=(1, 2, 3, 4), starter_species_known=True)
        self.assertTrue(tagged[0]["is_starter"])
        self.assertFalse(tagged[1]["is_starter"])

    def test_falls_back_to_first_slot_only_when_starter_known(self):
        records = [{"identity_signature": None}, {"identity_signature": None}]
        tagged = classify_party_starters(records, starter_signature=None, starter_species_known=True)
        self.assertTrue(tagged[0]["is_starter"])
        self.assertFalse(tagged[1]["is_starter"])
        unknown = classify_party_starters(records, starter_signature=None, starter_species_known=False)
        self.assertFalse(any(mon["is_starter"] for mon in unknown))


class HmFieldUseTests(unittest.TestCase):
    def setUp(self):
        self.ready = {name: {"field_ready": True} for name in ("cut", "surf", "strength")}
        self.seen = set()

    def test_cut_tree_success_only(self):
        old = {"tile_in_front": 0x3D, "x": 10, "y": 8, "map": 4, "direction": 12}
        current = {"cut_tile": 0x3D, "action_result": 1, "surf_state": 0, "boulder_pushed": False}
        events = detect_hm_field_events(old, current, 4, self.ready, False, self.seen)
        self.assertEqual(events, ["cut_tree"])
        self.assertEqual(detect_hm_field_events(old, current, 4, self.ready, False, self.seen), [])

    def test_cut_grass_and_reject_failed_or_unready_attempt(self):
        old = {"tile_in_front": 0x52, "x": 4, "y": 5, "map": 2, "direction": 0}
        failed = {"cut_tile": 0x52, "action_result": 0, "surf_state": 0, "boulder_pushed": False}
        self.assertEqual(detect_hm_field_events(old, failed, 4, self.ready, False, self.seen), [])
        current = dict(failed, action_result=1)
        not_ready = dict(self.ready, cut={"field_ready": False})
        self.assertEqual(detect_hm_field_events(old, current, 4, not_ready, False, self.seen), [])
        self.assertEqual(detect_hm_field_events(old, current, 4, self.ready, False, self.seen), ["cut_grass"])

    def test_surf_requires_transition_and_is_unique_per_map(self):
        old = {"surf_state": 0, "map": 10}
        current = {"surf_state": 2, "map": 10}
        self.assertEqual(detect_hm_field_events(old, current, 0, self.ready, False, self.seen), ["surf_start"])
        self.assertEqual(detect_hm_field_events(current, current, 0, self.ready, False, self.seen), [])
        old2 = {"surf_state": 0, "map": 11}
        current2 = {"surf_state": 2, "map": 11}
        self.assertEqual(detect_hm_field_events(old2, current2, 0, self.ready, False, self.seen), ["surf_start"])

    def test_strength_requires_success_latch_or_bit_edge_and_field_readiness(self):
        old = {"boulder_pushed": False, "map": 7, "x": 9, "y": 3}
        current = {"boulder_pushed": False, "map": 7, "x": 10, "y": 3, "surf_state": 0}
        self.assertEqual(detect_hm_field_events(old, current, 2, self.ready, True, self.seen), ["strength_boulder"])
        not_ready = dict(self.ready, strength={"field_ready": False})
        self.assertEqual(detect_hm_field_events(old, current, 2, not_ready, True, set()), [])


if __name__ == "__main__":
    unittest.main()
