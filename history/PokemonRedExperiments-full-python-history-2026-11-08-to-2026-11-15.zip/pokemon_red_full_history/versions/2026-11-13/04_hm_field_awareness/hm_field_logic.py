"""Pure helpers for Red/Blue HM assignment and successful field-use detection.

Kept free of PyBoy/Gym dependencies so the decision logic can be unit-tested.
"""

CUT_TREE_TILE = 0x3D
CUT_GRASS_TILE = 0x52
CUT_GYM_TREE_TILE = 0x50
CUTTABLE_TILES = frozenset({CUT_TREE_TILE, CUT_GRASS_TILE, CUT_GYM_TREE_TILE})


def classify_party_starters(records, starter_signature=None, starter_species_known=False):
    """Return shallow-copied party records tagged with ``is_starter``.

    OT ID + DVs are used as a stable identity across evolutions and party
    reordering. If that signature is unavailable, fall back to slot one only
    when the environment has positively identified a starter species.
    """
    tagged = []
    for index, record in enumerate(records):
        item = dict(record)
        signature = item.get("identity_signature")
        if starter_signature is not None and signature is not None:
            is_starter = tuple(signature) == tuple(starter_signature)
        else:
            is_starter = bool(starter_species_known and index == 0)
        item["is_starter"] = bool(is_starter)
        tagged.append(item)
    return tagged


def detect_hm_field_events(previous, current, action, hm_status, strength_push_latched, seen):
    """Return fresh, confirmed field-use event names and remember their keys.

    ``previous`` is the memory snapshot from immediately before the action;
    ``current`` is the post-action snapshot. Event keys suppress repeated
    shaping for the same obstacle/map within one worker lifetime.
    """
    events = []

    def ready(name):
        return bool(hm_status.get(name, {}).get("field_ready", False))

    # UsedCut stores the tile it cut and sets wActionResultOrTookBattleTurn=1.
    # The front-tile sample is taken before the action because the tile map is
    # redrawn as soon as Cut succeeds.
    front_tile = int(previous.get("tile_in_front", 0))
    cut_tile = int(current.get("cut_tile", 0))
    if (
        int(action) == 4
        and ready("cut")
        and int(current.get("action_result", 0)) == 1
        and front_tile in CUTTABLE_TILES
        and cut_tile == front_tile
    ):
        x = int(previous.get("x", current.get("x", 0)))
        y = int(previous.get("y", current.get("y", 0)))
        map_id = int(previous.get("map", current.get("map", 0)))
        direction = int(previous.get("direction", 0))
        key = ("cut", map_id, x, y, direction, front_tile)
        if key not in seen:
            seen.add(key)
            if front_tile == CUT_GRASS_TILE:
                events.append("cut_grass")
            elif front_tile == CUT_GYM_TREE_TILE:
                events.append("cut_gym_tree")
            else:
                events.append("cut_tree")

    # A transition into the game's Surfing state is stronger evidence than
    # merely owning Surf or having the move in the party.
    if (
        ready("surf")
        and int(previous.get("surf_state", 0)) != 2
        and int(current.get("surf_state", 0)) == 2
    ):
        map_id = int(current.get("map", 0))
        key = ("surf", map_id)
        if key not in seen:
            seen.add(key)
            events.append("surf_start")

    # The game sets BIT_PUSHED_BOULDER in wMiscFlags when a boulder is moved.
    # The frame-level latch catches the bit even when a map script clears it
    # before the normal post-action snapshot.
    boulder_edge = (
        not bool(previous.get("boulder_pushed", False))
        and bool(current.get("boulder_pushed", False))
    )
    if ready("strength") and (bool(strength_push_latched) or boulder_edge):
        key = (
            "strength",
            int(current.get("map", 0)),
            int(current.get("x", 0)),
            int(current.get("y", 0)),
        )
        if key not in seen:
            seen.add(key)
            events.append("strength_boulder")

    return events
