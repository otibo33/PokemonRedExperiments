"""Robust Pokémon Red TensorBoard callback.

Preserves the user's original TensorboardCallback name and histogram/stat
logs. Fixes terminal-episode capture for SB3 VecEnv auto-resets and maintains
cumulative exploration maps/progression across episode resets and process
restarts (provided the same log_dir is reused).

No gameplay screenshots are logged. No rewards, policy observations, or
training actions are changed by this callback.
"""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any

import numpy as np
from einops import rearrange, reduce
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.logger import Image
from torch.utils.tensorboard import SummaryWriter


def merge_dicts(dicts):
    """Return numeric means and distributions, ignoring non-numeric fields."""
    values_by_key: dict[str, list[float]] = {}
    for item in dicts:
        if not isinstance(item, dict):
            continue
        for key, value in item.items():
            if isinstance(value, (int, float, np.number)) and not isinstance(value, (bool, np.bool_)):
                values_by_key.setdefault(key, []).append(float(value))

    means = {key: float(np.mean(values)) for key, values in values_by_key.items()}
    distributions = {
        key: np.asarray(values, dtype=np.float32)
        for key, values in values_by_key.items()
    }
    return means, distributions


def _as_uint8_map(value: Any, expected_shape: tuple[int, int] | None = None):
    if value is None:
        return None
    array = np.asarray(value)
    if array.ndim != 2:
        return None
    if expected_shape is not None and tuple(array.shape) != tuple(expected_shape):
        return None
    return np.ascontiguousarray(np.clip(array, 0, 255), dtype=np.uint8)


def _make_map_mosaic(maps: np.ndarray) -> np.ndarray:
    """Arrange N HxW maps in a roughly square grid; supports any N >= 1."""
    maps = np.asarray(maps, dtype=np.uint8)
    if maps.ndim != 3 or maps.shape[0] < 1:
        raise ValueError(f"Expected NxHxW maps, got {maps.shape}")
    count, height, width = maps.shape
    columns = int(math.ceil(math.sqrt(count)))
    rows = int(math.ceil(count / columns))
    canvas = np.zeros((rows * height, columns * width), dtype=np.uint8)
    for index, item in enumerate(maps):
        row, column = divmod(index, columns)
        canvas[
            row * height:(row + 1) * height,
            column * width:(column + 1) * width,
        ] = item
    return canvas


def _nearest_neighbor_scale(image: np.ndarray, scale: int) -> np.ndarray:
    if scale <= 1:
        return np.ascontiguousarray(image, dtype=np.uint8)
    return np.ascontiguousarray(
        np.repeat(np.repeat(image, scale, axis=0), scale, axis=1),
        dtype=np.uint8,
    )


class TensorboardCallback(BaseCallback):
    """Keep the original callback API while preserving complete map history.

    Existing use remains valid:
        TensorboardCallback(log_dir)
        TensorboardCallback(log_dir, verbose=1)

    Args:
        log_dir: Existing run/session directory. A `_trajectory_history`
            subdirectory is created here to persist map history between runs.
        verbose: Stable-Baselines3 callback verbosity.
        map_image_scale: Nearest-neighbour visual enlargement (default 2).
        scalar_log_every: Aggregate environment timesteps between progress
            scalar updates (default 2560).
    """

    def __init__(
        self,
        log_dir,
        verbose=0,
        map_image_scale=2,
        scalar_log_every=2560,
        map_log_every=10000,
    ):
        super().__init__(verbose=verbose)
        self.log_dir = Path(log_dir).expanduser()
        self.writer = None
        self.map_image_scale = int(map_image_scale)
        self.scalar_log_every = int(scalar_log_every)
        self.map_log_every = int(map_log_every)
        if self.map_image_scale < 1:
            raise ValueError("map_image_scale must be a positive integer")
        if self.scalar_log_every < 1:
            raise ValueError("scalar_log_every must be a positive integer")
        if self.map_log_every < 1:
            raise ValueError("map_log_every must be a positive integer")

        self.history_dir = self.log_dir / "_trajectory_history"
        self.maps_path = self.history_dir / "worker_exploration_maps.npz"
        self.metadata_path = self.history_dir / "progress_metadata.json"
        self.worker_maps: np.ndarray | None = None
        self.map_shape: tuple[int, int] | None = None
        self.best_map_progress = -1
        self.best_map_id = -1
        self.episodes_completed = 0
        self.event_flags: dict[str, str] = {}
        self._last_scalar_log_timestep = 0
        self._last_map_log_timestep = 0
        self._warned_missing_snapshot = False

    def _on_training_start(self) -> None:
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.history_dir.mkdir(parents=True, exist_ok=True)
        self.writer = SummaryWriter(log_dir=str(self.log_dir / "histogram"))

        # Discover the fixed global map dimensions from the environments.
        try:
            existing_maps = self.training_env.get_attr("lifetime_explore_map")
            if existing_maps:
                first = np.asarray(existing_maps[0])
                if first.ndim == 2:
                    self.map_shape = tuple(int(v) for v in first.shape)
        except Exception:
            # We still support legacy environments for statistics. The
            # terminal-map tags require the patched red_gym_env_v2.py.
            self.map_shape = None

        self._load_persisted_history()

    def _load_persisted_history(self) -> None:
        n_envs = int(self.training_env.num_envs)
        self.worker_maps = None

        if self.maps_path.exists():
            try:
                with np.load(self.maps_path, allow_pickle=False) as saved:
                    old_maps = np.asarray(saved["worker_maps"], dtype=np.uint8)
                if old_maps.ndim == 3 and old_maps.shape[0] > 0:
                    if self.map_shape is None:
                        self.map_shape = tuple(int(v) for v in old_maps.shape[1:])
                    if tuple(old_maps.shape[1:]) == tuple(self.map_shape):
                        if old_maps.shape[0] == n_envs:
                            self.worker_maps = old_maps.copy()
                        else:
                            # If worker count changes, keep the complete prior
                            # union by seeding each new worker with that union.
                            merged = np.max(old_maps, axis=0)
                            self.worker_maps = np.repeat(merged[None, :, :], n_envs, axis=0)
            except Exception as exc:
                self._warn(f"Could not load saved exploration maps ({exc}); starting map history empty.")

        if self.worker_maps is None and self.map_shape is not None:
            self.worker_maps = np.zeros((n_envs, *self.map_shape), dtype=np.uint8)

        if self.metadata_path.exists():
            try:
                metadata = json.loads(self.metadata_path.read_text(encoding="utf-8"))
                self.best_map_progress = int(metadata.get("best_map_progress", -1))
                self.best_map_id = int(metadata.get("best_map_id", -1))
                self.episodes_completed = int(metadata.get("episodes_completed", 0))
                flags = metadata.get("event_flags", {})
                if isinstance(flags, dict):
                    self.event_flags = {str(k): str(v) for k, v in flags.items()}
            except Exception as exc:
                self._warn(f"Could not load progress metadata ({exc}); starting metadata fresh.")

    def _save_persisted_history(self) -> None:
        if self.worker_maps is not None:
            temp_path = self.maps_path.with_suffix(".npz.tmp")
            with temp_path.open("wb") as handle:
                np.savez_compressed(handle, worker_maps=self.worker_maps)
            os.replace(temp_path, self.maps_path)

        metadata = {
            "best_map_progress": int(self.best_map_progress),
            "best_map_id": int(self.best_map_id),
            "episodes_completed": int(self.episodes_completed),
            "event_flags": self.event_flags,
        }
        temp_meta = self.metadata_path.with_suffix(".json.tmp")
        temp_meta.write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")
        os.replace(temp_meta, self.metadata_path)

    def _warn(self, message: str) -> None:
        # Use plain stdout so this remains compatible with SB3 logger versions
        # that do not expose a Logger.warn() method.
        print(f"[TensorboardCallback] WARNING: {message}")

    def _get_infos_and_dones(self):
        infos = self.locals.get("infos", ())
        dones = self.locals.get("dones", ())
        if infos is None:
            infos = ()
        if dones is None:
            dones = ()
        try:
            dones = np.asarray(dones, dtype=bool).reshape(-1)
        except Exception:
            dones = np.zeros(len(infos), dtype=bool)
        return list(infos), dones

    def _update_maps_from_envs(self, infos, dones):
        n_envs = int(self.training_env.num_envs)
        if self.worker_maps is None:
            try:
                raw = self.training_env.get_attr("lifetime_explore_map")
                first = _as_uint8_map(raw[0])
                if first is None:
                    return []
                self.map_shape = tuple(first.shape)
                self.worker_maps = np.zeros((n_envs, *self.map_shape), dtype=np.uint8)
            except Exception as exc:
                self._warn(f"Environment does not expose lifetime_explore_map: {exc}")
                return []

        episode_maps = []
        snapshots_seen = 0
        for index in range(min(n_envs, len(infos), len(dones))):
            info = infos[index] if isinstance(infos[index], dict) else {}
            worker_best = info.get("best_map_progress")
            if isinstance(worker_best, (int, float, np.number)) and int(worker_best) > self.best_map_progress:
                self.best_map_progress = int(worker_best)
                self.best_map_id = int(info.get("best_map_id", info.get("map_id", -1)))
            if not dones[index]:
                continue
            snapshot = info.get("episode_snapshot")
            if not isinstance(snapshot, dict):
                continue
            snapshots_seen += 1

            episode_map = _as_uint8_map(snapshot.get("explore_map"), self.map_shape)
            lifetime_map = _as_uint8_map(snapshot.get("lifetime_explore_map"), self.map_shape)
            if episode_map is not None:
                episode_maps.append(episode_map)
            if lifetime_map is not None:
                self.worker_maps[index] = np.maximum(self.worker_maps[index], lifetime_map)
            elif episode_map is not None:
                self.worker_maps[index] = np.maximum(self.worker_maps[index], episode_map)

            stats = snapshot.get("agent_stats")
            if isinstance(stats, dict) and stats:
                self._completed_episode_stats.append(stats)

            progress = int(snapshot.get("best_map_progress", snapshot.get("map_progress", -1)))
            if progress > self.best_map_progress:
                self.best_map_progress = progress
                self.best_map_id = int(snapshot.get("best_map_id", snapshot.get("map_id", -1)))

            self.episodes_completed += 1
            flags = snapshot.get("lifetime_event_flags", snapshot.get("event_flags", {}))
            if isinstance(flags, dict):
                self.event_flags.update({str(k): str(v) for k, v in flags.items()})

        # Pull current cumulative maps from all workers. A completed worker has
        # already auto-reset, but its lifetime map intentionally survives reset.
        try:
            current_maps = self.training_env.get_attr("lifetime_explore_map")
            for index, raw_map in enumerate(current_maps[:n_envs]):
                current_map = _as_uint8_map(raw_map, self.map_shape)
                if current_map is not None:
                    self.worker_maps[index] = np.maximum(self.worker_maps[index], current_map)
        except Exception as exc:
            self._warn(f"Could not read lifetime maps from workers ({exc}).")

        # Fallback for a partially upgraded environment: at least collect named
        # event flags that are available after the VecEnv step.
        try:
            worker_flags = self.training_env.get_attr("lifetime_event_flags")
            for flags in worker_flags:
                if isinstance(flags, dict):
                    self.event_flags.update({str(k): str(v) for k, v in flags.items()})
        except Exception:
            pass

        if dones.size and np.any(dones) and snapshots_seen == 0 and not self._warned_missing_snapshot:
            self._warn(
                "An episode ended without info['episode_snapshot']. Replace red_gym_env_v2.py "
                "with the paired update; otherwise SB3's auto-reset can erase terminal maps before logging."
            )
            self._warned_missing_snapshot = True

        return episode_maps

    def _log_completed_episode_stats(self) -> None:
        if not self._completed_episode_stats:
            return
        means, distributions = merge_dicts(self._completed_episode_stats)
        for key, value in means.items():
            self.logger.record(f"env_stats/{key}", value)
        if self.writer is not None:
            for key, values in distributions.items():
                self.writer.add_histogram(
                    f"env_stats_distribs/{key}", values, self.num_timesteps
                )
                self.logger.record(f"env_stats_max/{key}", float(np.max(values)))
        self._completed_episode_stats.clear()

    def _log_map_images(self, episode_maps):
        if self.worker_maps is None or self.worker_maps.size == 0:
            return

        cumulative_sum = np.max(self.worker_maps, axis=0)
        cumulative_mosaic = _make_map_mosaic(self.worker_maps)
        cumulative_sum = _nearest_neighbor_scale(cumulative_sum, self.map_image_scale)
        cumulative_mosaic = _nearest_neighbor_scale(cumulative_mosaic, self.map_image_scale)

        # Preserve the original TensorBoard image tags, now showing lifetime
        # exploration rather than appearing to lose progress after each reset.
        self.logger.record(
            "trajectory/explore_sum",
            Image(cumulative_sum, "HW"),
            exclude=("stdout", "log", "json", "csv"),
        )
        self.logger.record(
            "trajectory/explore_map",
            Image(cumulative_mosaic, "HW"),
            exclude=("stdout", "log", "json", "csv"),
        )

        # Also keep a separate view of just the episode(s) that ended on this
        # VecEnv step. This makes a high-water episode easy to distinguish from
        # the all-time cumulative map.
        if episode_maps:
            episode_array = np.stack(episode_maps, axis=0).astype(np.uint8, copy=False)
            episode_sum = np.max(episode_array, axis=0)
            episode_mosaic = _make_map_mosaic(episode_array)
            episode_sum = _nearest_neighbor_scale(episode_sum, self.map_image_scale)
            episode_mosaic = _nearest_neighbor_scale(episode_mosaic, self.map_image_scale)
            self.logger.record(
                "trajectory/episode_explore_sum",
                Image(episode_sum, "HW"),
                exclude=("stdout", "log", "json", "csv"),
            )
            self.logger.record(
                "trajectory/episode_explore_map",
                Image(episode_mosaic, "HW"),
                exclude=("stdout", "log", "json", "csv"),
            )

    def _log_progress_scalars(self, infos):
        if self.num_timesteps - self._last_scalar_log_timestep < self.scalar_log_every:
            return
        self._last_scalar_log_timestep = int(self.num_timesteps)
        progress_values = []
        best_values = []
        seen_values = []
        for info in infos:
            if not isinstance(info, dict):
                continue
            for target, key in (
                (progress_values, "map_progress"),
                (best_values, "best_map_progress"),
                (seen_values, "seen_tiles"),
            ):
                value = info.get(key)
                if isinstance(value, (int, float, np.number)):
                    target.append(float(value))
            worker_best = info.get("best_map_progress")
            if isinstance(worker_best, (int, float, np.number)) and int(worker_best) > self.best_map_progress:
                self.best_map_progress = int(worker_best)
                self.best_map_id = int(info.get("best_map_id", info.get("map_id", -1)))
        if progress_values:
            self.logger.record("progress/current_map_progress_mean", float(np.mean(progress_values)))
        if best_values:
            self.logger.record("progress/worker_best_map_progress_mean", float(np.mean(best_values)))
        if seen_values:
            self.logger.record("progress/current_episode_seen_tiles_mean", float(np.mean(seen_values)))
        if self.best_map_progress >= 0:
            self.logger.record("progress/best_ever_map_progress", float(self.best_map_progress))
        self.logger.record("progress/episodes_completed_total", float(self.episodes_completed))

    def _on_step(self) -> bool:
        infos, dones = self._get_infos_and_dones()
        self._log_progress_scalars(infos)

        any_done = bool(dones.size and np.any(dones))
        map_due = self.num_timesteps - self._last_map_log_timestep >= self.map_log_every
        if any_done or map_due:
            self._completed_episode_stats = []
            episode_maps = self._update_maps_from_envs(infos, dones)
            if any_done:
                self._log_completed_episode_stats()

            if self.best_map_progress >= 0:
                self.logger.record("progress/best_ever_map_progress", float(self.best_map_progress))
                self.logger.record("progress/best_map_id", float(self.best_map_id))
            self.logger.record("progress/episodes_completed_total", float(self.episodes_completed))
            self.logger.record("trajectory/all_flags", json.dumps(self.event_flags, sort_keys=True))

            self._log_map_images(episode_maps)
            self._save_persisted_history()
            self._last_map_log_timestep = int(self.num_timesteps)

        return True

    def _on_training_end(self) -> None:
        # Save current lifetime maps even if training stopped before any worker
        # reached its episode limit. This prevents a partial episode from being
        # lost when the run is resumed later.
        try:
            self._completed_episode_stats = []
            self._update_maps_from_envs([], np.zeros(int(self.training_env.num_envs), dtype=bool))
            self._save_persisted_history()
        except Exception as exc:
            self._warn(f"Could not save final exploration history ({exc}).")

        if self.writer is not None:
            self.writer.flush()
            self.writer.close()
            self.writer = None
