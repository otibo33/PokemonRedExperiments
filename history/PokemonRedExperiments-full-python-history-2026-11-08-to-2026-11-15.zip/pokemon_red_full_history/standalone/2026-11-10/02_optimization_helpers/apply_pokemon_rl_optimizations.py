#!/usr/bin/env python3
"""Safely patch the Pokémon Red RL project for lower PyBoy overhead and 2 PPO epochs.

Default project: ~/Projects/PokemonRedExperiments/v2
You can pass another project directory as the first argument.
Backups are created beside each modified file before anything is written.
"""
from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path


def replace_once(source: str, old: str, new: str, description: str) -> str:
    count = source.count(old)
    if count != 1:
        raise RuntimeError(
            f"Expected exactly one match for {description!r}, found {count}. "
            "No files have been changed."
        )
    return source.replace(old, new, 1)


def main() -> int:
    project = Path(sys.argv[1]).expanduser() if len(sys.argv) > 1 else (
        Path.home() / "Projects" / "PokemonRedExperiments" / "v2"
    )
    project = project.resolve()

    env_path = project / "red_gym_env_v2.py"
    train_path = project / "baseline_run_paralell.py"
    missing = [str(p) for p in (env_path, train_path) if not p.is_file()]
    if missing:
        print("Could not find the expected project files:", file=sys.stderr)
        for path in missing:
            print(f"  {path}", file=sys.stderr)
        print(
            "Usage: python apply_pokemon_rl_optimizations.py "
            "/path/to/PokemonRedExperiments/v2",
            file=sys.stderr,
        )
        return 2

    env_text = env_path.read_text(encoding="utf-8")
    train_text = train_path.read_text(encoding="utf-8")

    # Keep observations screen-based: render exactly the final frame needed by _get_obs().
    env_text = replace_once(
        env_text,
        '        self.pyboy = PyBoy(cfg["gb_path"], window=head)\n',
        '        self.pyboy = PyBoy(\n'
        '            cfg["gb_path"],\n'
        '            window=head,\n'
        '            sound_emulated=False,\n'
        '        )\n',
        "PyBoy constructor",
    )

    old_action = '''    def run_action_on_emulator(self, action):
        # press the button, release it after a few ticks
        self.pyboy.send_input(self.valid_actions[action])
        render_screen = self.save_video or not self.headless
        press_step = 8
        self.pyboy.tick(press_step, render_screen)
        self.pyboy.send_input(self.release_actions[action])
        self.pyboy.tick(self.act_freq - press_step - 1, render_screen)
        self.pyboy.tick(1, True)
        if self.save_video and self.fast_video:
            self.add_video_frame()
'''
    new_action = '''    def run_action_on_emulator(self, action):
        # Keep the same action duration, but render/sample sound only when needed.
        press_step = 8
        self.pyboy.send_input(self.valid_actions[action])
        self.pyboy.tick(press_step, False, False)

        self.pyboy.send_input(self.release_actions[action])
        # Render the final frame because _get_obs() reads pyboy.screen.ndarray.
        self.pyboy.tick(self.act_freq - press_step, True, False)

        if self.save_video and self.fast_video:
            self.add_video_frame()
'''
    env_text = replace_once(
        env_text, old_action, new_action, "run_action_on_emulator method"
    )

    # Change new-model defaults. A post-branch assignment below also covers PPO.load().
    train_text = replace_once(
        train_text,
        "            n_epochs=1,\n",
        "            n_epochs=2,\n            target_kl=0.01,\n",
        "PPO constructor n_epochs setting",
    )
    train_text = replace_once(
        train_text,
        '    print("\\nModel policy:")\n',
        '    # Apply these settings to both new models and resumed checkpoints.\n'
        '    model.n_epochs = 2\n'
        '    model.target_kl = 0.01\n\n'
        '    print("\\nModel policy:")\n',
        "post-load PPO settings insertion point",
    )

    # Verify the exact intended modifications are present before writing.
    assert "sound_emulated=False" in env_text
    assert "self.pyboy.tick(press_step, False, False)" in env_text
    assert "self.pyboy.tick(self.act_freq - press_step, True, False)" in env_text
    assert "model.n_epochs = 2" in train_text
    assert "model.target_kl = 0.01" in train_text

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backups: list[tuple[Path, Path]] = []
    for path in (env_path, train_path):
        backup = path.with_name(f"{path.name}.bak-{stamp}")
        backup.write_bytes(path.read_bytes())
        backups.append((path, backup))

    try:
        env_path.write_text(env_text, encoding="utf-8")
        train_path.write_text(train_text, encoding="utf-8")
    except Exception:
        # Roll back both files if either write fails.
        for original, backup in backups:
            original.write_bytes(backup.read_bytes())
        raise

    print("Patch applied successfully.")
    print(f"Project: {project}")
    print(f"Environment: {env_path}")
    print(f"Training script: {train_path}")
    print("Backups:")
    for original, backup in backups:
        print(f"  {backup}")
    print("\nChanges:")
    print("  - PyBoy audio emulation disabled.")
    print("  - Each action keeps its frame count; only its final frame is rendered.")
    print("  - PyBoy tick audio sampling disabled.")
    print("  - PPO uses 2 epochs and target_kl=0.01, including resumed checkpoints.")
    print("\nNo checkpoints or TensorBoard files were changed.")
    print("The currently running Python process is unaffected; restart from a saved checkpoint to use this patch.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
