#!/usr/bin/env python3
"""Safely apply the PyBoy/PPO performance tweaks to a Pokémon Red RL project.

Usage:
    python apply_pokemon_rl_optimizations_v2.py /path/to/PokemonRedExperiments/v2

Creates timestamped backups before writing. It does not modify checkpoints or logs.
"""
from __future__ import annotations

import re
import sys
from datetime import datetime
from pathlib import Path


def find_call_end(source: str, open_paren: int) -> int:
    """Return the matching ')' while respecting quoted strings."""
    depth = 0
    quote: str | None = None
    triple = False
    escaped = False
    i = open_paren
    while i < len(source):
        ch = source[i]
        if quote is not None:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif triple and source.startswith(quote * 3, i):
                quote = None
                triple = False
                i += 2
            elif not triple and ch == quote:
                quote = None
        else:
            if ch in ("'", '"'):
                if source.startswith(ch * 3, i):
                    quote = ch
                    triple = True
                    i += 2
                else:
                    quote = ch
            elif ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    return i
        i += 1
    raise RuntimeError("Could not find the closing ')' for self.pyboy = PyBoy(...).")


def patch_pyboy_constructor(source: str) -> tuple[str, bool]:
    marker = "self.pyboy = PyBoy"
    positions = [m.start() for m in re.finditer(re.escape(marker), source)]
    if len(positions) != 1:
        candidates = [line.strip() for line in source.splitlines() if "PyBoy(" in line]
        raise RuntimeError(
            f"Expected one 'self.pyboy = PyBoy(...)' constructor, found {len(positions)}. "
            f"PyBoy-related lines: {candidates[:8]}"
        )

    start = positions[0]
    open_paren = source.find("(", start + len("self.pyboy = PyBoy"))
    if open_paren < 0:
        raise RuntimeError("Found self.pyboy = PyBoy but could not find its opening '('.")
    close_paren = find_call_end(source, open_paren)
    body = source[open_paren + 1:close_paren]

    if re.search(r"\bsound_emulated\s*=", body):
        if re.search(r"\bsound_emulated\s*=\s*False\b", body):
            return source, False
        raise RuntimeError("PyBoy constructor already sets sound_emulated to a different value.")

    trimmed = body.rstrip()
    trailing_ws = body[len(trimmed):]
    if not trimmed.strip():
        new_body = "sound_emulated=False" + trailing_ws
    elif trimmed.endswith(","):
        new_body = trimmed + " sound_emulated=False" + trailing_ws
    else:
        new_body = trimmed + ", sound_emulated=False" + trailing_ws
    return source[:open_paren + 1] + new_body + source[close_paren:], True


def patch_action_ticks(source: str) -> tuple[str, bool]:
    # Apply only within the named method, not elsewhere in the environment.
    method = re.search(
        r"(?m)^(?P<indent>[ \t]*)def run_action_on_emulator\(self, action\):\s*$", source
    )
    if not method:
        raise RuntimeError("Could not find run_action_on_emulator(self, action).")
    indent = method.group("indent")
    body_start = method.end()
    next_method = re.search(r"(?m)^" + re.escape(indent) + r"def\s+\w+\s*\(", source[body_start:])
    body_end = body_start + next_method.start() if next_method else len(source)
    body = source[body_start:body_end]
    changed = False

    substitutions = [
        (
            r"(?m)^(?P<i>[ \t]*)self\.pyboy\.tick\(\s*press_step\s*,\s*render_screen\s*\)\s*$",
            lambda m: m.group("i") + "self.pyboy.tick(press_step, False, False)",
            "first action tick",
        ),
        (
            r"(?m)^(?P<i>[ \t]*)self\.pyboy\.tick\(\s*self\.act_freq\s*-\s*press_step\s*-\s*1\s*,\s*render_screen\s*\)\s*$",
            lambda m: m.group("i") + "self.pyboy.tick(self.act_freq - press_step, True, False)",
            "second action tick",
        ),
        (
            r"(?m)^[ \t]*self\.pyboy\.tick\(\s*1\s*,\s*True\s*\)[ \t]*(?:\r?\n|$)",
            lambda m: "",
            "redundant final one-frame tick",
        ),
    ]
    for pattern, repl, label in substitutions:
        new_body, n = re.subn(pattern, repl, body)
        if n > 1:
            raise RuntimeError(f"Found multiple matches for {label}; refusing an ambiguous edit.")
        if n == 1:
            body = new_body
            changed = True

    # If no old calls were found, accept only if the intended optimised calls are already present.
    if not changed:
        if (
            "self.pyboy.tick(press_step, False, False)" in body
            and "self.pyboy.tick(self.act_freq - press_step, True, False)" in body
            and not re.search(r"self\.pyboy\.tick\(\s*1\s*,\s*True\s*\)", body)
        ):
            return source, False
        raise RuntimeError(
            "run_action_on_emulator was found, but its tick calls did not match the expected layout. "
            "No files have been changed; inspect that method before patching."
        )

    # Remove the now-unused render_screen assignment within this method, if present.
    body = re.sub(
        r"(?m)^[ \t]*render_screen\s*=\s*self\.save_video\s+or\s+not\s+self\.headless\s*\n",
        "",
        body,
        count=1,
    )
    return source[:body_start] + body + source[body_end:], True


def patch_training_script(source: str) -> tuple[str, bool]:
    changed = False

    # Keep the default in the PPO constructor consistent for fresh runs.
    epoch_pat = re.compile(r"(?m)^(?P<prefix>[ \t]*n_epochs\s*=\s*)1(?P<suffix>\s*,[^\n]*)?$")
    epoch_matches = list(epoch_pat.finditer(source))
    if len(epoch_matches) == 1:
        source = epoch_pat.sub(lambda m: m.group("prefix") + "2" + (m.group("suffix") or ""), source, count=1)
        changed = True
    elif len(epoch_matches) == 0:
        if not re.search(r"(?m)^\s*n_epochs\s*=\s*2\s*,?\s*$", source):
            raise RuntimeError("Could not find a unique n_epochs=1 setting (or an existing n_epochs=2).")
    else:
        raise RuntimeError(f"Found {len(epoch_matches)} n_epochs=1 settings; refusing an ambiguous edit.")

    has_epoch_assignment = re.search(r"(?m)^\s*model\.n_epochs\s*=\s*2\s*$", source)
    has_kl_assignment = re.search(r"(?m)^\s*model\.target_kl\s*=\s*0\.01\s*$", source)
    if not (has_epoch_assignment and has_kl_assignment):
        anchor = re.search(r'(?m)^(?P<i>[ \t]*)print\("\\nModel policy:"\)\s*$', source)
        if not anchor:
            raise RuntimeError('Could not find print("\\nModel policy:") insertion point after model creation.')
        indent = anchor.group("i")
        add = (
            f"{indent}# Apply optimization settings to both newly created and resumed PPO models.\n"
            f"{indent}model.n_epochs = 2\n"
            f"{indent}model.target_kl = 0.01\n\n"
        )
        source = source[:anchor.start()] + add + source[anchor.start():]
        changed = True
    return source, changed


def main() -> int:
    project = Path(sys.argv[1]).expanduser() if len(sys.argv) > 1 else (
        Path.home() / "Projects" / "PokemonRedExperiments" / "v2"
    )
    project = project.resolve()
    env_path = project / "red_gym_env_v2.py"
    train_path = project / "baseline_run_paralell.py"

    missing = [str(p) for p in (env_path, train_path) if not p.is_file()]
    if missing:
        print("Could not find the expected project files:", file=sys.stderr)
        for path in missing:
            print(f"  {path}", file=sys.stderr)
        return 2

    original_env = env_path.read_text(encoding="utf-8")
    original_train = train_path.read_text(encoding="utf-8")

    # Build and validate all edits in memory before creating backups or writing files.
    new_env, ctor_changed = patch_pyboy_constructor(original_env)
    new_env, ticks_changed = patch_action_ticks(new_env)
    new_train, train_changed = patch_training_script(original_train)

    env_changed = ctor_changed or ticks_changed
    if not env_changed and not train_changed:
        print("Everything is already patched; no files changed.")
        print(f"Project: {project}")
        return 0

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    originals = [(env_path, original_env, new_env), (train_path, original_train, new_train)]
    backups: list[tuple[Path, Path]] = []
    to_write = [(p, old, new) for p, old, new in originals if old != new]

    for path, old, new in to_write:
        backup = path.with_name(f"{path.name}.bak-{stamp}")
        backup.write_text(old, encoding="utf-8")
        backups.append((path, backup))

    written: list[tuple[Path, Path]] = []
    try:
        for path, old, new in to_write:
            path.write_text(new, encoding="utf-8")
            written.append((path, next(b for p, b in backups if p == path)))
    except Exception:
        for path, backup in written:
            path.write_bytes(backup.read_bytes())
        raise

    print("Patch applied successfully.")
    print(f"Project: {project}")
    print("Modified files:")
    for path, _, _ in to_write:
        print(f"  {path}")
    print("Backups:")
    for original, backup in backups:
        print(f"  {backup}")
    print("Changes:")
    if ctor_changed:
        print("  - Added sound_emulated=False to the PyBoy constructor.")
    if ticks_changed:
        print("  - Kept the action frame count; render only the final observation frame and skip audio sampling.")
    if train_changed:
        print("  - Set PPO to 2 epochs and target_kl=0.01, including resumed checkpoints.")
    print("No checkpoints or TensorBoard files were modified.")
    print("Restart training from your existing checkpoint to use these code changes.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"Patch aborted: {exc}", file=sys.stderr)
        print("No source files were written unless the success message appeared.", file=sys.stderr)
        raise SystemExit(1)
