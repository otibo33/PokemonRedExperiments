#!/usr/bin/env python3
"""Keep only the newest image summary for selected TensorBoard tags.

All non-image summaries (scalars, histograms, etc.) are preserved. The source
log directory is never modified. A new output directory is created with the
same event-file run structure and a copy of _trajectory_history, if present.

By default, only these party-dashboard tags are trimmed:
  - game/party_visual/env
  - game/party_visual/most_advanced

Run from the project's venv, where TensorBoard is installed:
  python trim_tensorboard_images.py runs runs_images_cleaned
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path
from typing import Iterable

DEFAULT_TAGS = (
    "game/party_visual/env",
    "game/party_visual/most_advanced",
)
EVENT_PREFIX = "events.out.tfevents."


def _load_events(path: Path):
    try:
        from tensorboard.backend.event_processing.event_file_loader import EventFileLoader
    except ImportError as exc:  # pragma: no cover - depends on user's venv
        raise RuntimeError(
            "TensorBoard is not importable. Run this script from the project's .venv."
        ) from exc
    return EventFileLoader(str(path)).Load()


def _is_target_image(value, tags: set[str], all_images: bool) -> bool:
    try:
        is_image = value.HasField("image")
    except (AttributeError, ValueError):
        is_image = False
    if not is_image:
        return False
    return all_images or value.tag in tags


def _scan_latest(event_files: list[Path], tags: set[str], all_images: bool):
    """Return latest target image location per tag, using step then file order."""
    latest: dict[str, tuple[int, int, Path, int]] = {}
    global_order = 0
    image_counts: dict[str, int] = {}
    for event_file in event_files:
        for event_index, event in enumerate(_load_events(event_file)):
            if event.HasField("summary"):
                for value_index, value in enumerate(event.summary.value):
                    if _is_target_image(value, tags, all_images):
                        tag = value.tag
                        image_counts[tag] = image_counts.get(tag, 0) + 1
                        candidate = (int(event.step), global_order, event_file, event_index)
                        previous = latest.get(tag)
                        if previous is None or candidate[:2] >= previous[:2]:
                            latest[tag] = (candidate[0], candidate[1], event_file, event_index, value_index)
                    global_order += 1
            else:
                global_order += 1
    return latest, image_counts


def _write_trimmed(
    event_files: list[Path],
    output_dir: Path,
    latest: dict[str, tuple[int, int, Path, int, int]],
    tags: set[str],
    all_images: bool,
) -> int:
    try:
        from tensorboard.summary.writer.event_file_writer import EventFileWriter
        from tensorboard.compat.proto import event_pb2
    except ImportError as exc:  # pragma: no cover - depends on user's venv
        raise RuntimeError(
            "TensorBoard is not importable. Run this script from the project's .venv."
        ) from exc

    keep_locations = {
        (str(path), event_index, value_index)
        for _step, _order, path, event_index, value_index in latest.values()
    }
    removed = 0
    output_dir.mkdir(parents=True, exist_ok=True)

    for source in event_files:
        writer = EventFileWriter(str(output_dir))
        try:
            for event_index, event in enumerate(_load_events(source)):
                if not event.HasField("summary"):
                    writer.add_event(event)
                    continue

                kept_values = []
                for value_index, value in enumerate(event.summary.value):
                    if _is_target_image(value, tags, all_images):
                        location = (str(source), event_index, value_index)
                        if location not in keep_locations:
                            removed += 1
                            continue
                    kept_values.append(value)

                # Preserve the event if it still contains any summary values.
                # Drop only summary events made empty by removing old images.
                if kept_values:
                    copied = event_pb2.Event()
                    copied.CopyFrom(event)
                    del copied.summary.value[:]
                    copied.summary.value.extend(kept_values)
                    writer.add_event(copied)
                elif not event.summary.value:
                    writer.add_event(event)
        finally:
            writer.flush()
            writer.close()
    return removed


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Keep only the newest TensorBoard image per selected tag; preserve scalars/histograms."
    )
    parser.add_argument("input_dir", type=Path, help="Existing TensorBoard log directory")
    parser.add_argument("output_dir", type=Path, help="New cleaned log directory (source remains untouched)")
    parser.add_argument(
        "--tag", action="append", dest="tags",
        help="Image tag to trim; may be repeated. Defaults to both party dashboard tags.",
    )
    parser.add_argument(
        "--all-images", action="store_true",
        help="Trim every image tag, retaining only the newest image of each tag per run directory.",
    )
    parser.add_argument(
        "--overwrite", action="store_true",
        help="Remove output_dir first if it already exists.",
    )
    args = parser.parse_args()

    source_root = args.input_dir.expanduser().resolve()
    output_root = args.output_dir.expanduser().resolve()
    if not source_root.is_dir():
        parser.error(f"Input directory does not exist: {source_root}")
    if source_root == output_root or source_root in output_root.parents:
        parser.error("Output directory must not be the input directory or inside it.")
    if output_root.exists():
        if not args.overwrite:
            parser.error(f"Output already exists: {output_root} (use --overwrite to replace it)")
        shutil.rmtree(output_root)

    tags = set(args.tags or DEFAULT_TAGS)
    event_files = sorted(
        (path for path in source_root.rglob(f"{EVENT_PREFIX}*") if path.is_file()),
        key=lambda path: (str(path.parent), path.name),
    )
    if not event_files:
        print(f"No TensorBoard event files found under {source_root}", file=sys.stderr)
        return 2

    groups: dict[Path, list[Path]] = {}
    for path in event_files:
        groups.setdefault(path.parent, []).append(path)

    try:
        total_removed = 0
        total_seen = 0
        for run_dir, files in sorted(groups.items(), key=lambda item: str(item[0])):
            relative = run_dir.relative_to(source_root)
            out_run_dir = output_root / relative
            latest, counts = _scan_latest(files, tags, args.all_images)
            removed = _write_trimmed(files, out_run_dir, latest, tags, args.all_images)
            total_removed += removed
            total_seen += sum(counts.values())
            if counts:
                kept = len(latest)
                print(f"{relative if str(relative) != '.' else '.'}: {sum(counts.values())} matching images -> {kept} latest kept; {removed} old removed")

        history = source_root / "_trajectory_history"
        if history.is_dir():
            shutil.copytree(history, output_root / "_trajectory_history", dirs_exist_ok=True)

    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    kept = total_seen - total_removed
    print("\nFinished.")
    print(f"Source (unchanged): {source_root}")
    print(f"Cleaned logs:       {output_root}")
    print(f"Target images:      {total_seen}")
    print(f"Images removed:     {total_removed}")
    print(f"Images retained:    {kept}")
    print("All non-image summaries were preserved.")
    print(f"Open TensorBoard with: tensorboard --logdir '{output_root}'")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
