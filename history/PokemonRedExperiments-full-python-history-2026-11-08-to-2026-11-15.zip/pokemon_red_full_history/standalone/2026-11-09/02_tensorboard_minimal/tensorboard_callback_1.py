"""Compatibility import for training scripts expecting TensorboardCallback.

Place this file in the same directory as tensorboard_game_image_callback.py.
The alias preserves the older class name used by baseline_run_paralell.py.
"""

from tensorboard_game_image_callback import TensorBoardGameImageCallback

# Existing training script imports this exact name (lowercase 'b' in Board).
TensorboardCallback = TensorBoardGameImageCallback

__all__ = ["TensorboardCallback", "TensorBoardGameImageCallback"]
