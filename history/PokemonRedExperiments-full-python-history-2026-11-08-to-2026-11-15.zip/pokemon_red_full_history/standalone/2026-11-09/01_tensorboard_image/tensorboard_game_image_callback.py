"""Stable-Baselines3 callback for high-resolution Pokémon Red TensorBoard images.

Import TensorBoardGameImageCallback in baseline_fast_v2.py and pass an instance
(or a CallbackList containing it) to model.learn(...).
"""

from __future__ import annotations

import numpy as np
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.logger import Image as SB3Image


class TensorBoardGameImageCallback(BaseCallback):
    """Log a full-colour, pixel-preserving screenshot from one vector env.

    The environment must expose ``get_tensorboard_frame(scale=...)``. The
    modified red_gym_env_v2.py supplied alongside this callback adds it.

    Args:
        log_freq: Log once every this many callback calls (vector steps).
        scale: Nearest-neighbour enlargement factor; 4 gives 640x576.
        env_index: Which environment to screenshot (0 is the first worker).
        tag: TensorBoard image tag.
        verbose: Stable-Baselines3 callback verbosity.
    """

    def __init__(
        self,
        log_freq: int = 2000,
        scale: int = 4,
        env_index: int = 0,
        tag: str = "gameplay/screen_4x_rgb",
        verbose: int = 0,
    ) -> None:
        super().__init__(verbose=verbose)
        if log_freq < 1:
            raise ValueError("log_freq must be >= 1")
        if scale < 1:
            raise ValueError("scale must be >= 1")
        if env_index < 0:
            raise ValueError("env_index must be >= 0")
        self.log_freq = int(log_freq)
        self.scale = int(scale)
        self.env_index = int(env_index)
        self.tag = tag

    def _on_step(self) -> bool:
        if self.n_calls % self.log_freq != 0:
            return True

        if self.training_env is None:
            return True

        try:
            frames = self.training_env.env_method(
                "get_tensorboard_frame",
                self.scale,
                indices=[self.env_index],
            )
        except Exception as exc:
            raise RuntimeError(
                "Could not fetch a TensorBoard screenshot from the training "
                "environment. Confirm that red_gym_env_v2.py contains "
                "get_tensorboard_frame() and that env_index is valid."
            ) from exc

        if not frames:
            raise RuntimeError("The selected environment returned no screenshot")

        frame = np.asarray(frames[0], dtype=np.uint8)
        if frame.ndim != 3 or frame.shape[2] != 3:
            raise ValueError(
                f"Expected an HxWx3 RGB frame; received shape {frame.shape}"
            )

        self.logger.record(
            self.tag,
            SB3Image(frame, "HWC"),
            exclude=("stdout", "log", "json", "csv"),
        )
        if self.verbose:
            self.logger.info(
                f"Logged {frame.shape[1]}x{frame.shape[0]} RGB gameplay frame "
                f"at {self.num_timesteps} timesteps"
            )
        return True

    def _on_training_end(self) -> None:
        # No resources are held between calls; nothing to clean up.
        return None
