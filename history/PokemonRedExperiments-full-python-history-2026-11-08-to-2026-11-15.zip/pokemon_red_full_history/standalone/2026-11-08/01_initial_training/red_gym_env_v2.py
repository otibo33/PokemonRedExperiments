import uuid
from pathlib import Path

import numpy as np
from skimage.transform import downscale_local_mean
import matplotlib.pyplot as plt
from pyboy import PyBoy
#from pyboy.logger import log_level
import mediapy as media
from einops import repeat

from gymnasium import Env, spaces
from pyboy.utils import WindowEvent

from global_map import local_to_global, GLOBAL_MAP_SHAPE

event_flags_start = 0xD747
event_flags_end = 0xD87E # expand for SS Anne # old - 0xD7F6 
museum_ticket = (0xD754, 0)

class RedGymEnv(Env):
    def __init__(self, config=None):
        self.s_path = config["session_path"]
        self.save_final_state = config["save_final_state"]
        self.print_rewards = config["print_rewards"]
        self.headless = config["headless"]
        self.init_state = config["init_state"]
        if isinstance(self.init_state, (str, Path)):
            self.init_states = [Path(self.init_state)]
        else:
            self.init_states = [Path(state) for state in self.init_state]
        if not self.init_states:
            raise ValueError("config['init_state'] must contain at least one save-state path")
        self.act_freq = config["action_freq"]
        self.max_steps = config["max_steps"]
        self.save_video = config["save_video"]
        self.fast_video = config["fast_video"]
        self.frame_stacks = 3
        self.explore_weight = (
            1 if "explore_weight" not in config else config["explore_weight"]
        )
        # Reward for reaching the next important story map. This setting was
        # already present in the original environment but was never used.
        self.map_progress_weight = float(config.get("map_progress_weight", 5.0))
        # A small shaping penalty encourages the agent to leave tiles where it
        # has been looping for a long time.
        self.stuck_penalty_weight = float(config.get("stuck_penalty_weight", 1.0))
        self.new_map_weight = float(config.get("new_map_weight", 0.5))
        # Keep False to preserve compatibility with existing PPO checkpoints.
        # Set True only for a fresh policy/run directory.
        self.include_navigation_obs = bool(config.get("include_navigation_obs", False))
        self.reward_scale = (
            1 if "reward_scale" not in config else config["reward_scale"]
        )
        self.instance_id = (
            str(uuid.uuid4())[:8]
            if "instance_id" not in config
            else config["instance_id"]
        )
        self.s_path.mkdir(exist_ok=True)
        self.full_frame_writer = None
        self.model_frame_writer = None
        self.map_frame_writer = None
        self.reset_count = 0
        self.all_runs = []

        self.essential_map_locations = {
            v:i for i,v in enumerate([
                40, 0, 12, 1, 13, 51, 2, 54, 14, 59, 60, 61, 15, 3, 65
            ])
        }

        # Confirmed Pokémon Red story flags supplied from this ROM/session.
        # Bit indices here follow the environment's event logger, which labels
        # bits from the left/MSB of the displayed 8-bit binary string.
        # Do not add the unidentified flags (e.g. D74A-6 / "01E") until their
        # meaning has been confirmed.
        self.story_milestones = {
            (0xD74B, 7): ("Oak appeared in Pallet", 1.0),
            (0xD74B, 0): ("Followed Oak into the lab", 2.0),
            (0xD74B, 2): ("Got starter Pokémon", 5.0),
            (0xD74B, 5): ("Got Pokédex", 4.0),
            (0xD74B, 4): ("Got Poké Balls from Oak", 4.0),
            (0xD74B, 6): ("Returned to Pallet after getting Poké Balls", 2.0),
            (0xD7EB, 7): ("Route 22 rival wants battle", 3.0),
            (0xD7EB, 0): ("Completed first Route 22 rival battle", 6.0),
            (0xD7F3, 3): ("Beat Viridian Forest trainer 1", 4.0),
            (0xD7F3, 4): ("Beat Viridian Forest trainer 2", 4.0),
        }

        # Set this in SOME subclasses
        self.metadata = {"render.modes": []}
        # This environment has both positive shaping rewards and a stuck penalty.
        self.reward_range = (-np.inf, np.inf)

        self.valid_actions = [
            WindowEvent.PRESS_ARROW_DOWN,
            WindowEvent.PRESS_ARROW_LEFT,
            WindowEvent.PRESS_ARROW_RIGHT,
            WindowEvent.PRESS_ARROW_UP,
            WindowEvent.PRESS_BUTTON_A,
            WindowEvent.PRESS_BUTTON_B,
            WindowEvent.PRESS_BUTTON_START,
        ]

        self.release_actions = [
            WindowEvent.RELEASE_ARROW_DOWN,
            WindowEvent.RELEASE_ARROW_LEFT,
            WindowEvent.RELEASE_ARROW_RIGHT,
            WindowEvent.RELEASE_ARROW_UP,
            WindowEvent.RELEASE_BUTTON_A,
            WindowEvent.RELEASE_BUTTON_B,
            WindowEvent.RELEASE_BUTTON_START
        ]

        self.output_shape = (72, 80, self.frame_stacks)
        self.coords_pad = 12

        # Set these in ALL subclasses
        self.action_space = spaces.Discrete(len(self.valid_actions))
        
        self.enc_freqs = 8

        observation_spaces = {
            "screens": spaces.Box(low=0, high=255, shape=self.output_shape, dtype=np.uint8),
            # Preserve the original checkpoint's scalar Box definition.
            # The old code declared Box(low=0, high=1) with shape=(),
            # even though it returned a one-element array. Returning a scalar
            # here makes observations valid without changing the policy's
            # flattened input width (still one feature).
            "health": spaces.Box(low=0.0, high=1.0, dtype=np.float32),
            "level": spaces.Box(
                low=-1.0, high=1.0,
                shape=(self.enc_freqs,), dtype=np.float32
            ),
            "badges": spaces.MultiBinary(8),
            "events": spaces.MultiBinary((event_flags_end - event_flags_start) * 8),
            "map": spaces.Box(low=0, high=255, shape=(
                self.coords_pad*4,self.coords_pad*4, 1), dtype=np.uint8),
            "recent_actions": spaces.MultiDiscrete([len(self.valid_actions)] * self.frame_stacks)
        }
        if self.include_navigation_obs:
            observation_spaces.update({
                "map_id": spaces.Discrete(256),
                "extras": spaces.Box(low=0.0, high=1.0, shape=(3,), dtype=np.float32),
            })
        self.observation_space = spaces.Dict(observation_spaces)

        head = "null" if config["headless"] else "SDL2"

        #log_level("ERROR")
        self.pyboy = PyBoy(
            config["gb_path"],
            #debugging=False,
            #disable_input=False,
            window=head,
        )

        #self.screen = self.pyboy.botsupport_manager().screen()

        if not config["headless"]:
            self.pyboy.set_emulation_speed(6)

    def reset(self, seed=None, options=None):
        # Gymnasium uses this to initialize its RNG and keep reset API compliant.
        super().reset(seed=seed)
        options = options or {}
        # Training samples start states from the seeded RNG. The explicit
        # index option is provided for smoke tests so every configured state
        # can be tested deterministically once.
        if "start_state_index" in options:
            state_index = int(options["start_state_index"])
            if not 0 <= state_index < len(self.init_states):
                raise IndexError(
                    f"start_state_index {state_index} is outside "
                    f"0..{len(self.init_states) - 1}"
                )
        else:
            state_index = int(self.np_random.integers(len(self.init_states)))
        start_state = self.init_states[state_index]
        self.current_start_state = start_state
        with start_state.open("rb") as f:
            self.pyboy.load_state(f)

        self.init_map_mem()

        # Keep only the latest snapshot; callbacks generally consume stats[-1].
        self.agent_stats = []
        self.visited_maps = set()
        self._hp_fraction_cache = None

        self.explore_map_dim = GLOBAL_MAP_SHAPE
        self.explore_map = np.zeros(self.explore_map_dim, dtype=np.uint8)

        self.recent_screens = np.zeros( self.output_shape, dtype=np.uint8)
        
        self.recent_actions = np.zeros((self.frame_stacks,), dtype=np.uint8)

        self.levels_satisfied = False
        self.base_explore = 0
        self.max_opponent_level = 0
        self.max_event_rew = 0
        self.max_level_rew = 0
        self.last_health = 1
        self.total_healing_rew = 0
        self.died_count = 0
        self.party_size = 0
        self.step_count = 0

        # Read event memory once. The same cached bytes are used by the reward
        # calculation and observation, avoiding two full RAM scans per step.
        self.refresh_event_cache()
        self.base_event_flags = sum(
            self.bit_count(int(value)) for value in self._event_cache
        )
        # Milestones already set in init_state are part of the starting state,
        # not new achievements for this episode.
        self.base_story_milestone_score = self.get_story_milestone_score()

        # Establish HP/party baselines from the loaded save state, not placeholder
        # values. This makes healing detection correct from the first action and
        # for later milestone save-state starts.
        self.last_health = self.read_hp_fraction(refresh=True)
        self.party_size = self.read_m(0xD163)

        self.out_of_bounds_coords = 0

        # experiment! 
        # self.max_steps += 128

        self.max_map_progress = 0
        # Include the initial tile/map in the episode's baseline. This prevents
        # the first action from receiving a misleading exploration bonus.
        self.update_map_progress()
        self.update_seen_coords()
        self.update_explore_map()
        self.progress_reward = self.get_game_state_reward()
        self.total_reward = sum([val for _, val in self.progress_reward.items()])
        self.reset_count += 1
        return self._get_obs(), {}

    def init_map_mem(self):
        self.seen_coords = {}

    def render(self, reduce_res=True):
        game_pixels_render = self.pyboy.screen.ndarray[:,:,0:1]  # (144, 160, 3)
        if reduce_res:
            game_pixels_render = (
                downscale_local_mean(game_pixels_render, (2,2,1))
            ).astype(np.uint8)
        return game_pixels_render
    
    def _get_obs(self):
        
        screen = self.render()

        self.update_recent_screens(screen)
        
        # normalize to approx 0-1
        level_sum = 0.02 * sum([
            self.read_m(a) for a in [0xD18C, 0xD1B8, 0xD1E4, 0xD210, 0xD23C, 0xD268]
        ])

        observation = {
            "screens": self.recent_screens,
            "health": np.float32(self.read_hp_fraction()),
            "level": self.fourier_encode(level_sum),
            "badges": np.array([int(bit) for bit in f"{self.read_m(0xD356):08b}"], dtype=np.int8),
            "events": np.array(self.read_event_bits(), dtype=np.int8),
            "map": self.get_explore_map()[:, :, None],
            "recent_actions": self.recent_actions
        }
        if self.include_navigation_obs:
            progress_denominator = max(len(self.essential_map_locations) - 1, 1)
            observation["map_id"] = int(np.clip(self.read_m(0xD35E), 0, 255))
            observation["extras"] = np.asarray([
                self.get_current_coord_count_reward(),
                float(self.read_m(0xD057) != 0),
                float(np.clip(self.max_map_progress / progress_denominator, 0.0, 1.0)),
            ], dtype=np.float32)

        return observation

    def step(self, action):

        if self.save_video and self.step_count == 0:
            self.start_video()

        self.run_action_on_emulator(action)
        self.refresh_event_cache()

        self.update_recent_actions(action)

        self.update_seen_coords()

        self.update_explore_map()

        current_hp_fraction = self.read_hp_fraction(refresh=True)
        self.update_heal_reward(current_hp_fraction)

        self.party_size = self.read_m(0xD163)
        self.last_health = current_hp_fraction

        # Update progression BEFORE calculating the reward.
        self.update_map_progress()

        new_reward = self.update_reward()
        # Record the post-action state and the progression values just rewarded.
        self.append_agent_stats(action)

        step_limit_reached = self.check_if_done()

        obs = self._get_obs()

        # self.save_and_print_info(step_limit_reached, obs)

        current_map = self.get_game_coords()[2]
        active_milestones = self.get_active_story_milestones()
        info = {
            "map_progress": int(self.max_map_progress),
            "map_id": int(current_map),
            "seen_tiles": int(len(self.seen_coords)),
            "visited_maps": int(len(self.visited_maps)),
            "badges": int(self.get_badges()),
            "events": int(self.get_all_events_reward()),
            "levels_sum": int(self.get_levels_sum()),
            "deaths": int(self.died_count),
            "story_milestones": active_milestones,
            "story_milestone_score": float(self.get_story_milestone_score()),
        }

        self.step_count += 1

        return obs, new_reward, False, step_limit_reached, info
    
    def run_action_on_emulator(self, action):
        # press button then release after some steps
        self.pyboy.send_input(self.valid_actions[action])
        # disable rendering when we don't need it
        render_screen = self.save_video or not self.headless
        press_step = 8
        self.pyboy.tick(press_step, render_screen)
        self.pyboy.send_input(self.release_actions[action])
        self.pyboy.tick(self.act_freq - press_step - 1, render_screen)
        self.pyboy.tick(1, True)
        if self.save_video and self.fast_video:
            self.add_video_frame()
        
    def append_agent_stats(self, action):
        x_pos, y_pos, map_n = self.get_game_coords()
        levels = [
            self.read_m(a) for a in [0xD18C, 0xD1B8, 0xD1E4, 0xD210, 0xD23C, 0xD268]
        ]
        latest_stats = {
                "step": self.step_count,
                "x": x_pos,
                "y": y_pos,
                "map": map_n,
                "max_map_progress": self.max_map_progress,
                "map_progress_reward": self.progress_reward.get("map_progress", 0.0),
                "story_milestone_reward": self.progress_reward.get("story_milestone", 0.0),
                "last_action": action,
                "pcount": self.read_m(0xD163),
                "levels": levels,
                "levels_sum": sum(levels),
                "ptypes": self.read_party(),
                "hp": self.read_hp_fraction(),
                "coord_count": len(self.seen_coords),
                "deaths": self.died_count,
                "badge": self.get_badges(),
                "event": self.progress_reward["event"],
                "healr": self.total_healing_rew,
            }
        self.agent_stats = [latest_stats]

    def start_video(self):

        if self.full_frame_writer is not None:
            self.full_frame_writer.close()
        if self.model_frame_writer is not None:
            self.model_frame_writer.close()
        if self.map_frame_writer is not None:
            self.map_frame_writer.close()

        base_dir = self.s_path / Path("rollouts")
        base_dir.mkdir(exist_ok=True)
        full_name = Path(
            f"full_reset_{self.reset_count}_id{self.instance_id}"
        ).with_suffix(".mp4")
        model_name = Path(
            f"model_reset_{self.reset_count}_id{self.instance_id}"
        ).with_suffix(".mp4")
        self.full_frame_writer = media.VideoWriter(
            base_dir / full_name, (144, 160), fps=60, input_format="gray"
        )
        self.full_frame_writer.__enter__()
        self.model_frame_writer = media.VideoWriter(
            base_dir / model_name, self.output_shape[:2], fps=60, input_format="gray"
        )
        self.model_frame_writer.__enter__()
        map_name = Path(
            f"map_reset_{self.reset_count}_id{self.instance_id}"
        ).with_suffix(".mp4")
        self.map_frame_writer = media.VideoWriter(
            base_dir / map_name,
            (self.coords_pad*4, self.coords_pad*4), 
            fps=60, input_format="gray"
        )
        self.map_frame_writer.__enter__()

    def add_video_frame(self):
        self.full_frame_writer.add_image(
            self.render(reduce_res=False)[:,:,0]
        )
        self.model_frame_writer.add_image(
            self.render(reduce_res=True)[:,:,0]
        )
        self.map_frame_writer.add_image(
            self.get_explore_map()
        )

    def get_game_coords(self):
        return (self.read_m(0xD362), self.read_m(0xD361), self.read_m(0xD35E))

    def update_seen_coords(self):
        # if not in battle
        if self.read_m(0xD057) == 0:
            x_pos, y_pos, map_n = self.get_game_coords()
            coord_string = f"x:{x_pos} y:{y_pos} m:{map_n}"
            if coord_string in self.seen_coords.keys():
                self.seen_coords[coord_string] += 1
            else:
                self.seen_coords[coord_string] = 1
            #self.seen_coords[coord_string] = self.step_count

    def get_current_coord_count_reward(self):
        """Return a 0..1 penalty intensity for repeatedly staying on one tile.

        The old threshold of 600 actions was so high that it rarely helped the
        agent escape an early loop. The penalty now ramps up after 10 visits and
        reaches its cap at 50 visits. It is a state-potential term, so moving to
        a less-visited tile gives some reward back.
        """
        x_pos, y_pos, map_n = self.get_game_coords()
        coord_string = f"x:{x_pos} y:{y_pos} m:{map_n}"
        count = self.seen_coords.get(coord_string, 0)
        return float(np.clip((count - 10) / 40.0, 0.0, 1.0))

    def get_global_coords(self):
        x_pos, y_pos, map_n = self.get_game_coords()
        return local_to_global(y_pos, x_pos, map_n)

    def update_explore_map(self):
        r, c = self.get_global_coords()
        height, width = self.explore_map.shape
        if 0 <= r < height and 0 <= c < width:
            self.explore_map[r, c] = 255
        else:
            # Avoid printing on every step if a map coordinate is unmapped.
            self.out_of_bounds_coords += 1

    def get_explore_map(self):
        """Return a fixed-size, zero-padded local map around the player.

        The old NumPy slice could become smaller than 24x24 near a map edge
        (or behave unexpectedly for negative indices), violating the declared
        observation shape. This implementation always returns 48x48.
        """
        r, c = self.get_global_coords()
        height, width = self.explore_map.shape
        size = self.coords_pad * 2
        out = np.zeros((size, size), dtype=np.uint8)

        if not (0 <= r < height and 0 <= c < width):
            return out.repeat(2, axis=0).repeat(2, axis=1)

        src_r0 = max(r - self.coords_pad, 0)
        src_r1 = min(r + self.coords_pad, height)
        src_c0 = max(c - self.coords_pad, 0)
        src_c1 = min(c + self.coords_pad, width)

        dst_r0 = src_r0 - (r - self.coords_pad)
        dst_c0 = src_c0 - (c - self.coords_pad)
        out[
            dst_r0:dst_r0 + (src_r1 - src_r0),
            dst_c0:dst_c0 + (src_c1 - src_c0),
        ] = self.explore_map[src_r0:src_r1, src_c0:src_c1]

        return out.repeat(2, axis=0).repeat(2, axis=1)
    
    def update_recent_screens(self, cur_screen):
        self.recent_screens = np.roll(self.recent_screens, 1, axis=2)
        self.recent_screens[:, :, 0] = cur_screen[:,:, 0]

    def update_recent_actions(self, action):
        self.recent_actions = np.roll(self.recent_actions, 1)
        self.recent_actions[0] = action

    def update_reward(self):
        # compute reward
        self.progress_reward = self.get_game_state_reward()
        new_total = sum(
            [val for _, val in self.progress_reward.items()]
        )
        new_step = new_total - self.total_reward

        self.total_reward = new_total
        return new_step

    def group_rewards(self):
        prog = self.progress_reward
        # These values are only used by the recurrent policy's reward memory.
        scale = max(abs(self.reward_scale), 1e-8)
        explore_scale = max(abs(self.explore_weight * self.reward_scale), 1e-8)
        return (
            prog["level"] * 100 / scale,
            self.read_hp_fraction() * 2000,
            prog["explore"] * 150 / explore_scale,
        )

    def check_if_done(self):
        done = self.step_count >= self.max_steps - 1
        # done = self.read_hp_fraction() == 0 # end game on loss
        return done

    def save_and_print_info(self, done, obs):
        if self.print_rewards:
            prog_string = f"step: {self.step_count:6d}"
            for key, val in self.progress_reward.items():
                prog_string += f" {key}: {val:5.2f}"
            prog_string += f" sum: {self.total_reward:5.2f}"
            print(f"\r{prog_string}", end="", flush=True)

        if self.step_count % 50 == 0:
            plt.imsave(
                self.s_path / Path(f"curframe_{self.instance_id}.jpeg"),
                self.render(reduce_res=False)[:,:, 0],
            )

        if self.print_rewards and done:
            print("", flush=True)
            if self.save_final_state:
                fs_path = self.s_path / Path("final_states")
                fs_path.mkdir(exist_ok=True)
                plt.imsave(
                    fs_path
                    / Path(
                        f"frame_r{self.total_reward:.4f}_{self.reset_count}_explore_map.jpeg"
                    ),
                    obs["map"][:,:, 0],
                )
                plt.imsave(
                    fs_path
                    / Path(
                        f"frame_r{self.total_reward:.4f}_{self.reset_count}_full_explore_map.jpeg"
                    ),
                    self.explore_map,
                )
                plt.imsave(
                    fs_path
                    / Path(
                        f"frame_r{self.total_reward:.4f}_{self.reset_count}_full.jpeg"
                    ),
                    self.render(reduce_res=False)[:,:, 0],
                )

        if self.save_video and done:
            self.full_frame_writer.close()
            self.model_frame_writer.close()
            self.map_frame_writer.close()

    def read_m(self, addr):
        #return self.pyboy.get_memory_value(addr)
        return self.pyboy.memory[addr]

    def read_bit(self, addr, bit: int) -> bool:
        # add padding so zero will read '0b100000000' instead of '0b0'
        return bin(256 + self.read_m(addr))[-bit - 1] == "1"

    def _read_event_bytes(self):
        # PyBoy supports contiguous memory slices; this is substantially cheaper
        # than issuing one Python-level memory read per byte.
        return np.asarray(
            self.pyboy.memory[event_flags_start:event_flags_end], dtype=np.uint8
        )

    def refresh_event_cache(self):
        self._event_cache = self._read_event_bytes()
        return self._event_cache

    def read_event_bits(self):
        # np.unpackbits defaults to MSB-first, matching the original f"{value:08b}".
        if not hasattr(self, "_event_cache"):
            self.refresh_event_cache()
        return np.unpackbits(self._event_cache).astype(np.int8)

    def get_levels_sum(self):
        min_poke_level = 2
        starter_additional_levels = 4
        poke_levels = [
            max(self.read_m(a) - min_poke_level, 0)
            for a in [0xD18C, 0xD1B8, 0xD1E4, 0xD210, 0xD23C, 0xD268]
        ]
        return max(sum(poke_levels) - starter_additional_levels, 0)

    def get_levels_reward(self):
        explore_thresh = 22
        scale_factor = 4
        level_sum = self.get_levels_sum()
        if level_sum < explore_thresh:
            scaled = level_sum
        else:
            scaled = (level_sum - explore_thresh) / scale_factor + explore_thresh
        self.max_level_rew = max(self.max_level_rew, scaled)
        return self.max_level_rew

    def get_badges(self):
        return self.bit_count(self.read_m(0xD356))

    def read_party(self):
        return [
            self.read_m(addr)
            for addr in [0xD164, 0xD165, 0xD166, 0xD167, 0xD168, 0xD169]
        ]

    def _is_event_flag_set(self, address, displayed_bit_index):
        """Read an event bit using the same MSB-first index as the event logger."""
        if not hasattr(self, "_event_cache"):
            self.refresh_event_cache()
        offset = int(address) - event_flags_start
        if offset < 0 or offset >= len(self._event_cache):
            return False
        if not 0 <= int(displayed_bit_index) <= 7:
            return False
        mask = 1 << (7 - int(displayed_bit_index))
        return bool(int(self._event_cache[offset]) & mask)

    def get_story_milestone_score(self):
        """Weighted sum of confirmed story flags currently set in RAM."""
        return float(sum(
            weight
            for (address, bit_index), (_name, weight) in self.story_milestones.items()
            if self._is_event_flag_set(address, bit_index)
        ))

    def get_active_story_milestones(self):
        """Return readable names of the confirmed story flags currently set."""
        return [
            name
            for (address, bit_index), (name, _weight) in self.story_milestones.items()
            if self._is_event_flag_set(address, bit_index)
        ]

    def get_all_events_reward(self):
        # Count cached event flags and exclude the museum ticket as before.
        if not hasattr(self, "_event_cache"):
            self.refresh_event_cache()
        event_count = int(np.unpackbits(self._event_cache).sum())
        ticket_offset = museum_ticket[0] - event_flags_start
        ticket_set = (int(self._event_cache[ticket_offset]) >> museum_ticket[1]) & 1
        return max(event_count - self.base_event_flags - ticket_set, 0)

    def get_game_state_reward(self, print_stats=False):
        # addresses from https://datacrystal.romhacking.net/wiki/Pok%C3%A9mon_Red/Blue:RAM_map
        # https://github.com/pret/pokered/blob/91dc3c9f9c8fd529bb6e8307b58b96efa0bec67e/constants/event_constants.asm
        state_scores = {
            "event": self.reward_scale * self.update_max_event_rew() * 4,
            "level": self.reward_scale * self.get_levels_reward() * 0.5,
            "heal": self.reward_scale * min(self.total_healing_rew, 0.5) * 10,
            #"op_lvl": self.reward_scale * self.update_max_op_level() * 0.2,
            #"dead": self.reward_scale * self.died_count * -0.1,
            "badge": self.reward_scale * self.get_badges() * 10,
            # Important story-map milestones. This uses the config value that
            # existed in the original file but was not connected to rewards.
            "map_progress": (
                self.reward_scale * self.map_progress_weight * self.max_map_progress
            ),
            # Small one-time bonus for each distinct map, including maps beyond
            # the hand-authored essential-map progression list.
            "new_maps": self.reward_scale * self.new_map_weight * len(self.visited_maps),
            # Extra shaping for meaningful story events. This is cumulative
            # potential; subtracting the init_state baseline below prevents
            # rewards for milestones that were already complete at reset.
            "story_milestone": (
                self.reward_scale * max(
                    self.get_story_milestone_score() - self.base_story_milestone_score,
                    0.0,
                ) * 2.0
            ),
            "explore": self.reward_scale * self.explore_weight * len(self.seen_coords) * 0.1,
            "stuck": (
                -self.reward_scale * self.stuck_penalty_weight
                * self.get_current_coord_count_reward()
            ),
        }

        return state_scores

    def update_max_op_level(self):
        opp_base_level = 5
        opponent_level = (
            max([
                self.read_m(a)
                for a in [0xD8C5, 0xD8F1, 0xD91D, 0xD949, 0xD975, 0xD9A1]
            ])
            - opp_base_level
        )
        self.max_opponent_level = max(self.max_opponent_level, opponent_level)
        return self.max_opponent_level

    def update_max_event_rew(self):
        cur_rew = self.get_all_events_reward()
        self.max_event_rew = max(cur_rew, self.max_event_rew)
        return self.max_event_rew

    def update_heal_reward(self, cur_health=None):
        if cur_health is None:
            cur_health = self.read_hp_fraction(refresh=True)
        # if health increased and party size did not change
        if cur_health > self.last_health and self.read_m(0xD163) == self.party_size:
            if self.last_health > 0:
                heal_amount = cur_health - self.last_health
                self.total_healing_rew += heal_amount * heal_amount
            else:
                self.died_count += 1

    def read_hp_fraction(self, refresh=False):
        if not refresh and self._hp_fraction_cache is not None:
            return self._hp_fraction_cache
        hp_sum = sum([
            self.read_hp(add)
            for add in [0xD16C, 0xD198, 0xD1C4, 0xD1F0, 0xD21C, 0xD248]
        ])
        max_hp_sum = sum([
            self.read_hp(add)
            for add in [0xD18D, 0xD1B9, 0xD1E5, 0xD211, 0xD23D, 0xD269]
        ])
        max_hp_sum = max(max_hp_sum, 1)
        self._hp_fraction_cache = float(hp_sum / max_hp_sum)
        return self._hp_fraction_cache

    def read_hp(self, start):
        return 256 * self.read_m(start) + self.read_m(start + 1)

    # built-in since python 3.10
    def bit_count(self, bits):
        return bin(bits).count("1")
    
    def fourier_encode(self, val):
        return np.sin(val * 2 ** np.arange(self.enc_freqs)).astype(np.float32)
    
    def update_map_progress(self):
        map_idx = int(self.read_m(0xD35E))
        self.visited_maps.add(map_idx)
        self.max_map_progress = max(self.max_map_progress, self.get_map_progress(map_idx))
    
    def get_map_progress(self, map_idx):
        if map_idx in self.essential_map_locations.keys():
            return self.essential_map_locations[map_idx]
        else:
            return -1

    def close(self):
        """Close any open video writers and stop the emulator cleanly."""
        for writer_name in ("full_frame_writer", "model_frame_writer", "map_frame_writer"):
            writer = getattr(self, writer_name, None)
            if writer is not None:
                try:
                    writer.close()
                finally:
                    setattr(self, writer_name, None)

        stop = getattr(self.pyboy, "stop", None)
        if callable(stop):
            stop()
